
package com.amerigroup.member.portal.dao.dto;

import java.util.*;



/**
 * Group Brand configuration
 * <p>Definition filename: daoMemberPortal.xml</p>
 */
public class MemberPortalGroupBrandConfigDto 
{

    
    /** 
     * <p>id</p>
     */
    
    public int id;
    
    /** 
     * <p>Group CK</p>
     */
    
    public int groupCK;
    
    /** 
     * <p>Group ID</p>
     */
    
    public String groupID;
    
    /** 
     * <p>Group Name</p>
     */
    
    public String groupName;
    
    /** 
     * <p>branding</p>
     */
    
    public String brand;
    
    /** 
     * <p>The effective date for this restriction</p>
     */
    
    public Date effectiveRestrictionDate;
    
    /** 
     * <p>The termination date for this restriction</p>
     */
    
    public Date terminationRestrictionDate;
    
	

    /**
     * Default constructor
     */
    public MemberPortalGroupBrandConfigDto() 
    {
        ;// Nothing to do
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder("[GroupBrandConfigDto: ");
        
        sb.append("id=").append(id).append(",");
        sb.append("groupCK=").append(groupCK).append(",");
        sb.append("groupID=").append(groupID).append(",");
        sb.append("groupName=").append(groupName).append(",");
        sb.append("brand=").append(brand).append(",");
        sb.append("effectiveRestrictionDate=").append(effectiveRestrictionDate).append(",");
        sb.append("terminationRestrictionDate=").append(terminationRestrictionDate);
        sb.append("]");
        return sb.toString();        
    }    
}
