
// CHECKSTYLE:OFF
package com.amerigroup.member.portal.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.*;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import com.amerigroup.utilities.Text;
import com.amerigroup.daobase.ADatabaseDao;
import com.amerigroup.daobase.IDatabaseDao;
import com.amerigroup.daobase.DAOTransaction;
import com.amerigroup.exception.runtime.execution.DAOException;
import com.amerigroup.exception.checked.DAONeedRollbackException;
import com.amerigroup.utilities.EnvironmentResolver;
import org.apache.log4j.Logger;

import com.amerigroup.member.portal.dao.dto.*;

/**
 * <p>A Data Access Object for Users in the Member Portal (old database in AGPCOM).</p>
 * <p>This class is the standard implementation for the DAO.</p>
 * <p>Definition filename: daoMemberPortal.xml</p>
 */
@SuppressWarnings("all")
public class MemberPortalDaoImpl extends ADatabaseDao implements IMemberPortalDao
{

    /** Log4j logger */
    private static final Logger log = Logger.getLogger(MemberPortalDaoImpl.class);

    /**
     * {@inheritDoc}
     * @see com.amerigroup.dao.ADatabaseDao#getLogger()
     */
    @Override
    public Logger getLogger()
    {
    	return MemberPortalDaoImpl.log;
    }
    
	/**
	 * {@inheritDoc}
	 * @see com.amerigroup.dao.IDatabaseDao#getDatasourceJndiName()
	 */
	 public String getDatasourceJndiName() 
   	 {  
       	 String jndiName = "";
     	 if (!Text.isEffectivelyEmptyOrNull(jndiName)){
	        	return jndiName;
	  	 } 	        
	  	 return getJndiNameByEnvironment();
   	 }
    
    public String getJndiNameByEnvironment() {
        
    	com.amerigroup.utilities.EnvironmentResolver envResolver = new com.amerigroup.utilities.EnvironmentResolver(); 
    	String envID = envResolver.getEnvironmentId();
		log.info("datasource " + envID);
		
		if(envID != null)
    	{

			envID= envResolver.getSingleProperty(envID,com.amerigroup.utilities.EnvironmentResolver.PropertyType.PROPERTY_TYPE_DATASOURCE, "Web");
        }
        
        return envID;      
    	
    }
	
		
    /**
     * <p>Get group brand configurations</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre> 
				select id, GRGR_CK, GRGR_ID, GRGR_NAME, Brand, EffectiveDate, TerminationDate 
                  from [dbo].[GRGR_Brand_Mapping] gr (nolock)                  
                  WHERE gr.GRGR_ID=?  AND getDate() BETWEEN gr.EffectiveDate AND  gr.TerminationDate
			</pre></blockquote></p>
     * @param groupID which is the id of a group
     * @return A <tt>List</tt> of <tt>MemberPortalGroupBrandConfigDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public List<MemberPortalGroupBrandConfigDto> getBrand(String groupID)
    {
        List<MemberPortalGroupBrandConfigDto> result = new ArrayList<MemberPortalGroupBrandConfigDto>();
        
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        String sql = ""+
         " select id, GRGR_CK, GRGR_ID, GRGR_NAME, Brand, EffectiveDate, TerminationDate"+
         " from [dbo].[GRGR_Brand_Mapping] gr (nolock)"+
         " WHERE gr.GRGR_ID=?  AND getDate() BETWEEN gr.EffectiveDate AND  gr.TerminationDate"+
         " 			";
        
        try 
        {
	        long connectionStart = System.currentTimeMillis();
			conn = getConnection();
			if (conn == null) {
				log.error("Unable to get a connection to datasource " + getDatasourceJndiName());
					log.debug("<getBrand" );
				return result;
			}

				StringBuilder sb = null;
            
            ps = conn.prepareStatement(sql);
            
            long connectionDuration = System.currentTimeMillis() - connectionStart;
            
            int parmNum = 1;
            
				log.debug("Executing SQL: " + sql);
            
				log.debug("   Setting parm #" + parmNum + " (groupID) to " + groupID);
                
            ps.setString(parmNum++, groupID);
            
            long queryStart = System.currentTimeMillis();
				log.debug("Starting query");
            rs = ps.executeQuery();
            int queryDuration = (int) (System.currentTimeMillis() - queryStart);

            // Load results into list            
            long loadResultsStart = System.currentTimeMillis();
            int rowsRead = 0;
            while (rs.next())
            {
            	rowsRead++;
                MemberPortalGroupBrandConfigDto dto = new MemberPortalGroupBrandConfigDto();
                                
                dto.id = rs.getInt("id");
                                
                dto.groupCK = rs.getInt("GRGR_CK");
                                
                dto.groupID = rs.getString("GRGR_ID");
                if (rs.wasNull()) 
                {
                    dto.groupID = null;
                }
                                
                dto.groupName = rs.getString("GRGR_NAME");
                if (rs.wasNull()) 
                {
                    dto.groupName = null;
                }
                                
                dto.brand = rs.getString("Brand");
                if (rs.wasNull()) 
                {
                    dto.brand = null;
                }
                
                dto.effectiveRestrictionDate = rs.getTimestamp("EffectiveDate");
                if (rs.wasNull()) 
                {
                    dto.effectiveRestrictionDate = null;
                }
                
                dto.terminationRestrictionDate = rs.getTimestamp("TerminationDate");
                if (rs.wasNull()) 
                {
                    dto.terminationRestrictionDate = null;
                }
                
                result.add(dto);
                
            }
            
            
            long loadResultsDuration = System.currentTimeMillis() - loadResultsStart;
            log.info(String.format("Query Statistics:getBrand  getJndiName="+getDatasourceJndiName()+", getConnection=%s, queryExecution=%s, loadResults=%s, rowsRead=%s", connectionDuration, queryDuration, loadResultsDuration, rowsRead));
        }
        catch (SQLException ex) 
        {
            SQLException tex = ex;
            if (ex.getNextException() != null)
            {
                tex = ex.getNextException();
            }
            while (tex != null)
            {
                log.error("Database problem: " + tex.getMessage()
                        + " - error code=" + tex.getErrorCode() + ", SQLState="
                        + tex.getSQLState() + " - SQL: " + sql, tex);
                tex = tex.getNextException();
            }
            throw new DAOException("Unable to perform read - SQL: " + sql, ex);
        }
        finally
        {
            closeDatabaseObjects(rs, ps, conn);
        }
        return result;
    }
	

    
}
// CHECKSTYLE:ON
/* END OF FILE  - com.amerigroup.member.portal.dao.MemberPortalDaoImpl */
