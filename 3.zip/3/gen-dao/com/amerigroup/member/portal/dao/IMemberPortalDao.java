
// CHECKSTYLE:OFF
package com.amerigroup.member.portal.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.*;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.amerigroup.daobase.IDatabaseDao;
import com.amerigroup.daobase.DAOTransaction;
import com.amerigroup.exception.runtime.execution.DAOException;
import com.amerigroup.exception.checked.DAONeedRollbackException;

import org.apache.log4j.Logger;

import com.amerigroup.member.portal.dao.dto.*;

/**
 * <p>A Data Access Object for Users in the Member Portal (old database in AGPCOM).</p>
 * <p>This class is the interface for the DAO.  The standard implementation is {@link MemberPortalDaoImpl}</p>
 * <p>Definition filename: daoMemberPortal.xml</p>
 */
@SuppressWarnings("all")
public interface IMemberPortalDao extends IDatabaseDao
{

		
		
		
    /**
     * <p>Get group brand configurations</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre> 
				select id, GRGR_CK, GRGR_ID, GRGR_NAME, Brand, EffectiveDate, TerminationDate 
                  from [dbo].[GRGR_Brand_Mapping] gr (nolock)                  
                  WHERE gr.GRGR_ID=?  AND getDate() BETWEEN gr.EffectiveDate AND  gr.TerminationDate
			</pre></blockquote></p>
     * @param groupID which is the id of a group
     * @return A <tt>List</tt> of <tt>MemberPortalGroupBrandConfigDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<MemberPortalGroupBrandConfigDto> getBrand(String groupID);    

 
    
}
// CHECKSTYLE:ON
/* END OF FILE  - com.amerigroup.member.portal.dao.IMemberPortalDao */
