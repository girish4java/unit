
package com.amerigroup.facets.dao.dto;

import java.util.*;



/**
 * DTO containing Member basic details and basic eligibility details
 * <p>Definition filename: daoFacetsMember.xml</p>
 */
public class FacetsMemberMemberDetailsDto 
{

    
    /** 
     * <p>Member's First Name</p>
     */
    
    public String firstName;
    
    /** 
     * <p>Member's Middle Initial </p>
     */
    
    public String middleInitial;
    
    /** 
     * <p>Member's Last Name</p>
     */
    
    public String lastName;
    
    /** 
     * <p>Member's Birth Date</p>
     */
    
    public Date birthDate;
    
    /** 
     * <p>Member's Gender</p>
     */
    
    public String gender;
    
    /** 
     * <p>Member's Contrived Key</p>
     */
    
    public String memberCk;
    
    /** 
     * <p>Member's Medicare Id</p>
     */
    
    public String medicareId;
    
    /** 
     * <p>Member's Medicaid Id</p>
     */
    
    public String medicaidId;
    
    /** 
     * <p>Member's Subscriber Contrived key</p>
     */
    
    public String sbrUid;
    
    /** 
     * <p>Member's Plan Prefix</p>
     */
    
    public String planPrefix;
    
    /** 
     * <p>Member's Eligibility Effective Date</p>
     */
    
    public Date eligibilityEffDt;
    
    /** 
     * <p>Member's Eligibility Termination Date</p>
     */
    
    public Date eligibilityTermDt;
    
    /** 
     * <p>Member's Product ID</p>
     */
    
    public String productId;
    
    /** 
     * <p>Member's plan Id</p>
     */
    
    public String planId;
    
    /** 
     * <p>Member's Class Id</p>
     */
    
    public String classId;
    
    /** 
     * <p>Eligibility Indicator</p>
     */
    
    public String eligibilityIndicator;
    
    /** 
     * <p>Subscriber Id</p>
     */
    
    public String subscriberId;
    
    /** 
     * <p>Line of Business</p>
     */
    
    public String lineOfBusiness;
    
    /** 
     * <p>Group Contrived Key</p>
     */
    
    public String groupCk;
    
    /** 
     * <p>Member's group region</p>
     */
    
    public String region;
    
    /** 
     * <p>Member's group Id</p>
     */
    
    public String groupId;
    
    /** 
     * <p>Member's group Type</p>
     */
    
    public String groupType;
    
    /** 
     * <p>Member's sub group</p>
     */
    
    public String subGroup;
    
    /** 
     * <p>Member's sub group sgsg_ck</p>
     */
    
    public String SGSG_CK;
    
	

    /**
     * Default constructor
     */
    public FacetsMemberMemberDetailsDto() 
    {
        ;// Nothing to do
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder("[MemberDetailsDto: ");
        
        sb.append("firstName=").append(firstName).append(",");
        sb.append("middleInitial=").append(middleInitial).append(",");
        sb.append("lastName=").append(lastName).append(",");
        sb.append("birthDate=").append(birthDate).append(",");
        sb.append("gender=").append(gender).append(",");
        sb.append("memberCk=").append(memberCk).append(",");
        sb.append("medicareId=").append(medicareId).append(",");
        sb.append("medicaidId=").append(medicaidId).append(",");
        sb.append("sbrUid=").append(sbrUid).append(",");
        sb.append("planPrefix=").append(planPrefix).append(",");
        sb.append("eligibilityEffDt=").append(eligibilityEffDt).append(",");
        sb.append("eligibilityTermDt=").append(eligibilityTermDt).append(",");
        sb.append("productId=").append(productId).append(",");
        sb.append("planId=").append(planId).append(",");
        sb.append("classId=").append(classId).append(",");
        sb.append("eligibilityIndicator=").append(eligibilityIndicator).append(",");
        sb.append("subscriberId=").append(subscriberId).append(",");
        sb.append("lineOfBusiness=").append(lineOfBusiness).append(",");
        sb.append("groupCk=").append(groupCk).append(",");
        sb.append("region=").append(region).append(",");
        sb.append("groupId=").append(groupId).append(",");
        sb.append("groupType=").append(groupType).append(",");
        sb.append("subGroup=").append(subGroup).append(",");
        sb.append("SGSG_CK=").append(SGSG_CK);
        sb.append("]");
        return sb.toString();        
    }    
}
