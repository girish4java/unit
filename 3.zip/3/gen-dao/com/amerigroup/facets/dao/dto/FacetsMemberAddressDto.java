
package com.amerigroup.facets.dao.dto;

import java.util.*;



/**
 * An address for a Facets Provider
 * <p>Definition filename: daoFacetsMember.xml</p>
 */
public class FacetsMemberAddressDto 
{

    
    /** 
     * <p>The type of address this is.  H=Home, 1=Mailing (usually)</p>
     */
    
    public String type;
    
    /** 
     * <p>The 1st line of the street address.</p>
     */
    
    public String street1;
    
    /** 
     * <p>The 2nd line of the street address.</p>
     */
    
    public String street2;
    
    /** 
     * <p>The 3rd line of the street address.</p>
     */
    
    public String street3;
    
    /** 
     * <p>The city for this address.</p>
     */
    
    public String city;
    
    /** 
     * <p>The county for this address.</p>
     */
    
    public String county;
    
    /** 
     * <p>The state abbreviation for this address.</p>
     */
    
    public String state;
    
    /** 
     * <p>The zip code for this address.</p>
     */
    
    public String zip;
    
    /** 
     * <p>The phone number for this address.</p>
     */
    
    public String phone;
    
    /** 
     * <p>The phone number extension for this address.</p>
     */
    
    public String phoneExt;
    
    /** 
     * <p>The email address for this address.</p>
     */
    
    public String email;
    
    /** 
     * <p>The fax number for this address.</p>
     */
    
    public String fax;
    
    /** 
     * <p>The fax number extension for this address.</p>
     */
    
    public String faxExt;
    
    /** 
     * <p>Home Address Type</p>
     */
    
    public String homeAddrType;
    
    /** 
     * <p>Mail Address Type</p>
     */
    
    public String mailAddrType;
    
	

    /**
     * Default constructor
     */
    public FacetsMemberAddressDto() 
    {
        ;// Nothing to do
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder("[AddressDto: ");
        
        sb.append("type=").append(type).append(",");
        sb.append("street1=").append(street1).append(",");
        sb.append("street2=").append(street2).append(",");
        sb.append("street3=").append(street3).append(",");
        sb.append("city=").append(city).append(",");
        sb.append("county=").append(county).append(",");
        sb.append("state=").append(state).append(",");
        sb.append("zip=").append(zip).append(",");
        sb.append("phone=").append(phone).append(",");
        sb.append("phoneExt=").append(phoneExt).append(",");
        sb.append("email=").append(email).append(",");
        sb.append("fax=").append(fax).append(",");
        sb.append("faxExt=").append(faxExt).append(",");
        sb.append("homeAddrType=").append(homeAddrType).append(",");
        sb.append("mailAddrType=").append(mailAddrType);
        sb.append("]");
        return sb.toString();        
    }    
}
