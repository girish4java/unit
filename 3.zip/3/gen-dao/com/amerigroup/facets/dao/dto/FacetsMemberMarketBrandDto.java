
package com.amerigroup.facets.dao.dto;

import java.util.*;



/**
 * Member Market Brand
 * <p>Definition filename: daoFacetsMember.xml</p>
 */
public class FacetsMemberMarketBrandDto 
{

    
    /** 
     * <p>Market brand code</p>
     */
    
    public String brandCode;
    
    /** 
     * <p>Brand Description</p>
     */
    
    public String brandDesc;
    
    /** 
     * <p>gcpp regex pattern</p>
     */
    
    public String gcppPattern;
    
    /** 
     * <p>eff Date</p>
     */
    
    public Date effDate;
    
	

    /**
     * Default constructor
     */
    public FacetsMemberMarketBrandDto() 
    {
        ;// Nothing to do
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder("[MarketBrandDto: ");
        
        sb.append("brandCode=").append(brandCode).append(",");
        sb.append("brandDesc=").append(brandDesc).append(",");
        sb.append("gcppPattern=").append(gcppPattern).append(",");
        sb.append("effDate=").append(effDate);
        sb.append("]");
        return sb.toString();        
    }    
}
