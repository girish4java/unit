
package com.amerigroup.facets.dao.dto;

import java.util.*;



/**
 * An Hipaa for a member
 * <p>Definition filename: daoFacetsMember.xml</p>
 */
public class FacetsMemberHippaDto 
{

    
    /** 
     * <p>This is the Amerigroup Id.</p>
     */
    
    public String amerigroupID;
    
    /** 
     * <p>This Y or N value for hipaa</p>
     */
    
    public String hipaa;
    
	

    /**
     * Default constructor
     */
    public FacetsMemberHippaDto() 
    {
        ;// Nothing to do
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder("[HippaDto: ");
        
        sb.append("amerigroupID=").append(amerigroupID).append(",");
        sb.append("hipaa=").append(hipaa);
        sb.append("]");
        return sb.toString();        
    }    
}
