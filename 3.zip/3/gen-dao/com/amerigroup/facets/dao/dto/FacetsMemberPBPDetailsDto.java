
package com.amerigroup.facets.dao.dto;

import java.util.*;



/**
 * The dto containing medicare details
 * <p>Definition filename: daoFacetsMember.xml</p>
 */
public class FacetsMemberPBPDetailsDto 
{

    
    /** 
     * <p>Member's Contrived Key</p>
     */
    
    public int memeCk;
    
    /** 
     * <p>Member's Event</p>
     */
    
    public String event;
    
    /** 
     * <p>HCFA effective Date</p>
     */
    
    public Date hcfaEffDT;
    
    /** 
     * <p>HCFA termination Date</p>
     */
    
    public Date hcfaTermDT;
    
    /** 
     * <p>PBP Id</p>
     */
    
    public String pbpId;
    
	

    /**
     * Default constructor
     */
    public FacetsMemberPBPDetailsDto() 
    {
        ;// Nothing to do
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder("[PBPDetailsDto: ");
        
        sb.append("memeCk=").append(memeCk).append(",");
        sb.append("event=").append(event).append(",");
        sb.append("hcfaEffDT=").append(hcfaEffDT).append(",");
        sb.append("hcfaTermDT=").append(hcfaTermDT).append(",");
        sb.append("pbpId=").append(pbpId);
        sb.append("]");
        return sb.toString();        
    }    
}
