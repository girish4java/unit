
package com.amerigroup.facets.dao.dto;

import java.util.*;



/**
 * Member SRI restriction
 * <p>Definition filename: daoFacetsMember.xml</p>
 */
public class FacetsMemberSriDto 
{

    
    /** 
     * <p>Service Restriction Indicative code</p>
     */
    
    public String code;
    
	

    /**
     * Default constructor
     */
    public FacetsMemberSriDto() 
    {
        ;// Nothing to do
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder("[SriDto: ");
        
        sb.append("code=").append(code);
        sb.append("]");
        return sb.toString();        
    }    
}
