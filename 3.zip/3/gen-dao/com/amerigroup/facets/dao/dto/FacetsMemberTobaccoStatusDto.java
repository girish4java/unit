
package com.amerigroup.facets.dao.dto;

import java.util.*;



/**
 * Tobacco Status
 * <p>Definition filename: daoFacetsMember.xml</p>
 */
public class FacetsMemberTobaccoStatusDto 
{

    
    /** 
     * <p>This is the tobacco status.</p>
     */
    
    public String categoryValue;
    
	

    /**
     * Default constructor
     */
    public FacetsMemberTobaccoStatusDto() 
    {
        ;// Nothing to do
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder("[TobaccoStatusDto: ");
        
        sb.append("categoryValue=").append(categoryValue);
        sb.append("]");
        return sb.toString();        
    }    
}
