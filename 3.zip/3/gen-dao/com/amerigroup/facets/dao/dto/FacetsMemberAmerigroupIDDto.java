
package com.amerigroup.facets.dao.dto;

import java.util.*;



/**
 * An Amerigroup ID for a Facets Member
 * <p>Definition filename: daoFacetsMember.xml</p>
 */
public class FacetsMemberAmerigroupIDDto 
{

    
    /** 
     * <p>This is the Amerigroup(SBSB) Id.</p>
     */
    
    public String amerigroupID;
    
    /** 
     * <p>This is the Group Id.</p>
     */
    
    public String groupID;
    
	

    /**
     * Default constructor
     */
    public FacetsMemberAmerigroupIDDto() 
    {
        ;// Nothing to do
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder("[AmerigroupIDDto: ");
        
        sb.append("amerigroupID=").append(amerigroupID).append(",");
        sb.append("groupID=").append(groupID);
        sb.append("]");
        return sb.toString();        
    }    
}
