
package com.amerigroup.facets.dao.dto;

import java.util.*;



/**
 * A member eligibility in Facets
 * <p>Definition filename: daoFacetsMember.xml</p>
 */
public class FacetsMemberEligibilityDto 
{

    
    /** 
     * <p>Group CK</p>
     */
    
    public String groupCk;
    
    /** 
     * <p>This is the subscriber ID</p>
     */
    
    public String sbsbID;
    
    /** 
     * <p>This is the subscriber CK value</p>
     */
    
    public String sbsbCK;
    
    /** 
     * <p>This is the class.</p>
     */
    
    public String classID;
    
    /** 
     * <p>This is the plan.</p>
     */
    
    public String planID;
    
    /** 
     * <p>This is description for the plan of benefits.</p>
     */
    
    public String planDesc;
    
    /** 
     * <p>This is the group.</p>
     */
    
    public String groupID;
    
    /** 
     * <p>This is the subgroup type.</p>
     */
    
    public String subgroupType;
    
    /** 
     * <p>This is the subgroup Id.</p>
     */
    
    public String subGroupId;
    
    /** 
     * <p>This is the government assigned Medicaid Id.</p>
     */
    
    public String medicaidID;
    
    /** 
     * <p>This is the government assigned Medicare Id.</p>
     */
    
    public String medicareID;
    
    /** 
     * <p>This is the product.</p>
     */
    
    public String productID;
    
    /** 
     * <p>This is the product name.</p>
     */
    
    public String productName;
    
    /** 
     * <p>This is the product description.</p>
     */
    
    public String productDescription;
    
    /** 
     * <p>This is the product value Code</p>
     */
    
    public String productValueCode;
    
    /** 
     * <p>This is the product value Code Description</p>
     */
    
    public String productValueCodeDesc;
    
    /** 
     * <p>This is the eligibility begins.</p>
     */
    
    public Date dateEffective;
    
    /** 
     * <p>This is the date the eligibility ends.</p>
     */
    
    public Date dateTermination;
    
    /** 
     * <p>This is the Coverage Type Code.</p>
     */
    
    public String coverageTypeCode;
    
    /** 
     * <p>Member's First Name</p>
     */
    
    public String firstName;
    
    /** 
     * <p>Member's Last Name</p>
     */
    
    public String lastName;
    
    /** 
     * <p>Member's Full Last Name</p>
     */
    
    public String fullLastName;
    
    /** 
     * <p>Member's Birth Date</p>
     */
    
    public Date birthDt;
    
    /** 
     * <p>Line of Business Id</p>
     */
    
    public String lobId;
    
    /** 
     * <p>Eligibility Status Code</p>
     */
    
    public String statusCode;
    
    /** 
     * <p>Group Name</p>
     */
    
    public String groupName;
    
    /** 
     * <p>Sub Group name</p>
     */
    
    public String subGroupName;
    
    /** 
     * <p>Sub Group Effective Date</p>
     */
    
    public Date subGroupEffectiveDate;
    
    /** 
     * <p>Sub Group Termination Date</p>
     */
    
    public Date subGroupTerminationDate;
    
    /** 
     * <p>Source System of the Member</p>
     */
    
    public String sourceSystem;
    
    /** 
     * <p>Plan entry date</p>
     */
    
    public Date planEntryDt;
    
    /** 
     * <p>eligibilityCreateDtm</p>
     */
    
    public Date eligibilityCreateDtm;
    
    /** 
     * <p>memeCk</p>
     */
    
    public String memeCk;
    
    /** 
     * <p>Group Phone Number</p>
     */
    
    public String grpPhNo;
    
	

    /**
     * Default constructor
     */
    public FacetsMemberEligibilityDto() 
    {
        ;// Nothing to do
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder("[EligibilityDto: ");
        
        sb.append("groupCk=").append(groupCk).append(",");
        sb.append("sbsbID=").append(sbsbID).append(",");
        sb.append("sbsbCK=").append(sbsbCK).append(",");
        sb.append("classID=").append(classID).append(",");
        sb.append("planID=").append(planID).append(",");
        sb.append("planDesc=").append(planDesc).append(",");
        sb.append("groupID=").append(groupID).append(",");
        sb.append("subgroupType=").append(subgroupType).append(",");
        sb.append("subGroupId=").append(subGroupId).append(",");
        sb.append("medicaidID=").append(medicaidID).append(",");
        sb.append("medicareID=").append(medicareID).append(",");
        sb.append("productID=").append(productID).append(",");
        sb.append("productName=").append(productName).append(",");
        sb.append("productDescription=").append(productDescription).append(",");
        sb.append("productValueCode=").append(productValueCode).append(",");
        sb.append("productValueCodeDesc=").append(productValueCodeDesc).append(",");
        sb.append("dateEffective=").append(dateEffective).append(",");
        sb.append("dateTermination=").append(dateTermination).append(",");
        sb.append("coverageTypeCode=").append(coverageTypeCode).append(",");
        sb.append("firstName=").append(firstName).append(",");
        sb.append("lastName=").append(lastName).append(",");
        sb.append("fullLastName=").append(fullLastName).append(",");
        sb.append("birthDt=").append(birthDt).append(",");
        sb.append("lobId=").append(lobId).append(",");
        sb.append("statusCode=").append(statusCode).append(",");
        sb.append("groupName=").append(groupName).append(",");
        sb.append("subGroupName=").append(subGroupName).append(",");
        sb.append("subGroupEffectiveDate=").append(subGroupEffectiveDate).append(",");
        sb.append("subGroupTerminationDate=").append(subGroupTerminationDate).append(",");
        sb.append("sourceSystem=").append(sourceSystem).append(",");
        sb.append("planEntryDt=").append(planEntryDt).append(",");
        sb.append("eligibilityCreateDtm=").append(eligibilityCreateDtm).append(",");
        sb.append("memeCk=").append(memeCk).append(",");
        sb.append("grpPhNo=").append(grpPhNo);
        sb.append("]");
        return sb.toString();        
    }    
}
