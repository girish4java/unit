
package com.amerigroup.facets.dao.dto;

import java.util.*;



/**
 * A DTO containing prefix field from class plan table
 * <p>Definition filename: daoFacetsMember.xml</p>
 */
public class FacetsMemberClassPlanPrefixDto 
{

    
    /** 
     * <p>Prefix </p>
     */
    
    public String prefix;
    
	

    /**
     * Default constructor
     */
    public FacetsMemberClassPlanPrefixDto() 
    {
        ;// Nothing to do
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder("[ClassPlanPrefixDto: ");
        
        sb.append("prefix=").append(prefix);
        sb.append("]");
        return sb.toString();        
    }    
}
