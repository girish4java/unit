
package com.amerigroup.facets.dao.dto;

import java.util.*;



/**
 * Member Billing component ID in Facets
 * <p>Definition filename: daoFacetsMember.xml</p>
 */
public class FacetsMemberBillingComponentDto 
{

    
    /** 
     * <p>Product Billing Component ID.</p>
     */
    
    public String billingComponentId;
    
    /** 
     * <p>Product Billing Component description.</p>
     */
    
    public String billingComponentDesc;
    
	

    /**
     * Default constructor
     */
    public FacetsMemberBillingComponentDto() 
    {
        ;// Nothing to do
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder("[BillingComponentDto: ");
        
        sb.append("billingComponentId=").append(billingComponentId).append(",");
        sb.append("billingComponentDesc=").append(billingComponentDesc);
        sb.append("]");
        return sb.toString();        
    }    
}
