
package com.amerigroup.facets.dao.dto;

import java.util.*;



/**
 * Dto containing the Dual citizenship details for a member
 * <p>Definition filename: daoFacetsMember.xml</p>
 */
public class FacetsMemberDualCitizenshipDetailsDto 
{

    
    /** 
     * <p>Dual Link</p>
     */
    
    public String dualLink;
    
    /** 
     * <p>Dual Type</p>
     */
    
    public String dualType;
    
    /** 
     * <p>Requested Subscriber Id</p>
     */
    
    public String requestedSubscriberId;
    
    /** 
     * <p>Requested Group Id</p>
     */
    
    public String requestedGroupId;
    
    /** 
     * <p>Requested MEME_CK</p>
     */
    
    public String requestedMemeCk;
    
    /** 
     * <p>Target Subscriber ID</p>
     */
    
    public String targetSubscriberId;
    
    /** 
     * <p>Target Group ID</p>
     */
    
    public String targetGroupId;
    
    /** 
     * <p>Target MEME_CK</p>
     */
    
    public String targetMemeCk;
    
    /** 
     * <p>Dual Span Start Date</p>
     */
    
    public Date dualSpanStartDt;
    
    /** 
     * <p>Dual Span End Date</p>
     */
    
    public Date dualSpanEndDt;
    
    /** 
     * <p>Dual Type Desc</p>
     */
    
    public String dualTypeDesc;
    
    /** 
     * <p>Medicaid Aid Category</p>
     */
    
    public String medicaidAidCategory;
    
    /** 
     * <p>Medicaid Cost Share</p>
     */
    
    public String medicaidCostShare;
    
	

    /**
     * Default constructor
     */
    public FacetsMemberDualCitizenshipDetailsDto() 
    {
        ;// Nothing to do
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder("[DualCitizenshipDetailsDto: ");
        
        sb.append("dualLink=").append(dualLink).append(",");
        sb.append("dualType=").append(dualType).append(",");
        sb.append("requestedSubscriberId=").append(requestedSubscriberId).append(",");
        sb.append("requestedGroupId=").append(requestedGroupId).append(",");
        sb.append("requestedMemeCk=").append(requestedMemeCk).append(",");
        sb.append("targetSubscriberId=").append(targetSubscriberId).append(",");
        sb.append("targetGroupId=").append(targetGroupId).append(",");
        sb.append("targetMemeCk=").append(targetMemeCk).append(",");
        sb.append("dualSpanStartDt=").append(dualSpanStartDt).append(",");
        sb.append("dualSpanEndDt=").append(dualSpanEndDt).append(",");
        sb.append("dualTypeDesc=").append(dualTypeDesc).append(",");
        sb.append("medicaidAidCategory=").append(medicaidAidCategory).append(",");
        sb.append("medicaidCostShare=").append(medicaidCostShare);
        sb.append("]");
        return sb.toString();        
    }    
}
