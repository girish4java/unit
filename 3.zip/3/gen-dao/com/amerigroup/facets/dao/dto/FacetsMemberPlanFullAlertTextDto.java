
package com.amerigroup.facets.dao.dto;

import java.util.*;



/**
 * warning  information of a Plan.
 * <p>Definition filename: daoFacetsMember.xml</p>
 */
public class FacetsMemberPlanFullAlertTextDto 
{

    
    /** 
     * <p>record type</p>
     */
    
    public String recType;
    
    /** 
     * <p>Effective Date of the message</p>
     */
    
    public Date effDate;
    
    /** 
     * <p>Termination Date of the message</p>
     */
    
    public Date termDate;
    
    /** 
     * <p>Message Sequence Number</p>
     */
    
    public String seqNo;
    
    /** 
     * <p>Alert Message</p>
     */
    
    public String text1;
    
    /** 
     * <p>Alert Message</p>
     */
    
    public String text2;
    
	

    /**
     * Default constructor
     */
    public FacetsMemberPlanFullAlertTextDto() 
    {
        ;// Nothing to do
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder("[PlanFullAlertTextDto: ");
        
        sb.append("recType=").append(recType).append(",");
        sb.append("effDate=").append(effDate).append(",");
        sb.append("termDate=").append(termDate).append(",");
        sb.append("seqNo=").append(seqNo).append(",");
        sb.append("text1=").append(text1).append(",");
        sb.append("text2=").append(text2);
        sb.append("]");
        return sb.toString();        
    }    
}
