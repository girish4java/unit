
package com.amerigroup.facets.dao.dto;

import java.util.*;



/**
 * Member Billing Group ID in Facets
 * <p>Definition filename: daoFacetsMember.xml</p>
 */
public class FacetsMemberBillingGroupDto 
{

    
    /** 
     * <p>Member Billing Group ID.</p>
     */
    
    public String federalContractId;
    
    /** 
     * <p>HCFA effective Date</p>
     */
    
    public Date hcfaEffDT;
    
    /** 
     * <p>HCFA termination Date</p>
     */
    
    public Date hcfaTermDT;
    
	

    /**
     * Default constructor
     */
    public FacetsMemberBillingGroupDto() 
    {
        ;// Nothing to do
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder("[BillingGroupDto: ");
        
        sb.append("federalContractId=").append(federalContractId).append(",");
        sb.append("hcfaEffDT=").append(hcfaEffDT).append(",");
        sb.append("hcfaTermDT=").append(hcfaTermDT);
        sb.append("]");
        return sb.toString();        
    }    
}
