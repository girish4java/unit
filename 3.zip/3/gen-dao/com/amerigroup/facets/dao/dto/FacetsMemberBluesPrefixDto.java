
package com.amerigroup.facets.dao.dto;

import java.util.*;



/**
 * A DTO to hold ID prefix Blues members
 * <p>Definition filename: daoFacetsMember.xml</p>
 */
public class FacetsMemberBluesPrefixDto 
{

    
    /** 
     * <p>for VAMM members this is the prefix for their ID card </p>
     */
    
    public String prefix;
    
	

    /**
     * Default constructor
     */
    public FacetsMemberBluesPrefixDto() 
    {
        ;// Nothing to do
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder("[BluesPrefixDto: ");
        
        sb.append("prefix=").append(prefix);
        sb.append("]");
        return sb.toString();        
    }    
}
