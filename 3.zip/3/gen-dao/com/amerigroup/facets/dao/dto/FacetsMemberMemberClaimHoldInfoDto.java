
package com.amerigroup.facets.dao.dto;

import java.util.*;



/**
 * Member ClaimHold Info
 * <p>Definition filename: daoFacetsMember.xml</p>
 */
public class FacetsMemberMemberClaimHoldInfoDto 
{

    
    /** 
     * <p>Member's subscriber ID</p>
     */
    
    public String sbsbId;
    
    /** 
     * <p>Member Contrived Key</p>
     */
    
    public String memeCK;
    
    /** 
     * <p>Effective Date</p>
     */
    
    public Date effDate;
    
    /** 
     * <p>Termination Date</p>
     */
    
    public Date termDate;
    
    /** 
     * <p>Reason code</p>
     */
    
    public String reasonCode;
    
    /** 
     * <p>Eligibility begin Date.</p>
     */
    
    public Date eligEffDate;
    
    /** 
     * <p>Eligibility end date.</p>
     */
    
    public Date eligTermDate;
    
    /** 
     * <p>Eligibility Ind</p>
     */
    
    public String eligInd;
    
	

    /**
     * Default constructor
     */
    public FacetsMemberMemberClaimHoldInfoDto() 
    {
        ;// Nothing to do
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder("[MemberClaimHoldInfoDto: ");
        
        sb.append("sbsbId=").append(sbsbId).append(",");
        sb.append("memeCK=").append(memeCK).append(",");
        sb.append("effDate=").append(effDate).append(",");
        sb.append("termDate=").append(termDate).append(",");
        sb.append("reasonCode=").append(reasonCode).append(",");
        sb.append("eligEffDate=").append(eligEffDate).append(",");
        sb.append("eligTermDate=").append(eligTermDate).append(",");
        sb.append("eligInd=").append(eligInd);
        sb.append("]");
        return sb.toString();        
    }    
}
