
package com.amerigroup.facets.dao.dto;

import java.util.*;



/**
 * A DTO to hold SBSB ID and prefix for Blues members
 * <p>Definition filename: daoFacetsMember.xml</p>
 */
public class FacetsMemberIdAndBluesPrefixDto 
{

    
    /** 
     * <p>The subscriber ID of a member</p>
     */
    
    public String sbsbId;
    
    /** 
     * <p>The Subgroup Type, for VAMM members this is the prefix for their ID card </p>
     */
    
    public String prefix;
    
	

    /**
     * Default constructor
     */
    public FacetsMemberIdAndBluesPrefixDto() 
    {
        ;// Nothing to do
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder("[IdAndBluesPrefixDto: ");
        
        sb.append("sbsbId=").append(sbsbId).append(",");
        sb.append("prefix=").append(prefix);
        sb.append("]");
        return sb.toString();        
    }    
}
