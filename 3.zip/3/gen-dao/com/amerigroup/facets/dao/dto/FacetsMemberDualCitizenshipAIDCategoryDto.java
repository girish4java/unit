
package com.amerigroup.facets.dao.dto;

import java.util.*;



/**
 * Dto containing the Dual citizenship AID Category details for a member
 * <p>Definition filename: daoFacetsMember.xml</p>
 */
public class FacetsMemberDualCitizenshipAIDCategoryDto 
{

    
    /** 
     * <p>Medicaid Aid Category from Enrollment</p>
     */
    
    public String medicaidAidCategory;
    
	

    /**
     * Default constructor
     */
    public FacetsMemberDualCitizenshipAIDCategoryDto() 
    {
        ;// Nothing to do
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder("[DualCitizenshipAIDCategoryDto: ");
        
        sb.append("medicaidAidCategory=").append(medicaidAidCategory);
        sb.append("]");
        return sb.toString();        
    }    
}
