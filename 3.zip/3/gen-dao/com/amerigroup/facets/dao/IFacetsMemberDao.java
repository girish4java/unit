
// CHECKSTYLE:OFF
package com.amerigroup.facets.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.*;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.amerigroup.daobase.IDatabaseDao;
import com.amerigroup.daobase.DAOTransaction;
import com.amerigroup.exception.runtime.execution.DAOException;
import com.amerigroup.exception.checked.DAONeedRollbackException;

import org.apache.log4j.Logger;

import com.amerigroup.facets.dao.dto.*;

/**
 * <p>A DAO for facets Members</p>
 * <p>This class is the interface for the DAO.  The standard implementation is {@link FacetsMemberDaoImpl}</p>
 * <p>Definition filename: daoFacetsMember.xml</p>
 */
@SuppressWarnings("all")
public interface IFacetsMemberDao extends IDatabaseDao
{

		
		
		
    /**
     * <p>get sbsb ID and prefix as of search Date</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
				select sbsb.SBSB_ID, sbsb.GRGR_CK
				from cmc_sbsb_subsc sbsb
				JOIN cmc_meme_member meme ON sbsb.sbsb_ck = meme.sbsb_ck
				JOIN cmc_mepe_prcs_elig mepe ON mepe.meme_ck = meme.meme_ck
				JOIN CMC_CSPI_CS_PLAN cspi on cspi.GRGR_CK = mepe.GRGR_CK and cspi.cscs_ID=mepe.cscs_ID and cspi.cspi_ID=mepe.cspi_ID
				and cspi.CSPD_CAT=mepe.CSPD_CAT and mepe.MEPE_EFF_DT <= cspi.CSPI_TERM_DT and mepe.MEPE_TERM_DT >= cspi.CSPI_EFF_DT
				where sbsb.SBSB_ID=? and upper(cspi.CSPI_ITS_PREFIX)=?
				and ?  <= cspi.CSPI_TERM_DT and ? >= cspi.CSPI_EFF_DT
			</pre></blockquote></p>
     * @param subscriberID The SBSB_ID of the member
     * @param prefix The prefix
     * @param searchStartDate The Search Date
     * @param searchEndDate The Search Date
     * @return A <tt>List</tt> of <tt>FacetsMemberAmerigroupIDDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberAmerigroupIDDto> getIdAndPrefixBySbsbIdDateAndPrefix(String subscriberID, String prefix, Date searchStartDate, Date searchEndDate);    

 
		
		
    /**
     * <p>Find amerigroupID using the amerigroup id</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre> select sbsb_id, grgr_ck from cmc_sbsb_subsc where sbsb_id=? </pre></blockquote></p>
     * @param agp Amerigroup ID of the member
     * @return A <tt>List</tt> of <tt>FacetsMemberAmerigroupIDDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberAmerigroupIDDto> findByAgp(String agp);    

 
		
		
    /**
     * <p>Get a members past, current, and future eligibility using the amerigroup id, sorted with most to least recent</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
			    select m.MEME_FIRST_NAME, m.MEME_LAST_NAME, CONCAT(m.MEME_LAST_NAME, m.MEME_TITLE) as FULL_LAST_NAME, m.MEME_BIRTH_DT, pd.LOBD_ID, s.SBSB_ID, s.SBSB_CK, e.MEPE_EFF_DT, e.MEPE_TERM_DT, e.CSCS_ID, e.PDPD_ID, e.CSPI_ID, pland.PLDS_DESC, g.GRGR_ID, sg.SGSG_MCTR_TYPE, m.MEME_MEDCD_NO,m.MEME_HICN, p.NAME, p.GENERAL_DESC, e.CSPD_CAT, 
			    e.MEPE_ELIG_IND, g.GRGR_NAME, sg.SGSG_NAME, sg.SGSG_ID, sg.SGSG_ORIG_EFF_DT, sg.SGSG_TERM_DT, g.GRGR_MCTR_TYPE , e.GRGR_CK,pdesc.PDDS_MCTR_VAL1,mctr.mctr_desc,e.MEPE_PLAN_ENTRY_DT,e.MEPE_CREATE_DTM,m.MEME_CK, g.GRGR_PHONE
                from CMC_MEPE_PRCS_ELIG e 
                inner join CMC_MEME_MEMBER m on e.MEME_CK = m.MEME_CK and e.MEPE_ELIG_IND = 'Y' 
                inner join CMC_SBSB_SUBSC s on m.SBSB_CK = s.SBSB_CK 
                left outer join CMC_SGSG_SUB_GROUP sg on e.SGSG_CK = sg.SGSG_CK 
                left outer join CMC_GRGR_GROUP g on e.GRGR_CK = g.GRGR_CK 
                left outer join AGP.CCTR_PRODUCT p on e.PDPD_ID = p.PRODUCT_ID and sg.sgsg_mctr_type=p.market_cd 
                left outer join CMC_PLDS_PLAN_DESC pland ON e.cspi_id = pland.cspi_id
                LEFT OUTER JOIN FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT
                left outer join CMC_PDDS_PROD_DESC pdesc  on e.pdpd_id = pdesc.pdpd_id
                left outer join  cmc_mctr_cd_trans mctr on mctr.mctr_value = pdesc.PDDS_MCTR_VAL1 and mctr.mctr_entity = 'PDDS' and mctr.MCTR_TYPE = 'VAL'
                where s.SBSB_ID =?
                order by e.MEPE_EFF_DT DESC
            </pre></blockquote></p>
     * @param amerigroupID Amerigroup ID of the member
     * @return A <tt>List</tt> of <tt>FacetsMemberEligibilityDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberEligibilityDto> getAllEligibilitiesByAmerigroupID(String amerigroupID);    

 
		
		
    /**
     * <p>Get a members current eligibilities using the medicaid id</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
			    select m.MEME_FIRST_NAME, m.MEME_LAST_NAME, CONCAT(m.MEME_LAST_NAME, m.MEME_TITLE) as FULL_LAST_NAME, m.MEME_BIRTH_DT, pd.LOBD_ID, s.SBSB_ID, s.SBSB_CK, e.MEPE_EFF_DT, e.MEPE_TERM_DT, e.CSCS_ID, e.PDPD_ID, e.CSPI_ID, pland.PLDS_DESC, g.GRGR_ID, sg.SGSG_MCTR_TYPE, m.MEME_MEDCD_NO,m.MEME_HICN, p.NAME, p.GENERAL_DESC, e.CSPD_CAT, 
			    e.MEPE_ELIG_IND, g.GRGR_NAME, sg.SGSG_NAME, sg.SGSG_ID, sg.SGSG_ORIG_EFF_DT, sg.SGSG_TERM_DT, g.GRGR_MCTR_TYPE , e.GRGR_CK,pdesc.PDDS_MCTR_VAL1,mctr.mctr_desc,e.MEPE_PLAN_ENTRY_DT,e.MEPE_CREATE_DTM,m.MEME_CK, g.GRGR_PHONE
                from CMC_MEPE_PRCS_ELIG e 
                inner join CMC_MEME_MEMBER m on e.MEME_CK = m.MEME_CK and e.MEPE_ELIG_IND = 'Y' 
                inner join CMC_SBSB_SUBSC s on m.SBSB_CK = s.SBSB_CK 
                left outer join CMC_SGSG_SUB_GROUP sg on e.SGSG_CK = sg.SGSG_CK 
                left outer join CMC_GRGR_GROUP g on e.GRGR_CK = g.GRGR_CK 
                left outer join AGP.CCTR_PRODUCT p on e.PDPD_ID = p.PRODUCT_ID and sg.sgsg_mctr_type=p.market_cd 
                left outer join CMC_PLDS_PLAN_DESC pland ON e.cspi_id = pland.cspi_id
                LEFT OUTER JOIN FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT
                left outer join CMC_PDDS_PROD_DESC pdesc  on e.pdpd_id = pdesc.pdpd_id
                left outer join  cmc_mctr_cd_trans mctr on mctr.mctr_value = pdesc.PDDS_MCTR_VAL1 and mctr.mctr_entity = 'PDDS' and mctr.MCTR_TYPE = 'VAL'
                where (m.MEME_MEDCD_NO =?) and g.grgr_mctr_type in ('MDCD', 'MDDD') and g.grgr_id like 'INMCD%' order by e.MEPE_EFF_DT desc
            </pre></blockquote></p>
     * @param medicaidId Medicaid ID of the member
     * @return A <tt>List</tt> of <tt>FacetsMemberEligibilityDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberEligibilityDto> getAllEligibilityByINMedicaidID(String medicaidId);    

 
		
		
    /**
     * <p>Get a members current eligibilities using the medicaid id</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
			    select m.MEME_FIRST_NAME, m.MEME_LAST_NAME, CONCAT(m.MEME_LAST_NAME, m.MEME_TITLE) as FULL_LAST_NAME, m.MEME_BIRTH_DT, pd.LOBD_ID, s.SBSB_ID, s.SBSB_CK, e.MEPE_EFF_DT, e.MEPE_TERM_DT, e.CSCS_ID, e.PDPD_ID, e.CSPI_ID, pland.PLDS_DESC, g.GRGR_ID, sg.SGSG_MCTR_TYPE, m.MEME_MEDCD_NO,m.MEME_HICN, p.NAME, p.GENERAL_DESC, e.CSPD_CAT, 
			    e.MEPE_ELIG_IND, g.GRGR_NAME, sg.SGSG_NAME, sg.SGSG_ID, sg.SGSG_ORIG_EFF_DT, sg.SGSG_TERM_DT, g.GRGR_MCTR_TYPE , e.GRGR_CK,pdesc.PDDS_MCTR_VAL1,mctr.mctr_desc,e.MEPE_PLAN_ENTRY_DT,e.MEPE_CREATE_DTM,m.MEME_CK, g.GRGR_PHONE
                from CMC_MEPE_PRCS_ELIG e 
                inner join CMC_MEME_MEMBER m on e.MEME_CK = m.MEME_CK and e.MEPE_ELIG_IND = 'Y' 
                inner join CMC_SBSB_SUBSC s on m.SBSB_CK = s.SBSB_CK 
                left outer join CMC_SGSG_SUB_GROUP sg on e.SGSG_CK = sg.SGSG_CK 
                left outer join CMC_GRGR_GROUP g on e.GRGR_CK = g.GRGR_CK 
                left outer join AGP.CCTR_PRODUCT p on e.PDPD_ID = p.PRODUCT_ID and sg.sgsg_mctr_type=p.market_cd 
                left outer join CMC_PLDS_PLAN_DESC pland ON e.cspi_id = pland.cspi_id
                LEFT OUTER JOIN FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT
                left outer join CMC_PDDS_PROD_DESC pdesc  on e.pdpd_id = pdesc.pdpd_id
                left outer join  cmc_mctr_cd_trans mctr on mctr.mctr_value = pdesc.PDDS_MCTR_VAL1 and mctr.mctr_entity = 'PDDS' and mctr.MCTR_TYPE = 'VAL'
                where (m.MEME_MEDCD_NO =?) and g.grgr_mctr_type in ('MDCD', 'MDDD') order by e.MEPE_EFF_DT desc
            </pre></blockquote></p>
     * @param medicaidId Medicaid ID of the member
     * @return A <tt>List</tt> of <tt>FacetsMemberEligibilityDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberEligibilityDto> getAllEligibilityByMedicaidID(String medicaidId);    

 
		
		
    /**
     * <p>Get a members current eligibilities using the medicaid id</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
			    select m.MEME_FIRST_NAME, m.MEME_LAST_NAME, CONCAT(m.MEME_LAST_NAME, m.MEME_TITLE) as FULL_LAST_NAME, m.MEME_BIRTH_DT, pd.LOBD_ID, s.SBSB_ID, s.SBSB_CK, e.MEPE_EFF_DT, e.MEPE_TERM_DT, e.CSCS_ID, e.PDPD_ID, e.CSPI_ID, pland.PLDS_DESC, g.GRGR_ID, sg.SGSG_MCTR_TYPE, m.MEME_MEDCD_NO,m.MEME_HICN, p.NAME, p.GENERAL_DESC, e.CSPD_CAT, 
			    e.MEPE_ELIG_IND, g.GRGR_NAME, sg.SGSG_NAME, sg.SGSG_ID, sg.SGSG_ORIG_EFF_DT, sg.SGSG_TERM_DT, g.GRGR_MCTR_TYPE , e.GRGR_CK,pdesc.PDDS_MCTR_VAL1,mctr.mctr_desc,e.MEPE_PLAN_ENTRY_DT,e.MEPE_CREATE_DTM,m.MEME_CK, g.GRGR_PHONE
                from CMC_MEPE_PRCS_ELIG e 
                inner join CMC_MEME_MEMBER m on e.MEME_CK = m.MEME_CK and e.MEPE_ELIG_IND = 'Y' 
                inner join CMC_SBSB_SUBSC s on m.SBSB_CK = s.SBSB_CK 
                left outer join CMC_SGSG_SUB_GROUP sg on e.SGSG_CK = sg.SGSG_CK 
                left outer join CMC_GRGR_GROUP g on e.GRGR_CK = g.GRGR_CK 
                left outer join AGP.CCTR_PRODUCT p on e.PDPD_ID = p.PRODUCT_ID and sg.sgsg_mctr_type=p.market_cd 
                left outer join CMC_PLDS_PLAN_DESC pland ON e.cspi_id = pland.cspi_id
                LEFT OUTER JOIN FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT
                left outer join CMC_PDDS_PROD_DESC pdesc  on e.pdpd_id = pdesc.pdpd_id
                left outer join  cmc_mctr_cd_trans mctr on mctr.mctr_value = pdesc.PDDS_MCTR_VAL1 and mctr.mctr_entity = 'PDDS' and mctr.MCTR_TYPE = 'VAL'
                where (m.MEME_MEDCD_NO =?) and g.grgr_mctr_type in ('MDCD', 'MDDD', 'MDCR') order by e.MEPE_EFF_DT desc
            </pre></blockquote></p>
     * @param medicaidId Medicaid ID of the member
     * @return A <tt>List</tt> of <tt>FacetsMemberEligibilityDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberEligibilityDto> getAllEligibilityByMedicaidIDWithMDCRGrpType(String medicaidId);    

 
		
		
    /**
     * <p>Get a members current eligibilities using the medicare id</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
			    select m.MEME_FIRST_NAME, m.MEME_LAST_NAME, CONCAT(m.MEME_LAST_NAME, m.MEME_TITLE) as FULL_LAST_NAME, m.MEME_BIRTH_DT, pd.LOBD_ID, s.SBSB_ID, s.SBSB_CK, e.MEPE_EFF_DT, e.MEPE_TERM_DT, e.CSCS_ID, e.PDPD_ID, e.CSPI_ID, pland.PLDS_DESC, g.GRGR_ID, sg.SGSG_MCTR_TYPE, m.MEME_MEDCD_NO,m.MEME_HICN, p.NAME, p.GENERAL_DESC, e.CSPD_CAT, 
			    e.MEPE_ELIG_IND, g.GRGR_NAME, sg.SGSG_NAME, sg.SGSG_ID, sg.SGSG_ORIG_EFF_DT, sg.SGSG_TERM_DT, g.GRGR_MCTR_TYPE , e.GRGR_CK ,pdesc.PDDS_MCTR_VAL1,mctr.mctr_desc,e.MEPE_PLAN_ENTRY_DT,e.MEPE_CREATE_DTM,m.MEME_CK, g.GRGR_PHONE
                from CMC_MEPE_PRCS_ELIG e 
                inner join CMC_MEME_MEMBER m on e.MEME_CK = m.MEME_CK and e.MEPE_ELIG_IND = 'Y' 
                inner join CMC_SBSB_SUBSC s on m.SBSB_CK = s.SBSB_CK 
                left outer join CMC_SGSG_SUB_GROUP sg on e.SGSG_CK = sg.SGSG_CK 
                left outer join CMC_GRGR_GROUP g on g.GRGR_CK = sg.GRGR_CK 
                left outer join AGP.CCTR_PRODUCT p on e.PDPD_ID = p.PRODUCT_ID and sg.sgsg_mctr_type=p.market_cd 
                left outer join CMC_PLDS_PLAN_DESC pland ON e.cspi_id = pland.cspi_id
                LEFT OUTER JOIN FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT
                left outer join CMC_PDDS_PROD_DESC pdesc  on e.pdpd_id = pdesc.pdpd_id
                left outer join  cmc_mctr_cd_trans mctr on mctr.mctr_value = pdesc.PDDS_MCTR_VAL1 and mctr.mctr_entity = 'PDDS' and mctr.MCTR_TYPE = 'VAL'
                where (m.MEME_HICN =?)  and g.grgr_mctr_type in ('MDCR', 'MDDD') order by e.MEPE_EFF_DT desc
            </pre></blockquote></p>
     * @param medicareId Medicare ID of the member
     * @return A <tt>List</tt> of <tt>FacetsMemberEligibilityDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberEligibilityDto> getAllEligibilityByCurrentMedicareID(String medicareId);    

 
		
		
    /**
     * <p>Get a members current eligibilities using the medicare id</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
			    select m.MEME_FIRST_NAME, m.MEME_LAST_NAME, CONCAT(m.MEME_LAST_NAME, m.MEME_TITLE) as FULL_LAST_NAME, m.MEME_BIRTH_DT, pd.LOBD_ID, s.SBSB_ID, s.SBSB_CK, e.MEPE_EFF_DT, e.MEPE_TERM_DT, e.CSCS_ID, e.PDPD_ID, e.CSPI_ID, pland.PLDS_DESC, g.GRGR_ID, sg.SGSG_MCTR_TYPE, m.MEME_MEDCD_NO,m.MEME_HICN, p.NAME, p.GENERAL_DESC, e.CSPD_CAT, 
			    e.MEPE_ELIG_IND, g.GRGR_NAME, sg.SGSG_NAME, sg.SGSG_ID, sg.SGSG_ORIG_EFF_DT, sg.SGSG_TERM_DT, g.GRGR_MCTR_TYPE , e.GRGR_CK ,pdesc.PDDS_MCTR_VAL1,mctr.mctr_desc,e.MEPE_PLAN_ENTRY_DT,e.MEPE_CREATE_DTM,m.MEME_CK, g.GRGR_PHONE
                from CMC_MEPE_PRCS_ELIG e 
                inner join CMC_MEME_MEMBER m on e.MEME_CK = m.MEME_CK and e.MEPE_ELIG_IND = 'Y' 
                inner join CMC_SBSB_SUBSC s on m.SBSB_CK = s.SBSB_CK 
                left join CMC_MECR_NO_XREF x on x.MEME_CK = M.MEME_CK
                left outer join CMC_SGSG_SUB_GROUP sg on e.SGSG_CK = sg.SGSG_CK 
                left outer join CMC_GRGR_GROUP g on g.GRGR_CK = sg.GRGR_CK 
                left outer join AGP.CCTR_PRODUCT p on e.PDPD_ID = p.PRODUCT_ID and sg.sgsg_mctr_type=p.market_cd 
                left outer join CMC_PLDS_PLAN_DESC pland ON e.cspi_id = pland.cspi_id
                LEFT OUTER JOIN FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT
                left outer join CMC_PDDS_PROD_DESC pdesc  on e.pdpd_id = pdesc.pdpd_id
                left outer join  cmc_mctr_cd_trans mctr on mctr.mctr_value = pdesc.PDDS_MCTR_VAL1 and mctr.mctr_entity = 'PDDS' and mctr.MCTR_TYPE = 'VAL'
                where x.MECR_NO_ORIG = ? and g.grgr_mctr_type in ('MDCR', 'MDDD') order by e.MEPE_EFF_DT desc
            </pre></blockquote></p>
     * @param medicareId Medicare ID of the member
     * @return A <tt>List</tt> of <tt>FacetsMemberEligibilityDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberEligibilityDto> getAllEligibilityByOldMedicareID(String medicareId);    

 
		
		
    /**
     * <p>Get a members past, current, and future eligibility using the amerigroup id, sorted with most to least recent</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
			    select m.MEME_FIRST_NAME, m.MEME_LAST_NAME, CONCAT(m.MEME_LAST_NAME, m.MEME_TITLE) as FULL_LAST_NAME, m.MEME_BIRTH_DT, pd.LOBD_ID, s.SBSB_ID, s.SBSB_CK, e.MEPE_EFF_DT, e.MEPE_TERM_DT, e.CSCS_ID, e.PDPD_ID, e.CSPI_ID, pland.PLDS_DESC, g.GRGR_ID, sg.SGSG_MCTR_TYPE, m.MEME_MEDCD_NO,m.MEME_HICN, p.NAME, p.GENERAL_DESC, e.CSPD_CAT, 
			    e.MEPE_ELIG_IND, g.GRGR_NAME, sg.SGSG_NAME, sg.SGSG_ID, sg.SGSG_ORIG_EFF_DT, sg.SGSG_TERM_DT, g.GRGR_MCTR_TYPE , e.GRGR_CK ,pdesc.PDDS_MCTR_VAL1,mctr.mctr_desc,e.MEPE_PLAN_ENTRY_DT,e.MEPE_CREATE_DTM,m.MEME_CK, g.GRGR_PHONE
                from CMC_MEPE_PRCS_ELIG e 
                inner join CMC_MEME_MEMBER m on e.MEME_CK = m.MEME_CK  
                inner join CMC_SBSB_SUBSC s on m.SBSB_CK = s.SBSB_CK 
                left outer join CMC_SGSG_SUB_GROUP sg on e.SGSG_CK = sg.SGSG_CK 
                left outer join CMC_GRGR_GROUP g on e.GRGR_CK = g.GRGR_CK 
                left outer join AGP.CCTR_PRODUCT p on e.PDPD_ID = p.PRODUCT_ID and sg.sgsg_mctr_type=p.market_cd 
                left outer join CMC_PLDS_PLAN_DESC pland ON e.cspi_id = pland.cspi_id
                LEFT OUTER JOIN FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT
                left outer join CMC_PDDS_PROD_DESC pdesc  on e.pdpd_id = pdesc.pdpd_id
                left outer join  cmc_mctr_cd_trans mctr on mctr.mctr_value = pdesc.PDDS_MCTR_VAL1 and mctr.mctr_entity = 'PDDS' and mctr.MCTR_TYPE = 'VAL'
                where s.SBSB_ID =?
                order by e.MEPE_EFF_DT DESC
            </pre></blockquote></p>
     * @param amerigroupID Amerigroup ID of the member
     * @return A <tt>List</tt> of <tt>FacetsMemberEligibilityDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberEligibilityDto> getAllEligibilitiesWithNoEligibilityCheckByAmerigroupID(String amerigroupID);    

 
		
		
    /**
     * <p>Get a members current eligibilities using the medicaid id</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
			    select m.MEME_FIRST_NAME, m.MEME_LAST_NAME, CONCAT(m.MEME_LAST_NAME, m.MEME_TITLE) as FULL_LAST_NAME, m.MEME_BIRTH_DT, pd.LOBD_ID, s.SBSB_ID, s.SBSB_CK, e.MEPE_EFF_DT, e.MEPE_TERM_DT, e.CSCS_ID, e.PDPD_ID, e.CSPI_ID, pland.PLDS_DESC, g.GRGR_ID, sg.SGSG_MCTR_TYPE, m.MEME_MEDCD_NO,m.MEME_HICN, p.NAME, p.GENERAL_DESC, e.CSPD_CAT, 
			    e.MEPE_ELIG_IND, g.GRGR_NAME, sg.SGSG_NAME, sg.SGSG_ID, sg.SGSG_ORIG_EFF_DT, sg.SGSG_TERM_DT, g.GRGR_MCTR_TYPE , e.GRGR_CK ,pdesc.PDDS_MCTR_VAL1,mctr.mctr_desc,e.MEPE_PLAN_ENTRY_DT,e.MEPE_CREATE_DTM,m.MEME_CK, g.GRGR_PHONE
                from CMC_MEPE_PRCS_ELIG e 
                inner join CMC_MEME_MEMBER m on e.MEME_CK = m.MEME_CK  
                inner join CMC_SBSB_SUBSC s on m.SBSB_CK = s.SBSB_CK 
                left outer join CMC_SGSG_SUB_GROUP sg on e.SGSG_CK = sg.SGSG_CK 
                left outer join CMC_GRGR_GROUP g on g.GRGR_CK = sg.GRGR_CK 
                left outer join AGP.CCTR_PRODUCT p on e.PDPD_ID = p.PRODUCT_ID and sg.sgsg_mctr_type=p.market_cd 
                left outer join CMC_PLDS_PLAN_DESC pland ON e.cspi_id = pland.cspi_id
                LEFT OUTER JOIN FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT
                left outer join CMC_PDDS_PROD_DESC pdesc  on e.pdpd_id = pdesc.pdpd_id
                left outer join  cmc_mctr_cd_trans mctr on mctr.mctr_value = pdesc.PDDS_MCTR_VAL1 and mctr.mctr_entity = 'PDDS' and mctr.MCTR_TYPE = 'VAL'
                where (m.MEME_MEDCD_NO =?) and g.grgr_mctr_type in ('MDCD', 'MDDD') and g.grgr_id like 'INMCD%' order by e.MEPE_EFF_DT desc
            </pre></blockquote></p>
     * @param medicaidId Medicaid ID of the member
     * @return A <tt>List</tt> of <tt>FacetsMemberEligibilityDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberEligibilityDto> getAllEligibilityWithNoEligibilityCheckByINMedicaidID(String medicaidId);    

 
		
		
    /**
     * <p>Get a members current eligibilities using the medicaid id</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
			    select m.MEME_FIRST_NAME, m.MEME_LAST_NAME, CONCAT(m.MEME_LAST_NAME, m.MEME_TITLE) as FULL_LAST_NAME, m.MEME_BIRTH_DT, pd.LOBD_ID, s.SBSB_ID, s.SBSB_CK, e.MEPE_EFF_DT, e.MEPE_TERM_DT, e.CSCS_ID, e.PDPD_ID, e.CSPI_ID, pland.PLDS_DESC, g.GRGR_ID, sg.SGSG_MCTR_TYPE, m.MEME_MEDCD_NO,m.MEME_HICN, p.NAME, p.GENERAL_DESC, e.CSPD_CAT, 
			    e.MEPE_ELIG_IND, g.GRGR_NAME, sg.SGSG_NAME, sg.SGSG_ID, sg.SGSG_ORIG_EFF_DT, sg.SGSG_TERM_DT, g.GRGR_MCTR_TYPE , e.GRGR_CK ,pdesc.PDDS_MCTR_VAL1,mctr.mctr_desc,e.MEPE_PLAN_ENTRY_DT,e.MEPE_CREATE_DTM,m.MEME_CK, g.GRGR_PHONE
                from CMC_MEPE_PRCS_ELIG e 
                inner join CMC_MEME_MEMBER m on e.MEME_CK = m.MEME_CK  
                inner join CMC_SBSB_SUBSC s on m.SBSB_CK = s.SBSB_CK 
                left outer join CMC_SGSG_SUB_GROUP sg on e.SGSG_CK = sg.SGSG_CK 
                left outer join CMC_GRGR_GROUP g on g.GRGR_CK = sg.GRGR_CK 
                left outer join AGP.CCTR_PRODUCT p on e.PDPD_ID = p.PRODUCT_ID and sg.sgsg_mctr_type=p.market_cd 
                left outer join CMC_PLDS_PLAN_DESC pland ON e.cspi_id = pland.cspi_id
                LEFT OUTER JOIN FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT
                left outer join CMC_PDDS_PROD_DESC pdesc  on e.pdpd_id = pdesc.pdpd_id
                left outer join  cmc_mctr_cd_trans mctr on mctr.mctr_value = pdesc.PDDS_MCTR_VAL1 and mctr.mctr_entity = 'PDDS' and mctr.MCTR_TYPE = 'VAL'
                where (m.MEME_MEDCD_NO =?) and g.grgr_mctr_type in ('MDCD', 'MDDD') order by e.MEPE_EFF_DT desc
            </pre></blockquote></p>
     * @param medicaidId Medicaid ID of the member
     * @return A <tt>List</tt> of <tt>FacetsMemberEligibilityDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberEligibilityDto> getAllEligibilityWithNoEligibilityCheckByMedicaidID(String medicaidId);    

 
		
		
    /**
     * <p>Get a members current eligibilities using the medicaid id</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
			    select m.MEME_FIRST_NAME, m.MEME_LAST_NAME, CONCAT(m.MEME_LAST_NAME, m.MEME_TITLE) as FULL_LAST_NAME, m.MEME_BIRTH_DT, pd.LOBD_ID, s.SBSB_ID, s.SBSB_CK, e.MEPE_EFF_DT, e.MEPE_TERM_DT, e.CSCS_ID, e.PDPD_ID, e.CSPI_ID, pland.PLDS_DESC, g.GRGR_ID, sg.SGSG_MCTR_TYPE, m.MEME_MEDCD_NO,m.MEME_HICN, p.NAME, p.GENERAL_DESC, e.CSPD_CAT, 
			    e.MEPE_ELIG_IND, g.GRGR_NAME, sg.SGSG_NAME, sg.SGSG_ID, sg.SGSG_ORIG_EFF_DT, sg.SGSG_TERM_DT, g.GRGR_MCTR_TYPE , e.GRGR_CK ,pdesc.PDDS_MCTR_VAL1,mctr.mctr_desc,e.MEPE_PLAN_ENTRY_DT,e.MEPE_CREATE_DTM,m.MEME_CK, g.GRGR_PHONE
                from CMC_MEPE_PRCS_ELIG e 
                inner join CMC_MEME_MEMBER m on e.MEME_CK = m.MEME_CK  
                inner join CMC_SBSB_SUBSC s on m.SBSB_CK = s.SBSB_CK 
                left outer join CMC_SGSG_SUB_GROUP sg on e.SGSG_CK = sg.SGSG_CK 
                left outer join CMC_GRGR_GROUP g on g.GRGR_CK = sg.GRGR_CK 
                left outer join AGP.CCTR_PRODUCT p on e.PDPD_ID = p.PRODUCT_ID and sg.sgsg_mctr_type=p.market_cd 
                left outer join CMC_PLDS_PLAN_DESC pland ON e.cspi_id = pland.cspi_id
                LEFT OUTER JOIN FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT
                left outer join CMC_PDDS_PROD_DESC pdesc  on e.pdpd_id = pdesc.pdpd_id
                left outer join  cmc_mctr_cd_trans mctr on mctr.mctr_value = pdesc.PDDS_MCTR_VAL1 and mctr.mctr_entity = 'PDDS' and mctr.MCTR_TYPE = 'VAL'
                where (m.MEME_MEDCD_NO =?) and g.grgr_mctr_type in ('MDCD', 'MDDD', 'MDCR') order by e.MEPE_EFF_DT desc
            </pre></blockquote></p>
     * @param medicaidId Medicaid ID of the member
     * @return A <tt>List</tt> of <tt>FacetsMemberEligibilityDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberEligibilityDto> getAllEligibilityWithNoEligibilityCheckByMedicaidIDWithMdcrGrpType(String medicaidId);    

 
		
		
    /**
     * <p>Get a members current eligibilities using the medicare id</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
			    select m.MEME_FIRST_NAME, m.MEME_LAST_NAME, CONCAT(m.MEME_LAST_NAME, m.MEME_TITLE) as FULL_LAST_NAME, m.MEME_BIRTH_DT, pd.LOBD_ID, s.SBSB_ID, s.SBSB_CK, e.MEPE_EFF_DT, e.MEPE_TERM_DT, e.CSCS_ID, e.PDPD_ID, e.CSPI_ID, pland.PLDS_DESC, g.GRGR_ID, sg.SGSG_MCTR_TYPE, m.MEME_MEDCD_NO,m.MEME_HICN, p.NAME, p.GENERAL_DESC, e.CSPD_CAT, 
			    e.MEPE_ELIG_IND, g.GRGR_NAME, sg.SGSG_NAME, sg.SGSG_ID, sg.SGSG_ORIG_EFF_DT, sg.SGSG_TERM_DT, g.GRGR_MCTR_TYPE , e.GRGR_CK,pdesc.PDDS_MCTR_VAL1,mctr.mctr_desc,e.MEPE_PLAN_ENTRY_DT,e.MEPE_CREATE_DTM,m.MEME_CK, g.GRGR_PHONE
                from CMC_MEPE_PRCS_ELIG e 
                inner join CMC_MEME_MEMBER m on e.MEME_CK = m.MEME_CK  
                inner join CMC_SBSB_SUBSC s on m.SBSB_CK = s.SBSB_CK 
                left outer join CMC_SGSG_SUB_GROUP sg on e.SGSG_CK = sg.SGSG_CK 
                left outer join CMC_GRGR_GROUP g on g.GRGR_CK = sg.GRGR_CK 
                left outer join AGP.CCTR_PRODUCT p on e.PDPD_ID = p.PRODUCT_ID and sg.sgsg_mctr_type=p.market_cd 
                left outer join CMC_PLDS_PLAN_DESC pland ON e.cspi_id = pland.cspi_id
                LEFT OUTER JOIN FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT
                left outer join CMC_PDDS_PROD_DESC pdesc  on e.pdpd_id = pdesc.pdpd_id
                left outer join  cmc_mctr_cd_trans mctr on mctr.mctr_value = pdesc.PDDS_MCTR_VAL1 and mctr.mctr_entity = 'PDDS' and mctr.MCTR_TYPE = 'VAL'
                where (m.MEME_HICN =?) and g.grgr_mctr_type in ('MDCR', 'MDDD') order by e.MEPE_EFF_DT desc
            </pre></blockquote></p>
     * @param medicareId Medicare ID of the member
     * @return A <tt>List</tt> of <tt>FacetsMemberEligibilityDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberEligibilityDto> getAllEligibilityWithNoEligibilityCheckByCurrentMedicareID(String medicareId);    

 
		
		
    /**
     * <p>Get a members current eligibilities using the medicare id</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
			    select m.MEME_FIRST_NAME, m.MEME_LAST_NAME, CONCAT(m.MEME_LAST_NAME, m.MEME_TITLE) as FULL_LAST_NAME, m.MEME_BIRTH_DT, pd.LOBD_ID, s.SBSB_ID, s.SBSB_CK, e.MEPE_EFF_DT, e.MEPE_TERM_DT, e.CSCS_ID, e.PDPD_ID, e.CSPI_ID, pland.PLDS_DESC, g.GRGR_ID, sg.SGSG_MCTR_TYPE, m.MEME_MEDCD_NO,m.MEME_HICN, p.NAME, p.GENERAL_DESC, e.CSPD_CAT, 
			    e.MEPE_ELIG_IND, g.GRGR_NAME, sg.SGSG_NAME, sg.SGSG_ID, sg.SGSG_ORIG_EFF_DT, sg.SGSG_TERM_DT, g.GRGR_MCTR_TYPE , e.GRGR_CK,pdesc.PDDS_MCTR_VAL1,mctr.mctr_desc,e.MEPE_PLAN_ENTRY_DT,e.MEPE_CREATE_DTM,m.MEME_CK, g.GRGR_PHONE
                from CMC_MEPE_PRCS_ELIG e 
                inner join CMC_MEME_MEMBER m on e.MEME_CK = m.MEME_CK  
                inner join CMC_SBSB_SUBSC s on m.SBSB_CK = s.SBSB_CK 
                left join CMC_MECR_NO_XREF x on x.MEME_CK = M.MEME_CK
                left outer join CMC_SGSG_SUB_GROUP sg on e.SGSG_CK = sg.SGSG_CK 
                left outer join CMC_GRGR_GROUP g on g.GRGR_CK = sg.GRGR_CK 
                left outer join AGP.CCTR_PRODUCT p on e.PDPD_ID = p.PRODUCT_ID and sg.sgsg_mctr_type=p.market_cd 
                left outer join CMC_PLDS_PLAN_DESC pland ON e.cspi_id = pland.cspi_id
                LEFT OUTER JOIN FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT
                left outer join CMC_PDDS_PROD_DESC pdesc  on e.pdpd_id = pdesc.pdpd_id
                left outer join  cmc_mctr_cd_trans mctr on mctr.mctr_value = pdesc.PDDS_MCTR_VAL1 and mctr.mctr_entity = 'PDDS' and mctr.MCTR_TYPE = 'VAL'
                where x.MECR_NO_ORIG = ? and g.grgr_mctr_type in ('MDCR', 'MDDD') order by e.MEPE_EFF_DT desc
            </pre></blockquote></p>
     * @param medicareId Medicare ID of the member
     * @return A <tt>List</tt> of <tt>FacetsMemberEligibilityDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberEligibilityDto> getAllEligibilityWithNoEligibilityCheckByOldMedicareID(String medicareId);    

 
		
		
    /**
     * <p>Get the home address for a member</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>select a.sbad_type, a.sbad_addr1, a.sbad_addr2, a.sbad_addr3, a.sbad_city, a.sbad_county, a.sbad_state, a.sbad_zip, 
						a.sbad_phone, a.sbad_phone_ext, a.sbad_email, a.sbad_fax, a.sbad_fax_ext, s.SBAD_TYPE_HOME, s.SBAD_TYPE_MAIL   
				  from CMC_SBSB_SUBSC s
				  join CMC_SBAD_ADDR a on a.SBSB_CK = s.SBSB_CK and a.SBAD_TYPE = s.SBAD_TYPE_HOME
				where s.sbsb_id = ?
			</pre></blockquote></p>
     * @param agpID The Amerigroup ID of the member
     * @return the <tt>FacetsMemberAddressDto</tt> object that matches the
     * selection criteria, or null if there is no match.
     */
    public abstract FacetsMemberAddressDto getHomeAddress(String agpID);    

 
		
		
    /**
     * <p>Get the Dual Citizenship details by Subscriber ID</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
			WITH TEMP AS
			(
				SELECT DISTINCT 
		            DP.dual_link, DP.dual_type, 
	            	SUB.sbsb_id as requestedsbsbId,
	            	GRP.grgr_id as requestedgrgrId, 
	            	MEM.meme_ck as requestedmemeCk,
	            	SUB2.sbsb_id as targetsbsbId, 
	            	GRP2.grgr_id as targetgrgrId,
	            	MEM2.meme_ck as targetmemeCk,
	            	DP.DUAL_SPN_START_DT, DP.DUAL_SPN_END_DT,
	            	DD.dual_desc, MEDICAID_LEVEL, COST_SHARE_CAT 
				FROM FACETS.CMC_MEME_MEMBER MEM 
	 			INNER JOIN FACETS.CMC_SBSB_SUBSC SUB on SUB.sbsb_ck = MEM.sbsb_ck
	   			INNER JOIN FACETS.CMC_GRGR_GROUP GRP on GRP.grgr_ck = MEM.grgr_ck
	    		INNER JOIN AGP.DUAL_POPULATION_SPN DP on DP.meme_ck = MEM.meme_ck  AND DP.DUAL_LINK > 0
	    		INNER JOIN AGP.DUAL_POPULATION_SPN DP2 on DP2.dual_link = DP.dual_link AND dp2.meme_ck != dp.meme_ck AND DP2.DUAL_LINK > 0
		        INNER JOIN AGP.DUAL_DESC DD on DD.dual_type = DP.dual_type 
		        LEFT OUTER JOIN AGP.DUAL_MEDICAID_AID_CAT_SPN DMACS on DP.dual_pop_spn_id = DMACS.dual_spn_id 
	    		INNER JOIN FACETS.CMC_MEME_MEMBER MEM2 on MEM2.meme_ck = DP2.meme_ck 
	   			INNER JOIN FACETS.CMC_SBSB_SUBSC SUB2 on SUB2.sbsb_ck = MEM2.sbsb_ck
	    		INNER JOIN FACETS.CMC_GRGR_GROUP GRP2 on GRP2.grgr_ck = MEM2.grgr_ck 
				WHERE SUB.sbsb_id = ?
				
	    		UNION 
	    		
				SELECT DISTINCT 
		            0, DE.dual_type, 
	            	SUB.sbsb_id as requestedsbsbId,
	            	GRP.grgr_id as requestedgrgrId, 
	            	MEM.meme_ck as requestedmemeCk,
	            	'' as targetsbsbId, 
	            	'' as targetgrgrId,
	            	0 as targetmemeCk,
	            	DE.DUAL_SPN_START_DT, DE.DUAL_SPN_END_DT,
					DD.dual_desc, MEDICAID_LEVEL, COST_SHARE_CAT 
				FROM FACETS.CMC_MEME_MEMBER MEM 
	     		INNER JOIN FACETS.CMC_SBSB_SUBSC SUB on SUB.sbsb_ck = MEM.sbsb_ck 
	     		INNER JOIN FACETS.CMC_GRGR_GROUP GRP on GRP.grgr_ck = MEM.grgr_ck
				INNER JOIN AGP.DUAL_ELIGIBLE_SPN DE on DE.meme_ck = MEM.meme_ck
		        INNER JOIN AGP.DUAL_DESC DD on DD.dual_type = DE.dual_type 
		        LEFT OUTER JOIN AGP.DUAL_MEDICAID_AID_CAT_SPN DMACS on DE.dual_elig_spn_id = DMACS.dual_spn_id 
				WHERE SUB.sbsb_id = ?
				
				UNION
				
				select DISTINCT DP.dual_link, DP.dual_type,SUB.sbsb_id as requestedsbsbId,GRP.grgr_id as requestedgrgrId,
        MEM.meme_ck as requestedmemeCk,'' as targetsbsbId,'' as targetgrgrId,0 as targetmemeCk,DP.DUAL_SPN_START_DT, DP.DUAL_SPN_END_DT,DD.dual_desc, MEDICAID_LEVEL, COST_SHARE_CAT
        from FACETS.CMC_MEME_MEMBER MEM inner join FACETS.CMC_SBSB_SUBSC SUB on SUB.sbsb_ck = MEM.sbsb_ck 
        inner join FACETS.CMC_GRGR_GROUP GRP on GRP.grgr_ck = MEM.grgr_ck 
        inner join AGP.DUAL_POPULATION_SPN DP on DP.meme_ck = MEM.meme_ck and dual_link=-1 and dual_type='I'
        inner join AGP.DUAL_DESC DD on DD.dual_type = DP.dual_type
        left outer join AGP.DUAL_MEDICAID_AID_CAT_SPN DMACS on DP.dual_pop_spn_id = DMACS.dual_spn_id
        where SUB.sbsb_id = ?
				)
        		SELECT t.* FROM TEMP t 
        		order by t.DUAL_SPN_END_DT desc, t.dual_type ASC
			</pre></blockquote></p>
     * @param sbsbId Subscriber Id
     * @return A <tt>List</tt> of <tt>FacetsMemberDualCitizenshipDetailsDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberDualCitizenshipDetailsDto> getDualCitizenshipDetailsBySBSBIDwithMediciad(String sbsbId);    

 
		
		
    /**
     * <p>populate the Dual Citizenship AID Category name based on LAST_VER_DATEs and CREATE_DTM by MEME ID</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
			select  MEDICAID_LVL   
			from AGP.MCR_ENR_MEDICAID_LEVEL MEML 
			where meme_ck = ? 
			order by LAST_VER_DATE desc, create_dtm desc 
			</pre></blockquote></p>
     * @param memeCk member contrived key
     * @return A <tt>List</tt> of <tt>FacetsMemberDualCitizenshipAIDCategoryDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberDualCitizenshipAIDCategoryDto> getDualCitizenshipAIDCategoryByMemeCk(String memeCk);    

 
		
		
    /**
     * <p>Fetches the member details by sbrUid(SBSB_CK from Facets), eligibility effective date and eligibility termination date</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
			select
				m.MEME_FIRST_NAME , m.MEME_MID_INIT, m.MEME_LAST_NAME ,
				m.MEME_BIRTH_DT , m.MEME_SEX ,
				m.MEME_CK , m.MEME_HICN , m.MEME_MEDCD_NO, m.SBSB_CK,
				cspi.CSPI_ITS_PREFIX ,e.MEPE_EFF_DT , e.MEPE_TERM_DT ,
				e.PDPD_ID , e.CSPI_ID , e.CSCS_ID, e.MEPE_ELIG_IND ,
				s.SBSB_ID ,pd.LOBD_ID,g.grgr_ck, g.CICI_ID , g.GRGR_ID, 
				g.GRGR_MCTR_TYPE, sg.SGSG_MCTR_TYPE, sg.sgsg_ck
			from CMC_SBSB_SUBSC s
			inner join CMC_MEME_MEMBER m on m.SBSB_CK = s.SBSB_CK
			inner join CMC_MEPE_PRCS_ELIG e on e.MEME_CK = m.MEME_CK and e.MEPE_ELIG_IND = 'Y'
			inner join CMC_GRGR_GROUP g on e.GRGR_CK = g.GRGR_CK
			inner join FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT
			inner join CMC_CSPI_CS_PLAN cspi on cspi.GRGR_CK = e.GRGR_CK and cspi.CSCS_ID = e.CSCS_ID and cspi.CSPI_ID = e.CSPI_ID and cspi.CSPD_CAT = e.CSPD_CAT and e.MEPE_EFF_DT between cspi.CSPI_EFF_DT and cspi.CSPI_TERM_DT
			left outer join CMC_SGSG_SUB_GROUP sg on e.SGSG_CK = sg.SGSG_CK
			where s.sbsb_ck = ? and e.MEPE_EFF_DT = ? and e.MEPE_TERM_DT = ?
		</pre></blockquote></p>
     * @param sbrUid Member's Subscriber CK(SBSB_CK from Facets)
     * @param eligibilityEffDt Member's Eligibility Effective Date
     * @param eligibilityTermDt Member's Eligibility Termination Date
     * @return the <tt>FacetsMemberMemberDetailsDto</tt> object that matches the
     * selection criteria, or null if there is no match.
     */
    public abstract FacetsMemberMemberDetailsDto getEligibilityBySbrUidAndEligibilityDates(String sbrUid, Date eligibilityEffDt, Date eligibilityTermDt);    

 
		
		
    /**
     * <p>Get Member Claim Hold Info by sbruid</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
					SELECT S.SBSB_ID, MH.MEME_CK, MH.MECH_EFF_DT, MH.MECH_TERM_DT, MH.CLST_MCTR_REAS, 
						MEPE.MEPE_EFF_DT, MEPE.MEPE_TERM_DT, MEPE.MEPE_ELIG_IND
					FROM CMC_MECH_CLM_HOLD MH
					JOIN CMC_MEME_MEMBER M ON MH.MEME_CK = M.MEME_CK
					JOIN CMC_SBSB_SUBSC S ON S.sbsb_ck = M.sbsb_ck
					JOIN CMC_MEPE_PRCS_ELIG MEPE ON M.MEME_CK = MEPE.MEME_CK 
					WHERE S.SBSB_CK = ?  
						AND MH.CLST_MCTR_REAS = 'RETR' 
						AND MEPE.MEPE_ELIG_IND = 'Y' 
						AND MH.MECH_TERM_DT BETWEEN ? AND ? 
						order by MH.MECH_TERM_DT desc
			</pre></blockquote></p>
     * @param sbruid Member's SBSB_CK
     * @param effDate Member's Elig Eff Date
     * @param termDate Member's Elig Term Date
     * @return A <tt>List</tt> of <tt>FacetsMemberMemberClaimHoldInfoDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberMemberClaimHoldInfoDto> getMemberClaimHoldDetailsBySbruid(String sbruid, Date effDate, Date termDate);    

 
		
		
    /**
     * <p>gets the prefix from the given class, plan, grgrCk, cspdCat and with respective elig dates</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
				select CSPI_ITS_PREFIX from CMC_CSPI_CS_PLAN 
				where ? >= CSPI_EFF_DT and  ? <= CSPI_TERM_DT and GRGR_CK = ? and CSCS_ID = ? and CSPD_CAT = ? and CSPI_ID = ?
				order by CSPI_TERM_DT desc
			</pre></blockquote></p>
     * @param eligTermDt Eligibility Effective Date
     * @param eligEffDt Eligibility Termination Date
     * @param groupCk GRGR_CK
     * @param classId CSCS_ID
     * @param cspdCat CSPD_CAT
     * @param planId CSPI_ID
     * @return the <tt>FacetsMemberClassPlanPrefixDto</tt> object that matches the
     * selection criteria, or null if there is no match.
     */
    public abstract FacetsMemberClassPlanPrefixDto getPrefixByClassPlan(Date eligTermDt, Date eligEffDt, String groupCk, String classId, String cspdCat, String planId);    

 
		
		
    /**
     * <p>Get member medicaid brand by plan</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>SELECT BRAND_CD,BRAND_DESC,GCPP_PATTERN,MARKET_EFF_DT FROM AGP.MEM_MARKET_BRAND where regexp_like (?, gcpp_pattern) and sysdate between MARKET_EFF_DT and MARKET_TERM_DT and MARKET_BRAND_IND = 'Y'
			</pre></blockquote></p>
     * @param GCPProduct a concatenation of group, class, plan and product
     * @return A <tt>List</tt> of <tt>FacetsMemberMarketBrandDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberMarketBrandDto> getMemberMarketBrand(String GCPProduct);    

 
		
		
    /**
     * <p>Get member print brand by plan</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
				SELECT BRAND_CD,BRAND_DESC,GCPP_PATTERN,MARKET_EFF_DT 
				FROM AGP.MEM_MARKET_BRAND where regexp_like (?, gcpp_pattern) and sysdate between MARKET_EFF_DT and MARKET_TERM_DT and PRINT_BRAND_IND = 'Y'
			</pre></blockquote></p>
     * @param GCPProduct a concatenation of group, class, plan and product
     * @return A <tt>List</tt> of <tt>FacetsMemberMarketBrandDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberMarketBrandDto> getMemberPrinttBrand(String GCPProduct);    

 
		
		
    /**
     * <p>get PBP ID from medicare details table with sbsb_ck and eligibility dates</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
				select distinct memd.MEME_CK ,
				memd.MEMD_EVENT_CD , 
				memd.MEMD_HCFA_EFF_DT, 
				memd.MEMD_HCFA_TERM_DT,
				memd.MEMD_MCTR_PBP
				from CMC_MEMD_MECR_DETL memd 
				join cmc_meme_member meme on meme.meme_ck = memd.meme_ck
				where memd.MEMD_EVENT_CD = 'PBP' and meme.sbsb_ck = ? 
        		and memd.MEMD_HCFA_TERM_DT > ?  and memd.MEMD_HCFA_EFF_DT < ?
				order by MEMD_HCFA_EFF_DT DESC
			</pre></blockquote></p>
     * @param sbsbCk Subscriber's contrived Key
     * @param eligEffDt Eligibility Effective Date
     * @param eligTermDt Eligibility Termination Date
     * @return the <tt>FacetsMemberPBPDetailsDto</tt> object that matches the
     * selection criteria, or null if there is no match.
     */
    public abstract FacetsMemberPBPDetailsDto getPBPIdBySbrUidAndEligibility(String sbsbCk, Date eligEffDt, Date eligTermDt);    

 
		
		
    /**
     * <p>Get Member Billing Component ID </p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
			select distinct PDBL.PDBL_ID, pdesc.PDBL_DESC
			from CMC_PDBC_PROD_COMP pdbc
			JOIN CMC_PDBL_PROD_BILL PDBL ON pdbc.pdbc_pfx =  pdbl.pdbc_pfx
			left join AGP.PROD_PDBL_DESC pdesc on PDBL.PDBL_ID = pdesc.PDBL_ID
			where pdbc.pdbc_type = 'PDBL'
			and pdbc.pdpd_id = ?
		</pre></blockquote></p>
     * @param pdpdId Members product Id
     * @return A <tt>List</tt> of <tt>FacetsMemberBillingComponentDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberBillingComponentDto> getBillingComponentID(String pdpdId);    

 
		
		
    /**
     * <p>get CMS contract ID by sbruid and member eligibility period</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
				select distinct bgbg.BGBG_ID,
			                    memd.MEMD_HCFA_EFF_DT,
			                    memd.MEMD_HCFA_TERM_DT
				from CMC_MEMD_MECR_DETL memd 
				LEFT JOIN cmc_bgbg_bil_group bgbg on memd.bgbg_ck = bgbg.bgbg_ck 
				join CMC_MEME_MEMBER m on memd.meme_ck = m.meme_ck 
				where memd.MEMD_EVENT_CD = 'SCCC' and m.sbsb_ck = ?  
        		and MEMD_HCFA_TERM_DT > ?  and MEMD_HCFA_EFF_DT < ?
				order by MEMD_HCFA_EFF_DT DESC
			</pre></blockquote></p>
     * @param sbsbCk Subscribers's contrived Key
     * @param eligEffDt Eligibility Effective Date
     * @param eligTermDt Eligibility Termination Date
     * @return the <tt>FacetsMemberBillingGroupDto</tt> object that matches the
     * selection criteria, or null if there is no match.
     */
    public abstract FacetsMemberBillingGroupDto getCMSContractIdBySbrUidAndEligibilityDates (String sbsbCk, Date eligEffDt, Date eligTermDt);    

 
		
		
    /**
     * <p>Get Member Alert Messages</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
					SELECT DISTINCT			
					       WMDS.WMDS_REC_TYPE,			
					       MEWM.MEWM_EFF_DT,			
					       MEWM.MEWM_TERM_DT,			
					       WMDS.WMDS_SEQ_NO,			
					       WMDS.WMDS_TEXT1,			
					       WMDS.WMDS_TEXT2			
					FROM CMC_SBSB_SUBSC SBSB			
					       JOIN CMC_MEME_MEMBER MEME ON SBSB.SBSB_CK = MEME.SBSB_CK			
					       JOIN CMC_MEWM_ME_MSG MEWM ON MEWM.MEME_CK = MEME.MEME_CK			
					       JOIN CMC_WMDS_DESC WMDS ON WMDS.WMDS_SEQ_NO = MEWM.WMDS_SEQ_NO			
					 WHERE WMDS.WMDS_REC_TYPE = 'MEME' 			
					       AND (MEWM.MEWM_TERM_DT BETWEEN ? AND ? 		
					         OR MEWM.MEWM_EFF_DT BETWEEN ? AND ?  			
					         OR ? BETWEEN MEWM.MEWM_EFF_DT AND MEWM.MEWM_TERM_DT 			
					         OR ? BETWEEN MEWM.MEWM_EFF_DT AND MEWM.MEWM_TERM_DT)			
		                         AND SBSB.SBSB_ID = ?
				</pre></blockquote></p>
     * @param subscriberId The SBSB_ID of the subscriber
     * @param effDate The term date to check on the eligibility
     * @param termDate The term date to check on the provider relationship
     * @return A <tt>List</tt> of <tt>FacetsMemberMemberFullAlertTextDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberMemberFullAlertTextDto> getMemberWarningMsg(String subscriberId, Date effDate, Date termDate);    

 
		
		
    /**
     * <p>Get Member Alert Messages</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
			SELECT DISTINCT 		
			       WMDS.WMDS_REC_TYPE,		
			       CSPI.CSPI_EFF_DT,		
			       CSPI.CSPI_TERM_DT,		
			       WMDS.WMDS_SEQ_NO,		
			       WMDS.WMDS_TEXT1,		
			       WMDS.WMDS_TEXT2      		
			  FROM CMC_CSPI_CS_PLAN CSPI 		
			       JOIN CMC_WMDS_DESC WMDS ON WMDS.WMDS_SEQ_NO = CSPI.WMDS_SEQ_NO		
			 WHERE WMDS.WMDS_REC_TYPE = 'CSPI'		
			       AND CSPI.GRGR_CK = ?          		
			       AND CSPI.CSCS_ID = ?        		
			       AND CSPI.CSPI_ID = ?   		
                   AND CSPI.PDPD_ID = ?
                   AND (CSPI.CSPI_TERM_DT BETWEEN ? AND ?     
				         OR CSPI.CSPI_EFF_DT BETWEEN ? AND ?      
				         OR ? BETWEEN CSPI.CSPI_EFF_DT AND CSPI.CSPI_TERM_DT    
				         OR ?  BETWEEN CSPI.CSPI_EFF_DT AND CSPI.CSPI_TERM_DT)
                              
		</pre></blockquote></p>
     * @param grgrck The grgrck of the subscriber
     * @param cscsid cscsid of the Plan
     * @param cspiid cspiid on the plan
     * @param pdpdid pdpdid on the plan
     * @param effDate The term date to check on the eligibility
     * @param termDate The term date to check on the provider relationship
     * @return A <tt>List</tt> of <tt>FacetsMemberPlanFullAlertTextDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberPlanFullAlertTextDto> getPlanWarningMsg(String grgrck, String cscsid, String cspiid, String pdpdid, Date effDate, Date termDate);    

 
		
		
    /**
     * <p>fetch members tobacco Status</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
	   SELECT S.CATEGORY_VALUE 
           FROM AGP.ENRL_STATE_REPORTING_CAT S 
           WHERE S.SBSB_CK = ?
             AND S.CATEGORY = 'Tobacco' 
             AND S.CATEGORY_VALUE = ANY ('Y','N','R','U') 
             AND S.CREATED_DT=( 
           SELECT MAX(C.CREATED_DT)  
           FROM AGP.ENRL_STATE_REPORTING_CAT C  
           WHERE C.SBSB_CK = S.SBSB_CK
             AND C.CATEGORY = 'Tobacco' 
             AND C.CATEGORY_VALUE = ANY ('Y','N','R','U') 
              )        
	   		</pre></blockquote></p>
     * @param sbsb_ck Member's SBSB_CK
     * @return the <tt>FacetsMemberTobaccoStatusDto</tt> object that matches the
     * selection criteria, or null if there is no match.
     */
    public abstract FacetsMemberTobaccoStatusDto getMemberTobaccoStatus(String sbsb_ck);    

 
		
		
    /**
     * <p>get blues prefix</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
			SELECT distinct CSPI_ITS_PREFIX as PREFIX
			FROM CMC_CSPI_CS_PLAN WHERE length(CSPI_ITS_PREFIX)=3			
		   </pre></blockquote></p>
     * @return A <tt>List</tt> of <tt>FacetsMemberBluesPrefixDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberBluesPrefixDto> getBluesPrefixes();    

 
		
		
    /**
     * <p>get sbsb ID and bluse prefix</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
				select sbsb.SBSB_ID, cspi.CSPI_ITS_PREFIX
				from cmc_sbsb_subsc sbsb
				JOIN cmc_meme_member meme ON sbsb.sbsb_ck = meme.sbsb_ck
				JOIN cmc_mepe_prcs_elig mepe ON mepe.meme_ck = meme.meme_ck and mepe.MEPE_ELIG_IND='Y' 
				JOIN CMC_CSPI_CS_PLAN cspi on cspi.GRGR_CK = mepe.GRGR_CK and cspi.cscs_ID=mepe.cscs_ID and cspi.cspi_ID=mepe.cspi_ID 
					 and cspi.CSPD_CAT=mepe.CSPD_CAT and length(cspi.CSPI_ITS_PREFIX)=3 and mepe.MEPE_EFF_DT <= cspi.CSPI_TERM_DT and mepe.MEPE_TERM_DT >= cspi.CSPI_EFF_DT
				where sbsb.sbsb_id=? and ? between cspi.CSPI_EFF_DT and cspi.CSPI_TERM_DT			
		    </pre></blockquote></p>
     * @param subscriberID The SBSB_ID of the member
     * @param searchDate The Search Date
     * @return the <tt>FacetsMemberIdAndBluesPrefixDto</tt> object that matches the
     * selection criteria, or null if there is no match.
     */
    public abstract FacetsMemberIdAndBluesPrefixDto getIdAndBluesPrefixBySbsbIdAndDate(String subscriberID, Date searchDate);    

 
		
		
    /**
     * <p>Get SRI code by SBSB_CK</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre> 
	            select SRI_CODE
	            from AGP.SRI 
				where SBSB_CK = ? AND ( term_dt is null OR (eff_dt is null and sysdate > term_dt) OR (sysdate between eff_dt and term_dt)  )
	        </pre></blockquote></p>
     * @param sbsbCK contrived key
     * @return A <tt>List</tt> of <tt>FacetsMemberSriDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<FacetsMemberSriDto> getSriBySbsbCK(String sbsbCK);    

 
		
		
    /**
     * <p>Get hipaa</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre> SELECT SBSB.SBSB_ID, (CASE WHEN MAX(PMCC.PMCC_TERM_DTM) >= SYSDATE THEN 'Y' ELSE 'N' END) AS HIPAA
				FROM FHP_PMED_MEMBER_D PMED
				LEFT JOIN FHP_PMCC_COMM_X PMCC ON PMCC.PMED_CKE = PMED.PMED_CKE AND PMCC.PMCC_PZCD_STS = 'ACPT'
				INNER JOIN CMC_SBSB_SUBSC SBSB ON SBSB.SBSB_ID  = SUBSTR(PMED.PMED_ID,9,9)
				WHERE
				    SBSB.SBSB_ID = ?
				GROUP BY
				    SBSB.SBSB_ID</pre></blockquote></p>
     * @param memberId Amerigroup ID of the Facets member.
     * @return the <tt>FacetsMemberHippaDto</tt> object that matches the
     * selection criteria, or null if there is no match.
     */
    public abstract FacetsMemberHippaDto getHipaa(String memberId);    

 
		
		
    /**
     * <p>Get a members current eligibilities using the medicaid id</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
				select m.MEME_FIRST_NAME, m.MEME_LAST_NAME, CONCAT(m.MEME_LAST_NAME, m.MEME_TITLE) as FULL_LAST_NAME, m.MEME_BIRTH_DT, pd.LOBD_ID, s.SBSB_ID, s.SBSB_CK, e.MEPE_EFF_DT, e.MEPE_TERM_DT, e.CSCS_ID, e.PDPD_ID, e.CSPI_ID, pland.PLDS_DESC, g.GRGR_ID, sg.SGSG_MCTR_TYPE, m.MEME_MEDCD_NO,m.MEME_HICN, p.NAME, p.GENERAL_DESC, e.CSPD_CAT,
				e.MEPE_ELIG_IND, g.GRGR_NAME, sg.SGSG_NAME, sg.SGSG_ID, sg.SGSG_ORIG_EFF_DT, sg.SGSG_TERM_DT, g.GRGR_MCTR_TYPE , e.GRGR_CK ,pdesc.PDDS_MCTR_VAL1,mctr.mctr_desc,e.MEPE_PLAN_ENTRY_DT,e.MEPE_CREATE_DTM,m.MEME_CK, g.GRGR_PHONE
				from CMC_MEPE_PRCS_ELIG e
				inner join CMC_MEME_MEMBER m on e.MEME_CK = m.MEME_CK and e.MEPE_ELIG_IND = 'Y'
				inner join CMC_SBSB_SUBSC s on m.SBSB_CK = s.SBSB_CK
				left outer join CMC_SGSG_SUB_GROUP sg on e.SGSG_CK = sg.SGSG_CK
				left outer join CMC_GRGR_GROUP g on g.GRGR_CK = sg.GRGR_CK
				left outer join AGP.CCTR_PRODUCT p on e.PDPD_ID = p.PRODUCT_ID and sg.sgsg_mctr_type=p.market_cd
				left outer join CMC_PLDS_PLAN_DESC pland ON e.cspi_id = pland.cspi_id
				LEFT OUTER JOIN FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT
				left outer join CMC_PDDS_PROD_DESC pdesc  on e.pdpd_id = pdesc.pdpd_id
				left outer join  cmc_mctr_cd_trans mctr on mctr.mctr_value = pdesc.PDDS_MCTR_VAL1 and mctr.mctr_entity = 'PDDS' and mctr.MCTR_TYPE = 'VAL'
				where (m.MEME_MEDCD_NO =?) and TRUNC(SYSDATE) between e.MEPE_EFF_DT and e.MEPE_TERM_DT
			</pre></blockquote></p>
     * @param medicaidId Medicaid ID of the member
     * @return the <tt>FacetsMemberEligibilityDto</tt> object that matches the
     * selection criteria, or null if there is no match.
     */
    public abstract FacetsMemberEligibilityDto getCurrentEligibilityByMedicaidID(String medicaidId);    

 
		
		
    /**
     * <p>Get a members current eligibilities using the medicaid id</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
				select m.MEME_FIRST_NAME, m.MEME_LAST_NAME, CONCAT(m.MEME_LAST_NAME, m.MEME_TITLE) as FULL_LAST_NAME, m.MEME_BIRTH_DT, pd.LOBD_ID, s.SBSB_ID, s.SBSB_CK, e.MEPE_EFF_DT, e.MEPE_TERM_DT, e.CSCS_ID, e.PDPD_ID, e.CSPI_ID, pland.PLDS_DESC, g.GRGR_ID, sg.SGSG_MCTR_TYPE, m.MEME_MEDCD_NO,m.MEME_HICN, p.NAME, p.GENERAL_DESC, e.CSPD_CAT,
				e.MEPE_ELIG_IND, g.GRGR_NAME, sg.SGSG_NAME, sg.SGSG_ID, sg.SGSG_ORIG_EFF_DT, sg.SGSG_TERM_DT, g.GRGR_MCTR_TYPE , e.GRGR_CK,pdesc.PDDS_MCTR_VAL1,mctr.mctr_desc,e.MEPE_PLAN_ENTRY_DT,e.MEPE_CREATE_DTM,m.MEME_CK, g.GRGR_PHONE
				from CMC_MEPE_PRCS_ELIG e
				inner join CMC_MEME_MEMBER m on e.MEME_CK = m.MEME_CK and e.MEPE_ELIG_IND = 'Y'
				inner join CMC_SBSB_SUBSC s on m.SBSB_CK = s.SBSB_CK
				left outer join CMC_SGSG_SUB_GROUP sg on e.SGSG_CK = sg.SGSG_CK
				left outer join CMC_GRGR_GROUP g on g.GRGR_CK = sg.GRGR_CK
				left outer join AGP.CCTR_PRODUCT p on e.PDPD_ID = p.PRODUCT_ID and sg.sgsg_mctr_type=p.market_cd
				left outer join CMC_PLDS_PLAN_DESC pland ON e.cspi_id = pland.cspi_id
				LEFT OUTER JOIN FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT
				left outer join CMC_PDDS_PROD_DESC pdesc  on e.pdpd_id = pdesc.pdpd_id
				left outer join  cmc_mctr_cd_trans mctr on mctr.mctr_value = pdesc.PDDS_MCTR_VAL1 and mctr.mctr_entity = 'PDDS' and mctr.MCTR_TYPE = 'VAL'
				where (m.MEME_HICN =?) and TRUNC(SYSDATE) between e.MEPE_EFF_DT and e.MEPE_TERM_DT
			</pre></blockquote></p>
     * @param medicareId Medicaid ID of the member
     * @return the <tt>FacetsMemberEligibilityDto</tt> object that matches the
     * selection criteria, or null if there is no match.
     */
    public abstract FacetsMemberEligibilityDto getCurrentEligibilityByCurrentMedicareID(String medicareId);    

 
		
		
    /**
     * <p>Get a members current eligibilities using the medicaid id</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
				select m.MEME_FIRST_NAME, m.MEME_LAST_NAME, CONCAT(m.MEME_LAST_NAME, m.MEME_TITLE) as FULL_LAST_NAME, m.MEME_BIRTH_DT, pd.LOBD_ID, s.SBSB_ID, s.SBSB_CK, e.MEPE_EFF_DT, e.MEPE_TERM_DT, e.CSCS_ID, e.PDPD_ID, e.CSPI_ID, pland.PLDS_DESC, g.GRGR_ID, sg.SGSG_MCTR_TYPE, m.MEME_MEDCD_NO,m.MEME_HICN, p.NAME, p.GENERAL_DESC, e.CSPD_CAT,
				e.MEPE_ELIG_IND, g.GRGR_NAME, sg.SGSG_NAME, sg.SGSG_ID, sg.SGSG_ORIG_EFF_DT, sg.SGSG_TERM_DT, g.GRGR_MCTR_TYPE , e.GRGR_CK,pdesc.PDDS_MCTR_VAL1,mctr.mctr_desc,e.MEPE_PLAN_ENTRY_DT,e.MEPE_CREATE_DTM,m.MEME_CK, g.GRGR_PHONE
				from CMC_MEPE_PRCS_ELIG e
				inner join CMC_MEME_MEMBER m on e.MEME_CK = m.MEME_CK and e.MEPE_ELIG_IND = 'Y'
				inner join CMC_SBSB_SUBSC s on m.SBSB_CK = s.SBSB_CK
				left join CMC_MECR_NO_XREF x on x.MEME_CK = M.MEME_CK
				left outer join CMC_SGSG_SUB_GROUP sg on e.SGSG_CK = sg.SGSG_CK
				left outer join CMC_GRGR_GROUP g on g.GRGR_CK = sg.GRGR_CK
				left outer join AGP.CCTR_PRODUCT p on e.PDPD_ID = p.PRODUCT_ID and sg.sgsg_mctr_type=p.market_cd
				left outer join CMC_PLDS_PLAN_DESC pland ON e.cspi_id = pland.cspi_id
				LEFT OUTER JOIN FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT
				left outer join CMC_PDDS_PROD_DESC pdesc  on e.pdpd_id = pdesc.pdpd_id
				left outer join  cmc_mctr_cd_trans mctr on mctr.mctr_value = pdesc.PDDS_MCTR_VAL1 and mctr.mctr_entity = 'PDDS' and mctr.MCTR_TYPE = 'VAL'
				where (x.MECR_NO_ORIG = ?) and TRUNC(SYSDATE) between e.MEPE_EFF_DT and e.MEPE_TERM_DT
			</pre></blockquote></p>
     * @param medicareId Medicaid ID of the member
     * @return the <tt>FacetsMemberEligibilityDto</tt> object that matches the
     * selection criteria, or null if there is no match.
     */
    public abstract FacetsMemberEligibilityDto getCurrentEligibilityByOldMedicareID(String medicareId);    

 
		
		
    /**
     * <p>Get a members current eligibilities using the medicaid id</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
				select m.MEME_FIRST_NAME, m.MEME_LAST_NAME, CONCAT(m.MEME_LAST_NAME, m.MEME_TITLE) as FULL_LAST_NAME, m.MEME_BIRTH_DT, pd.LOBD_ID, s.SBSB_ID, s.SBSB_CK, e.MEPE_EFF_DT, e.MEPE_TERM_DT, e.CSCS_ID, e.PDPD_ID, e.CSPI_ID, pland.PLDS_DESC, g.GRGR_ID, sg.SGSG_MCTR_TYPE, m.MEME_MEDCD_NO,m.MEME_HICN, p.NAME, p.GENERAL_DESC, e.CSPD_CAT,
				e.MEPE_ELIG_IND, g.GRGR_NAME, sg.SGSG_NAME, sg.SGSG_ID, sg.SGSG_ORIG_EFF_DT, sg.SGSG_TERM_DT, g.GRGR_MCTR_TYPE , e.GRGR_CK,pdesc.PDDS_MCTR_VAL1,mctr.mctr_desc,e.MEPE_PLAN_ENTRY_DT,e.MEPE_CREATE_DTM,m.MEME_CK, g.GRGR_PHONE
				from CMC_MEPE_PRCS_ELIG e
				inner join CMC_MEME_MEMBER m on e.MEME_CK = m.MEME_CK
				inner join CMC_SBSB_SUBSC s on m.SBSB_CK = s.SBSB_CK
				left outer join CMC_SGSG_SUB_GROUP sg on e.SGSG_CK = sg.SGSG_CK
				left outer join CMC_GRGR_GROUP g on g.GRGR_CK = sg.GRGR_CK
				left outer join AGP.CCTR_PRODUCT p on e.PDPD_ID = p.PRODUCT_ID and sg.sgsg_mctr_type=p.market_cd
				left outer join CMC_PLDS_PLAN_DESC pland ON e.cspi_id = pland.cspi_id
				LEFT OUTER JOIN FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT
				left outer join CMC_PDDS_PROD_DESC pdesc  on e.pdpd_id = pdesc.pdpd_id
				left outer join  cmc_mctr_cd_trans mctr on mctr.mctr_value = pdesc.PDDS_MCTR_VAL1 and mctr.mctr_entity = 'PDDS' and mctr.MCTR_TYPE = 'VAL'
				where (m.MEME_MEDCD_NO =?) and TRUNC(SYSDATE) between e.MEPE_EFF_DT and e.MEPE_TERM_DT
			</pre></blockquote></p>
     * @param medicaidId Medicaid ID of the member
     * @return the <tt>FacetsMemberEligibilityDto</tt> object that matches the
     * selection criteria, or null if there is no match.
     */
    public abstract FacetsMemberEligibilityDto getCurrentEligibilityWithNoEligibilityCheckByMedicaidID(String medicaidId);    

 
		
		
    /**
     * <p>Get a members current eligibilities using the medicare id</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
				select m.MEME_FIRST_NAME, m.MEME_LAST_NAME, CONCAT(m.MEME_LAST_NAME, m.MEME_TITLE) as FULL_LAST_NAME, m.MEME_BIRTH_DT, pd.LOBD_ID, s.SBSB_ID, s.SBSB_CK, e.MEPE_EFF_DT, e.MEPE_TERM_DT, e.CSCS_ID, e.PDPD_ID, e.CSPI_ID, pland.PLDS_DESC, g.GRGR_ID, sg.SGSG_MCTR_TYPE, m.MEME_MEDCD_NO,m.MEME_HICN, p.NAME, p.GENERAL_DESC, e.CSPD_CAT,
				e.MEPE_ELIG_IND, g.GRGR_NAME, sg.SGSG_NAME, sg.SGSG_ID, sg.SGSG_ORIG_EFF_DT, sg.SGSG_TERM_DT, g.GRGR_MCTR_TYPE , e.GRGR_CK,pdesc.PDDS_MCTR_VAL1,mctr.mctr_desc,e.MEPE_PLAN_ENTRY_DT,e.MEPE_CREATE_DTM,m.MEME_CK, g.GRGR_PHONE
				from CMC_MEPE_PRCS_ELIG e
				inner join CMC_MEME_MEMBER m on e.MEME_CK = m.MEME_CK
				inner join CMC_SBSB_SUBSC s on m.SBSB_CK = s.SBSB_CK
				left outer join CMC_SGSG_SUB_GROUP sg on e.SGSG_CK = sg.SGSG_CK
				left outer join CMC_GRGR_GROUP g on g.GRGR_CK = sg.GRGR_CK
				left outer join AGP.CCTR_PRODUCT p on e.PDPD_ID = p.PRODUCT_ID and sg.sgsg_mctr_type=p.market_cd
				left outer join CMC_PLDS_PLAN_DESC pland ON e.cspi_id = pland.cspi_id
				LEFT OUTER JOIN FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT
				left outer join CMC_PDDS_PROD_DESC pdesc  on e.pdpd_id = pdesc.pdpd_id
				left outer join  cmc_mctr_cd_trans mctr on mctr.mctr_value = pdesc.PDDS_MCTR_VAL1 and mctr.mctr_entity = 'PDDS' and mctr.MCTR_TYPE = 'VAL'
				where (m.MEME_HICN =?) and TRUNC(SYSDATE) between e.MEPE_EFF_DT and e.MEPE_TERM_DT
			</pre></blockquote></p>
     * @param medicaidId Medicaid ID of the member
     * @return the <tt>FacetsMemberEligibilityDto</tt> object that matches the
     * selection criteria, or null if there is no match.
     */
    public abstract FacetsMemberEligibilityDto getCurrentEligibilityWithNoEligibilityCheckByCurrentMedicareID(String medicaidId);    

 
		
		
    /**
     * <p>Get a members current eligibilities using the medicaid id</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
				select m.MEME_FIRST_NAME, m.MEME_LAST_NAME, CONCAT(m.MEME_LAST_NAME, m.MEME_TITLE) as FULL_LAST_NAME, m.MEME_BIRTH_DT, pd.LOBD_ID, s.SBSB_ID, s.SBSB_CK, e.MEPE_EFF_DT, e.MEPE_TERM_DT, e.CSCS_ID, e.PDPD_ID, e.CSPI_ID, pland.PLDS_DESC, g.GRGR_ID, sg.SGSG_MCTR_TYPE, m.MEME_MEDCD_NO,m.MEME_HICN, p.NAME, p.GENERAL_DESC, e.CSPD_CAT,
				e.MEPE_ELIG_IND, g.GRGR_NAME, sg.SGSG_NAME, sg.SGSG_ID, sg.SGSG_ORIG_EFF_DT, sg.SGSG_TERM_DT, g.GRGR_MCTR_TYPE , e.GRGR_CK,pdesc.PDDS_MCTR_VAL1,mctr.mctr_desc,e.MEPE_PLAN_ENTRY_DT,e.MEPE_CREATE_DTM,m.MEME_CK, g.GRGR_PHONE
				from CMC_MEPE_PRCS_ELIG e
				inner join CMC_MEME_MEMBER m on e.MEME_CK = m.MEME_CK
				inner join CMC_SBSB_SUBSC s on m.SBSB_CK = s.SBSB_CK
				left join CMC_MECR_NO_XREF x on x.MEME_CK = M.MEME_CK
				left outer join CMC_SGSG_SUB_GROUP sg on e.SGSG_CK = sg.SGSG_CK
				left outer join CMC_GRGR_GROUP g on g.GRGR_CK = sg.GRGR_CK
				left outer join AGP.CCTR_PRODUCT p on e.PDPD_ID = p.PRODUCT_ID and sg.sgsg_mctr_type=p.market_cd
				left outer join CMC_PLDS_PLAN_DESC pland ON e.cspi_id = pland.cspi_id
				LEFT OUTER JOIN FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT
				left outer join CMC_PDDS_PROD_DESC pdesc  on e.pdpd_id = pdesc.pdpd_id
				left outer join  cmc_mctr_cd_trans mctr on mctr.mctr_value = pdesc.PDDS_MCTR_VAL1 and mctr.mctr_entity = 'PDDS' and mctr.MCTR_TYPE = 'VAL'
				where (x.MECR_NO_ORIG =?) and TRUNC(SYSDATE) between e.MEPE_EFF_DT and e.MEPE_TERM_DT
			</pre></blockquote></p>
     * @param medicareId Medicaid ID of the member
     * @return the <tt>FacetsMemberEligibilityDto</tt> object that matches the
     * selection criteria, or null if there is no match.
     */
    public abstract FacetsMemberEligibilityDto getCurrentEligibilityWithNoEligibilityCheckByOldMedicareID(String medicareId);    

 
		
		
    /**
     * <p>Get a members current eligibility using the amerigroup id</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre> select m.MEME_FIRST_NAME, m.MEME_LAST_NAME,
				CONCAT(m.MEME_LAST_NAME, m.MEME_TITLE) as FULL_LAST_NAME,
				m.MEME_BIRTH_DT, pd.LOBD_ID, s.SBSB_ID, s.SBSB_CK, e.MEPE_EFF_DT,
				e.MEPE_TERM_DT, e.CSCS_ID, e.PDPD_ID, e.CSPI_ID, pland.PLDS_DESC,
				g.GRGR_ID, sg.SGSG_MCTR_TYPE, m.MEME_MEDCD_NO,m.MEME_HICN, p.NAME,
				p.GENERAL_DESC, e.CSPD_CAT, e.MEPE_ELIG_IND, g.GRGR_NAME,
				sg.SGSG_NAME, sg.SGSG_ID, sg.SGSG_ORIG_EFF_DT,
				sg.SGSG_TERM_DT,g.GRGR_MCTR_TYPE, e.GRGR_CK,pdesc.PDDS_MCTR_VAL1,
				mctr.mctr_desc, e.MEPE_PLAN_ENTRY_DT,e.MEPE_CREATE_DTM,m.MEME_CK,
				g.GRGR_PHONE from CMC_MEPE_PRCS_ELIG e inner join CMC_MEME_MEMBER m
				on e.MEME_CK = m.MEME_CK and e.MEPE_ELIG_IND = 'Y' inner join
				CMC_SBSB_SUBSC s on m.SBSB_CK = s.SBSB_CK left outer join
				CMC_SGSG_SUB_GROUP sg on e.SGSG_CK = sg.SGSG_CK left outer join
				CMC_GRGR_GROUP g on g.GRGR_CK = sg.GRGR_CK left outer join
				AGP.CCTR_PRODUCT p on e.PDPD_ID = p.PRODUCT_ID and
				sg.sgsg_mctr_type=p.market_cd left outer join CMC_PLDS_PLAN_DESC
				pland ON e.cspi_id = pland.cspi_id LEFT OUTER JOIN
				FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and
				e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT left outer
				join CMC_PDDS_PROD_DESC pdesc on e.pdpd_id = pdesc.pdpd_id left
				outer join cmc_mctr_cd_trans mctr on mctr.mctr_value =
				pdesc.PDDS_MCTR_VAL1 and mctr.mctr_entity = 'PDDS' and
				mctr.MCTR_TYPE = 'VAL' where (s.SBSB_ID =?) and TRUNC(SYSDATE)
				between e.MEPE_EFF_DT and e.MEPE_TERM_DT
			</pre></blockquote></p>
     * @param amerigroupID Amerigroup ID of the member
     * @return the <tt>FacetsMemberEligibilityDto</tt> object that matches the
     * selection criteria, or null if there is no match.
     */
    public abstract FacetsMemberEligibilityDto getCurrentEligibilityByAmerigroupID(String amerigroupID);    

 
		
		
    /**
     * <p>Get a members current eligibility using the amerigroup id</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre> select m.MEME_FIRST_NAME,
				m.MEME_LAST_NAME,CONCAT(m.MEME_LAST_NAME, m.MEME_TITLE) as
				FULL_LAST_NAME, m.MEME_BIRTH_DT, pd.LOBD_ID, s.SBSB_ID, s.SBSB_CK,
				e.MEPE_EFF_DT, e.MEPE_TERM_DT, e.CSCS_ID, e.PDPD_ID, e.CSPI_ID,
				pland.PLDS_DESC, g.GRGR_ID, sg.SGSG_MCTR_TYPE,
				m.MEME_MEDCD_NO,m.MEME_HICN, p.NAME, p.GENERAL_DESC, e.CSPD_CAT,
				e.MEPE_ELIG_IND, g.GRGR_NAME, sg.SGSG_NAME, sg.SGSG_ID,
				sg.SGSG_ORIG_EFF_DT, sg.SGSG_TERM_DT,g.GRGR_MCTR_TYPE,
				e.GRGR_CK,pdesc.PDDS_MCTR_VAL1,
				mctr.mctr_desc,e.MEPE_PLAN_ENTRY_DT,e.MEPE_CREATE_DTM,m.MEME_CK,
				g.GRGR_PHONE from CMC_MEPE_PRCS_ELIG e inner join CMC_MEME_MEMBER m
				on e.MEME_CK = m.MEME_CK inner join CMC_SBSB_SUBSC s on m.SBSB_CK =
				s.SBSB_CK left outer join CMC_SGSG_SUB_GROUP sg on e.SGSG_CK =
				sg.SGSG_CK left outer join CMC_GRGR_GROUP g on g.GRGR_CK =
				sg.GRGR_CK left outer join AGP.CCTR_PRODUCT p on e.PDPD_ID =
				p.PRODUCT_ID and sg.sgsg_mctr_type=p.market_cd left outer join
				CMC_PLDS_PLAN_DESC pland ON e.cspi_id = pland.cspi_id LEFT OUTER
				JOIN FACETS.CMC_PDPD_PRODUCT pd on e.PDPD_ID = pd.PDPD_ID and
				e.MEPE_EFF_DT between pd.PDPD_EFF_DT and pd.PDPD_TERM_DT left outer
				join CMC_PDDS_PROD_DESC pdesc on e.pdpd_id = pdesc.pdpd_id left
				outer join cmc_mctr_cd_trans mctr on mctr.mctr_value =
				pdesc.PDDS_MCTR_VAL1 and mctr.mctr_entity = 'PDDS' and
				mctr.MCTR_TYPE = 'VAL' where (s.SBSB_ID =?) and TRUNC(SYSDATE)
				between e.MEPE_EFF_DT and e.MEPE_TERM_DT </pre></blockquote></p>
     * @param amerigroupID Amerigroup ID of the member
     * @return the <tt>FacetsMemberEligibilityDto</tt> object that matches the
     * selection criteria, or null if there is no match.
     */
    public abstract FacetsMemberEligibilityDto getCurrentEligibilityWithNoEligibilityCheckByAmerigroupID(String amerigroupID);    

 
    
}
// CHECKSTYLE:ON
/* END OF FILE  - com.amerigroup.facets.dao.IFacetsMemberDao */
