
package com.amerigroup.auth.dao.dto;

import java.util.*;



/**
 * Vendor Details
 * <p>Definition filename: daoPreCert.xml</p>
 */
public class PreCertVendorInfoDto 
{

    
    /** 
     * <p>Group ID</p>
     */
    
    public String groupID;
    
    /** 
     * <p>vendor code</p>
     */
    
    public String vendorCode;
    
    /** 
     * <p>code_link</p>
     */
    
    public String codeLink;
    
    /** 
     * <p>eff_date</p>
     */
    
    public String effdate;
    
    /** 
     * <p>term_date</p>
     */
    
    public String termDate;
    
	

    /**
     * Default constructor
     */
    public PreCertVendorInfoDto() 
    {
        ;// Nothing to do
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() 
    {
        StringBuilder sb = new StringBuilder("[VendorInfoDto: ");
        
        sb.append("groupID=").append(groupID).append(",");
        sb.append("vendorCode=").append(vendorCode).append(",");
        sb.append("codeLink=").append(codeLink).append(",");
        sb.append("effdate=").append(effdate).append(",");
        sb.append("termDate=").append(termDate);
        sb.append("]");
        return sb.toString();        
    }    
}
