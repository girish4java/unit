
// CHECKSTYLE:OFF
package com.amerigroup.auth.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.*;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import com.amerigroup.utilities.Text;
import com.amerigroup.daobase.ADatabaseDao;
import com.amerigroup.daobase.IDatabaseDao;
import com.amerigroup.daobase.DAOTransaction;
import com.amerigroup.exception.runtime.execution.DAOException;
import com.amerigroup.exception.checked.DAONeedRollbackException;
import com.amerigroup.utilities.EnvironmentResolver;
import org.apache.log4j.Logger;

import com.amerigroup.auth.dao.dto.*;

/**
 * <p>A DAO for Pre certification</p>
 * <p>This class is the standard implementation for the DAO.</p>
 * <p>Definition filename: daoPreCert.xml</p>
 */
@SuppressWarnings("all")
public class PreCertDaoImpl extends ADatabaseDao implements IPreCertDao
{

    /** Log4j logger */
    private static final Logger log = Logger.getLogger(PreCertDaoImpl.class);

    /**
     * {@inheritDoc}
     * @see com.amerigroup.dao.ADatabaseDao#getLogger()
     */
    @Override
    public Logger getLogger()
    {
    	return PreCertDaoImpl.log;
    }
    
	/**
	 * {@inheritDoc}
	 * @see com.amerigroup.dao.IDatabaseDao#getDatasourceJndiName()
	 */
	 public String getDatasourceJndiName() 
   	 {  
       	 String jndiName = "";
     	 if (!Text.isEffectivelyEmptyOrNull(jndiName)){
	        	return jndiName;
	  	 } 	        
	  	 return getJndiNameByEnvironment();
   	 }
    
    public String getJndiNameByEnvironment() {
        
    	com.amerigroup.utilities.EnvironmentResolver envResolver = new com.amerigroup.utilities.EnvironmentResolver(); 
    	String envID = envResolver.getEnvironmentId();
		log.info("datasource " + envID);
		
		if(envID != null)
    	{

			envID= envResolver.getSingleProperty(envID,com.amerigroup.utilities.EnvironmentResolver.PropertyType.PROPERTY_TYPE_DATASOURCE, "WebAuth");
        }
        
        return envID;      
    	
    }
	
		
    /**
     * <p>Get Vendor Details by given Group Class Plan</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
				SELECT distinct grgr_id, vendor_code, code_link, eff_date, term_date 
				FROM [WEBAUTH].[dbo].[VendorDelegateGroupPlan] (nolock)
				WHERE grgr_id = ? and cscs_id = ? and cspi_id = ?
					and ? <= term_date and ? >= eff_date
			</pre></blockquote></p>
     * @param grgrId Group ID
     * @param classId Class ID
     * @param planId Plan ID
     * @param startDt start date
     * @param endDt search end date
     * @return A <tt>List</tt> of <tt>PreCertVendorInfoDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public List<PreCertVendorInfoDto> getVendorDetailsBetweenDates(String grgrId, String classId, String planId, Date startDt, Date endDt)
    {
        List<PreCertVendorInfoDto> result = new ArrayList<PreCertVendorInfoDto>();
        
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        String sql = ""+
         " SELECT distinct grgr_id, vendor_code, code_link, eff_date, term_date"+
         " FROM [WEBAUTH].[dbo].[VendorDelegateGroupPlan] (nolock)"+
         " WHERE grgr_id = ? and cscs_id = ? and cspi_id = ?"+
         " and ? <= term_date and ? >= eff_date"+
         " 			";
        
        try 
        {
	        long connectionStart = System.currentTimeMillis();
			conn = getConnection();
			if (conn == null) {
				log.error("Unable to get a connection to datasource " + getDatasourceJndiName());
					log.debug("<getVendorDetailsBetweenDates" );
				return result;
			}

				StringBuilder sb = null;
            
            ps = conn.prepareStatement(sql);
            
            long connectionDuration = System.currentTimeMillis() - connectionStart;
            
            int parmNum = 1;
            
				log.debug("Executing SQL: " + sql);
            
				log.debug("   Setting parm #" + parmNum + " (grgrId) to " + grgrId);
                
            ps.setString(parmNum++, grgrId);
            
				log.debug("   Setting parm #" + parmNum + " (classId) to " + classId);
                
            ps.setString(parmNum++, classId);
            
				log.debug("   Setting parm #" + parmNum + " (planId) to " + planId);
                
            ps.setString(parmNum++, planId);
            
				log.debug("   Setting parm #" + parmNum + " (startDt) to " + startDt);
                

				if (startDt == null) 
            {
                
                ps.setTimestamp(parmNum++, null);
                
            }
            else {
                
                ps.setTimestamp(parmNum++, new java.sql.Timestamp(startDt.getTime()));
                
            }            
            
				log.debug("   Setting parm #" + parmNum + " (endDt) to " + endDt);
                

				if (endDt == null) 
            {
                
                ps.setTimestamp(parmNum++, null);
                
            }
            else {
                
                ps.setTimestamp(parmNum++, new java.sql.Timestamp(endDt.getTime()));
                
            }            
            
            long queryStart = System.currentTimeMillis();
				log.debug("Starting query");
            rs = ps.executeQuery();
            int queryDuration = (int) (System.currentTimeMillis() - queryStart);

            // Load results into list            
            long loadResultsStart = System.currentTimeMillis();
            int rowsRead = 0;
            while (rs.next())
            {
            	rowsRead++;
                PreCertVendorInfoDto dto = new PreCertVendorInfoDto();
                                
                dto.groupID = rs.getString("grgr_id");
                if (rs.wasNull()) 
                {
                    dto.groupID = null;
                }
                                
                dto.vendorCode = rs.getString("vendor_code");
                if (rs.wasNull()) 
                {
                    dto.vendorCode = null;
                }
                                
                dto.codeLink = rs.getString("code_link");
                if (rs.wasNull()) 
                {
                    dto.codeLink = null;
                }
                                
                dto.effdate = rs.getString("eff_date");
                if (rs.wasNull()) 
                {
                    dto.effdate = null;
                }
                                
                dto.termDate = rs.getString("term_date");
                if (rs.wasNull()) 
                {
                    dto.termDate = null;
                }
                
                result.add(dto);
                
            }
            
            
            long loadResultsDuration = System.currentTimeMillis() - loadResultsStart;
            log.info(String.format("Query Statistics:getVendorDetailsBetweenDates  getJndiName="+getDatasourceJndiName()+", getConnection=%s, queryExecution=%s, loadResults=%s, rowsRead=%s", connectionDuration, queryDuration, loadResultsDuration, rowsRead));
        }
        catch (SQLException ex) 
        {
            SQLException tex = ex;
            if (ex.getNextException() != null)
            {
                tex = ex.getNextException();
            }
            while (tex != null)
            {
                log.error("Database problem: " + tex.getMessage()
                        + " - error code=" + tex.getErrorCode() + ", SQLState="
                        + tex.getSQLState() + " - SQL: " + sql, tex);
                tex = tex.getNextException();
            }
            throw new DAOException("Unable to perform read - SQL: " + sql, ex);
        }
        finally
        {
            closeDatabaseObjects(rs, ps, conn);
        }
        return result;
    }
	

    
}
// CHECKSTYLE:ON
/* END OF FILE  - com.amerigroup.auth.dao.PreCertDaoImpl */
