
// CHECKSTYLE:OFF
package com.amerigroup.auth.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.*;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.amerigroup.daobase.IDatabaseDao;
import com.amerigroup.daobase.DAOTransaction;
import com.amerigroup.exception.runtime.execution.DAOException;
import com.amerigroup.exception.checked.DAONeedRollbackException;

import org.apache.log4j.Logger;

import com.amerigroup.auth.dao.dto.*;

/**
 * <p>A DAO for Pre certification</p>
 * <p>This class is the interface for the DAO.  The standard implementation is {@link PreCertDaoImpl}</p>
 * <p>Definition filename: daoPreCert.xml</p>
 */
@SuppressWarnings("all")
public interface IPreCertDao extends IDatabaseDao
{

		
		
		
    /**
     * <p>Get Vendor Details by given Group Class Plan</p>
     * <p><b>Not transaction-aware.</b></p>
     * <p>Executes the following SQL:<br/>
     * <blockquote><pre>
				SELECT distinct grgr_id, vendor_code, code_link, eff_date, term_date 
				FROM [WEBAUTH].[dbo].[VendorDelegateGroupPlan] (nolock)
				WHERE grgr_id = ? and cscs_id = ? and cspi_id = ?
					and ? <= term_date and ? >= eff_date
			</pre></blockquote></p>
     * @param grgrId Group ID
     * @param classId Class ID
     * @param planId Plan ID
     * @param startDt start date
     * @param endDt search end date
     * @return A <tt>List</tt> of <tt>PreCertVendorInfoDto</tt> objects that match the
     * selection criteria.  The <tt>List</tt> may be empty but will never return null.
     */
    public abstract List<PreCertVendorInfoDto> getVendorDetailsBetweenDates(String grgrId, String classId, String planId, Date startDt, Date endDt);    

 
    
}
// CHECKSTYLE:ON
/* END OF FILE  - com.amerigroup.auth.dao.IPreCertDao */
