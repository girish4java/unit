/*
 * package com.elevancehealth.dckr.microsvc.aksgbdsoamembereligibility;
 * 
 * import static org.junit.jupiter.api.Assertions.assertTrue;
 * 
 * import junit.framework.TestCase; import junit.framework.TestSuite;
 * 
 *//**
	 * Unit test for simple App.
	 */
/*
 * public class ApplicationTest extends TestCase {
 * 
 *//**
	 * Create the test case
	 *
	 * @param testName name of the test case
	 */
/*
 * public ApplicationTest( String testName ) { super( testName ); }
 * 
 *//**
	 * @return the suite of tests being tested
	 */
/*
 * public static Test suite() { return new TestSuite( ApplicationTest.class ); }
 * 
 *//**
	 * Rigourous Test :-)
	 *//*
		 * public void testApp() { assertTrue( true ); }
		 * 
		 * }
		 */