/*
 * package com.elevancehealth.dckr.microsvc.aksgbdsoamembereligibility;
 * 
 * import org.junit.jupiter.api.Test; import
 * org.springframework.boot.test.context.SpringBootTest;
 * 
 * @SpringBootTest class HelloworldApplicationTests {
 * 
 * 
 * }
 */