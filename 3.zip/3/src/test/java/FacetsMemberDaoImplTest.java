import com.amerigroup.facets.dao.FacetsMemberDaoImpl;
import com.amerigroup.facets.dao.dto.FacetsMemberAmerigroupIDDto;
import com.github.springtestdbunit.DbUnitTestExecutionListener;
import com.github.springtestdbunit.annotation.DatabaseSetup;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;

import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;


@SpringBootTest // Bootstraps the Spring context
@ExtendWith(SpringExtension.class) // Integrates JUnit 5 with Spring
@TestExecutionListeners({
		DependencyInjectionTestExecutionListener.class,
		DirtiesContextTestExecutionListener.class,
		TransactionalTestExecutionListener.class,
		DbUnitTestExecutionListener.class // Enables DBUnit
})
// Ensures the test runs in a transaction and rolls back after completion
public class FacetsMemberDaoImplTest
{

	@Autowired
	private FacetsMemberDaoImpl facetsMemberDao; // Autowire your DAO class

	@Test
	@DatabaseSetup("classpath:test-dataset.xml") // Loads test data from this file
	public void testGetIdAndPrefixBySbsbIdDateAndPrefix()
	{
		// Arrange
		String subscriberID = "12345";
		String prefix = "TEST";
		Date searchStartDate = new Date();
		Date searchEndDate = new Date();

		// Act
		List<FacetsMemberAmerigroupIDDto> result = facetsMemberDao.getIdAndPrefixBySbsbIdDateAndPrefix(subscriberID, prefix,
				searchStartDate, searchEndDate);

		// Assert
		assertEquals(1, result.size());
		assertEquals("12345", result.get(0).amerigroupID);
		assertEquals("GRP123", result.get(0).groupID);
	}
}