package com.anthem.soa.gbd.apimembereligibility.swagger;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;



@Configuration
@ConfigurationProperties(prefix = "membereligibility")
public class MemberEligibilityConfigService {

	
	private Map<String, String> memberdomain;
	

	
	public void setMemberDomain(Map<String, String> memberdomain) {
		this.memberdomain = memberdomain;
	}

	public Map<String, String> getMemberDomain() {
		return memberdomain;
	}


}
