package com.anthem.soa.gbd.apimembereligibility.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

public class Relationship
{

	@JsonProperty("relationship")
	private Relationship2 relationship;

	public Relationship2 getRelationship()
	{
		return relationship;
	}

	public void setRelationship(Relationship2 relationship)
	{
		this.relationship = relationship;
	}

	@Override
	public String toString()
	{
		return "Relationship [relationship=" + relationship + "]";
	}

}
