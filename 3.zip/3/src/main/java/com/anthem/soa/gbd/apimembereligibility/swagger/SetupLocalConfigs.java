package com.anthem.soa.gbd.apimembereligibility.swagger;
//####This class is uesed for local set up

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.soa.gbd.apimembereligibility.util.ESOAApiCallUtil;

import jakarta.annotation.PostConstruct;

@Component
@RestController

public class SetupLocalConfigs {

	@Autowired
	private MemberEligibilityConfigService membereligibility;


	
	@PostConstruct
	public void init() {

		Map<String, String> memberDomainConfigs = membereligibility.getMemberDomain();

		if (memberDomainConfigs == null || memberDomainConfigs.isEmpty()) {
			throw new RuntimeException("membereligibility.memberdomain configuration is missing");
		}

		membereligibility.setMemberDomain(memberDomainConfigs);
		ESOAApiCallUtil.setMembereligibilitymap(memberDomainConfigs);
	}

	@GetMapping("/localMemberDomainconfigs")
	public Map<String, String> getmemberdomainConfigs() {
		return membereligibility.getMemberDomain();
	}

}
