package com.anthem.soa.gbd.apimembereligibility.models;

import java.io.Serializable;

public class ComponentDetails implements Serializable
{

	/**
	 * generated UID
	 */
	private static final long serialVersionUID = 3456106581785222576L;

	private String componentID;

	private String componentDescription;

	public String getComponentID()
	{
		return componentID;
	}

	public void setComponentID(String componentID)
	{
		this.componentID = componentID;
	}

	public String getComponentDescription()
	{
		return componentDescription;
	}

	public void setComponentDescription(String componentDescription)
	{
		this.componentDescription = componentDescription;
	}

	@Override
	public String toString()
	{
		return "ComponentDetails [componentID=" + componentID + ", componentDescription=" + componentDescription + "]";
	}

}
