package com.anthem.soa.gbd.apimembereligibility.models;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

public class Root
{

	private List<Person> persons;

	public List<Person> getPersons()
	{
		return persons;
	}

	public void setPersons(List<Person> persons)
	{
		this.persons = persons;
	}

	@Override
	public String toString()
	{
		return "Root [persons=" + persons + "]";
	}

}
