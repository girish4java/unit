package com.anthem.soa.gbd.apimembereligibility.servicelogic;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;
import com.amerigroup.auth.dao.IPreCertDao;
import com.amerigroup.auth.dao.dto.PreCertVendorInfoDto;
import com.amerigroup.daobase.DaoImplFactory;
import com.amerigroup.facets.dao.IFacetsMemberDao;
import com.amerigroup.facets.dao.dto.FacetsMemberAddressDto;
import com.amerigroup.facets.dao.dto.FacetsMemberAmerigroupIDDto;
import com.amerigroup.facets.dao.dto.FacetsMemberBillingComponentDto;
import com.amerigroup.facets.dao.dto.FacetsMemberBillingGroupDto;
import com.amerigroup.facets.dao.dto.FacetsMemberClassPlanPrefixDto;
import com.amerigroup.facets.dao.dto.FacetsMemberDualCitizenshipAIDCategoryDto;
import com.amerigroup.facets.dao.dto.FacetsMemberDualCitizenshipDetailsDto;
import com.amerigroup.facets.dao.dto.FacetsMemberEligibilityDto;
import com.amerigroup.facets.dao.dto.FacetsMemberMarketBrandDto;
import com.amerigroup.facets.dao.dto.FacetsMemberMemberClaimHoldInfoDto;
import com.amerigroup.facets.dao.dto.FacetsMemberMemberDetailsDto;
import com.amerigroup.facets.dao.dto.FacetsMemberMemberFullAlertTextDto;
import com.amerigroup.facets.dao.dto.FacetsMemberPBPDetailsDto;
import com.amerigroup.facets.dao.dto.FacetsMemberPlanFullAlertTextDto;
import com.amerigroup.facets.dao.dto.FacetsMemberTobaccoStatusDto;
import com.amerigroup.facets.member.FacetsMemberDB;
import com.amerigroup.member.HealthCardID;
import com.amerigroup.member.HealthCardIDFactory;
import com.amerigroup.member.portal.APIEligibilityLookup;
import com.amerigroup.member.portal.dao.IMemberPortalDao;
import com.amerigroup.member.portal.dao.dto.MemberPortalGroupBrandConfigDto;
import com.amerigroup.utilities.DateUtilities;
import com.amerigroup.utilities.LoggerFactory;
import com.amerigroup.utilities.Text;
import com.anthem.member.model.MemberEligibilityDetails;
import com.anthem.member.restrictions.IRestrictionManager;
import com.anthem.member.restrictions.RestrictionManagerImpl;
import com.anthem.member.restrictions.RestrictionType;
import com.anthem.member.restrictions.exceptions.MemberRestrictionException;
import com.anthem.soa.gbd.apimembereligibility.models.ComponentDetails;
import com.anthem.soa.gbd.apimembereligibility.models.DualCitizenshipDetails;
import com.anthem.soa.gbd.apimembereligibility.models.MemberEligibilityResponse;
import com.anthem.soa.gbd.apimembereligibility.models.Person;
import com.anthem.soa.gbd.apimembereligibility.models.Relationship;
import com.anthem.soa.gbd.apimembereligibility.models.Root;
import com.anthem.soa.gbd.apimembereligibility.models.WarningMessages;
import com.anthem.soa.gbd.apimembereligibility.util.ESOAApiCallUtil;
import com.anthem.soa.gbd.apimembereligibility.util.MedicareStrategicTypeMap;

public class MemberEligibilityService
{

    private static final Logger LOG = LoggerFactory.getLogger(MemberEligibilityService.class);

    private static final String REMOVE_SPACE_SPECIALCHAR = "[^a-zA-Z]+";

    public static final String CARE_MORE = "CAREMORE";

    public static final String MARKET_MCD = "MDCD";

    /**
     * Administrative service only
     */
    public static final String FUNDING_TYPE_CD_ASO = "ASO";

    /**
     * Fully Insured
     */
    public static final String FUNDING_TYPE_CD_FI = "FI";

    /**
     *
     * @param healthCardId Health card Id of a member
     * @param medicaidId Medicaid ID of a member
     * @param startDt if passed both startDt and endDt then this operation fetches the eligibilities during that period
     * @param endDt if passed both startDt and endDt then this operation fetches the eligibilities during that period
     * @param eligibilityCheck if the value is true then it fetches the eligibilities only when MEPE_ELIG_IND = "Y"
     * @param medicareId Medicare ID of a member
     * @return ResponseEligibility
     * @throws MemberRestrictionException
     */
    public List<MemberEligibilityResponse.MemberEligibility> findMemberEligibility(String healthCardId,
                                                                                   String medicaidId, Date startDt, Date endDt, boolean eligibilityCheck, String medicareId,
                                                                                   boolean isMcidRequired, String stateCd, String providerState, String lastName, String dob,
                                                                                   String recordType, boolean restrictionCheck) throws MemberRestrictionException
    {
        try
        {

            String sbsbId = null;

            List<FacetsMemberAmerigroupIDDto> agpIds = new ArrayList<FacetsMemberAmerigroupIDDto>();

            if (!Text.isEffectivelyEmptyOrNull(healthCardId))
            {
                //get the SBSB_ID
                sbsbId = verifyHCID(healthCardId);

                if (!Text.isEffectivelyEmptyOrNull(sbsbId))
                {
                    if (healthCardId.trim().length() > 9)
                    {
                        String pfx = healthCardId.trim().substring(0, 3).toUpperCase();
                        Date stdt = null;
                        Date edt = null;
                        if (startDt == null && endDt == null)
                        {
                            stdt = new Date();
                            edt = new Date();
                        }
                        else
                        {
                            stdt = startDt;
                            edt = endDt;
                        }

                        agpIds = getIFacetsMemberDao().getIdAndPrefixBySbsbIdDateAndPrefix(sbsbId, pfx, stdt, edt);

                    }
                    else
                    {
                        agpIds = getIFacetsMemberDao().findByAgp(sbsbId);
                    }

                    if (agpIds == null || agpIds.isEmpty() || agpIds.size() <= 0)
                    {
                        if (healthCardId.length() == 15)
                        {
                            sbsbId = healthCardId.substring(3, healthCardId.length());
                        }
                        else
                        {
                            sbsbId = healthCardId;
                        }
                    }
                }

                if (!Text.isEffectivelyEmptyOrNull(medicaidId) && !healthCardId.equalsIgnoreCase(medicaidId))
                {
                    medicaidId = null;
                }

            }
            if (Text.isEffectivelyEmptyOrNull(medicaidId))
            {
                stateCd = null;
            }

            if (!Text.isEffectivelyEmptyOrNull(medicaidId))
            {
                agpIds = getIFacetsMemberDao().findByAgp(medicaidId);

                if (agpIds == null || agpIds.isEmpty() || agpIds.size() <= 0)
                {
                    medicaidId = getAlphaPrefixTrim(medicaidId);
                }
            }

            if (!Text.isEffectivelyEmptyOrNull(medicareId))
            {
                medicareId = getAlphaPrefixTrim(medicareId);
            }

            List<FacetsMemberEligibilityDto> eligibilities = new ArrayList<FacetsMemberEligibilityDto>();

            //if eligibilityCheck is true then fetch eligibilities only with condition MEPE_ELIG_IND = "Y", else don't consider the condition in the query.
            if (eligibilityCheck)
            {
                eligibilities = getAllEligibilitiesWithEligibilityCheck(healthCardId, sbsbId, medicaidId, medicareId,
                        providerState, lastName, dob, recordType);
            }
            else
            {
                eligibilities = getAllEligibilitiesWithNoEligibilityCheck(healthCardId, sbsbId, medicaidId, medicareId,
                        providerState, lastName, dob, recordType);
            }

            List<MemberEligibilityResponse.MemberEligibility> eligList = new ArrayList<MemberEligibilityResponse.MemberEligibility>();

            if (!(eligibilities == null || eligibilities.isEmpty()))
            {
                //check if member eligibility has any restrictions. At this point we are checking restriction for one of the
                //eligibility in the list assuming that same restrictions apply to the same member's other eligibilities.
                if (restrictionCheck)
                {
                    checkForRestrictions(eligibilities);
                }

                //Fetching the home address for the member.
                FacetsMemberAddressDto address = getIFacetsMemberDao().getHomeAddress(eligibilities.get(0).sbsbID);

                //Fetching dual citizenship details for one of the member eligibility, assuming that member's SBSB_ID won't change for eligibility to eligibility.
                List<FacetsMemberDualCitizenshipDetailsDto> dualCitizenshipDetails = getIFacetsMemberDao()
                        .getDualCitizenshipDetailsBySBSBIDwithMediciad(eligibilities.get(0).sbsbID);

                // SE-329818 changes
                // For the latest record, fetch medicaidAidCategory from MCR_ENR_MEDICAID_LEVEL - based on LAST_VER_DATE DESC and CREATE_DTM DESC.

                if (dualCitizenshipDetails != null && !dualCitizenshipDetails.isEmpty()
                        && !Text.isEffectivelyEmptyOrNull(dualCitizenshipDetails.get(0).requestedMemeCk))
                {
                    List<FacetsMemberDualCitizenshipAIDCategoryDto> dualCitizenshipAIDCategoryList = getIFacetsMemberDao()
                            .getDualCitizenshipAIDCategoryByMemeCk(dualCitizenshipDetails.get(0).requestedMemeCk);

                    if (!dualCitizenshipAIDCategoryList.isEmpty() && !Text
                            .isEffectivelyEmptyOrNull(dualCitizenshipAIDCategoryList.get(0).medicaidAidCategory))
                    {
                        dualCitizenshipDetails.get(0).medicaidAidCategory = dualCitizenshipAIDCategoryList
                                .get(0).medicaidAidCategory;
                    }
                }

                //filter the eligibilities based on the date requirement and transform them to the response.
                eligList = getFilteredAndTransformedEligList(eligibilities, address, dualCitizenshipDetails, startDt,
                        endDt, isMcidRequired, stateCd);

            }
            return eligList;
        }
        catch (Exception e)
        {
            throw e;
        }

    }

    private String getAlphaPrefixTrim(String str)
    {

        if (str.substring(0, 3).matches("^[a-zA-Z]*$"))
        {
            return str.substring(3);
        }

        return str;
    }

    /**
     *
     * This method fetches all the eligibilities without the condition MEPE_ELIG_IND in the query.
     *
     * @param healthCardId
     * @param sbsbId
     * @param medicaidId
     * @param medicareId
     * @return
     */
    private List<FacetsMemberEligibilityDto> getAllEligibilitiesWithNoEligibilityCheck(String healthCardId,
                                                                                       String sbsbId, String medicaidId, String medicareId, String providerState, String lastName, String dob,
                                                                                       String recordType)
    {
        List<FacetsMemberEligibilityDto> eligs = new ArrayList<FacetsMemberEligibilityDto>();

        //fetch the eligibilities with SBSB_ID only when HCID is given.
        if (!Text.isEffectivelyEmptyOrNull(healthCardId) && Text.isEffectivelyEmptyOrNull(medicaidId)
                && Text.isEffectivelyEmptyOrNull(medicareId))
        {
            eligs = getIFacetsMemberDao().getAllEligibilitiesWithNoEligibilityCheckByAmerigroupID(sbsbId);
            if (eligs == null || eligs.isEmpty() || eligs.size() <= 0)
            {
                eligs = getIFacetsMemberDao().getAllEligibilityWithNoEligibilityCheckByINMedicaidID(sbsbId);
            }
        }
        //fetch the eligibilities with MEDCD_NO only when medicaidId is given.
        else if (Text.isEffectivelyEmptyOrNull(healthCardId) && !Text.isEffectivelyEmptyOrNull(medicaidId)
                && Text.isEffectivelyEmptyOrNull(medicareId))
        {
            eligs = getIFacetsMemberDao().getAllEligibilityWithNoEligibilityCheckByMedicaidID(medicaidId);
            if (eligs == null || eligs.isEmpty() || eligs.size() <= 0)
            {
                eligs = getIFacetsMemberDao()
                        .getAllEligibilityWithNoEligibilityCheckByMedicaidIDWithMdcrGrpType(medicaidId);

                if (eligs == null || eligs.isEmpty() || eligs.size() <= 0)
                {
                    eligs = getIFacetsMemberDao().getAllEligibilitiesWithNoEligibilityCheckByAmerigroupID(medicaidId);

                }

            }

        }
        //fetch the eligibilities with HCIN_ID only when medicareId is given.
        else if (Text.isEffectivelyEmptyOrNull(healthCardId) && Text.isEffectivelyEmptyOrNull(medicaidId)
                && !Text.isEffectivelyEmptyOrNull(medicareId))
        {
            eligs = getIFacetsMemberDao().getAllEligibilityWithNoEligibilityCheckByCurrentMedicareID(medicareId);
            if (eligs == null || eligs.isEmpty() || eligs.size() <= 0)
            {
                eligs = getIFacetsMemberDao().getAllEligibilityWithNoEligibilityCheckByOldMedicareID(medicareId);
            }
        }
        //fetch the eligibilities with SBSB_ID first and if there isn't data then fetch with MEDCD_NO when both HCID and meicaidId are given and both are same values.
        else if (!Text.isEffectivelyEmptyOrNull(healthCardId) && !Text.isEffectivelyEmptyOrNull(medicaidId)
                && Text.isEffectivelyEmptyOrNull(medicareId)
                && (healthCardId.equalsIgnoreCase(medicaidId) || sbsbId.equalsIgnoreCase(medicaidId)))
        {
            eligs = getIFacetsMemberDao().getAllEligibilitiesWithNoEligibilityCheckByAmerigroupID(sbsbId);
            if (eligs == null || eligs.size() <= 0)
            {

                eligs = getIFacetsMemberDao().getAllEligibilityWithNoEligibilityCheckByMedicaidID(medicaidId);
            }
        }
        //fetch the eligibilities with SBSB_ID when both HCID and meicareId are given.
        else if (!Text.isEffectivelyEmptyOrNull(healthCardId) && Text.isEffectivelyEmptyOrNull(medicaidId)
                && !Text.isEffectivelyEmptyOrNull(medicareId))
        {
            eligs = getIFacetsMemberDao().getAllEligibilitiesWithNoEligibilityCheckByAmerigroupID(sbsbId);
        }
        else if (!Text.isEffectivelyEmptyOrNull(healthCardId) && !Text.isEffectivelyEmptyOrNull(medicaidId)
                && !Text.isEffectivelyEmptyOrNull(medicareId)
                && (sbsbId.equalsIgnoreCase(medicaidId) || healthCardId.equalsIgnoreCase(medicaidId))
                && (sbsbId.equalsIgnoreCase(medicareId) || healthCardId.equalsIgnoreCase(medicareId)))
        {

            List<FacetsMemberEligibilityDto> medicaidElig = new ArrayList<FacetsMemberEligibilityDto>();
            List<FacetsMemberEligibilityDto> medicareElig = new ArrayList<FacetsMemberEligibilityDto>();

            // medicare
            if (recordType.equalsIgnoreCase("BOTH") || recordType.equalsIgnoreCase("MCR"))
            {
                medicareElig = getIFacetsMemberDao()
                        .getAllEligibilityWithNoEligibilityCheckByCurrentMedicareID(medicareId);
                if (medicareElig == null || medicareElig.isEmpty() || medicareElig.size() <= 0)
                {
                    medicareElig = getIFacetsMemberDao()
                            .getAllEligibilityWithNoEligibilityCheckByOldMedicareID(medicareId);
                }
            }

            // mdedicaid
            if (recordType.equalsIgnoreCase("BOTH") || recordType.equalsIgnoreCase("MCD"))
            {
                medicaidElig = getIFacetsMemberDao().getAllEligibilityWithNoEligibilityCheckByMedicaidID(medicaidId);
            }

            if (medicareElig.size() > 0 || medicaidElig.size() > 0)
            {
                if (recordType.equalsIgnoreCase("BOTH"))
                {
                    medicareElig.addAll(medicaidElig);
                    if (!medicareElig.isEmpty() && (null != lastName || null != dob || null != providerState))
                    {
                        medicareElig = filterEligBasedOnLastNameDOBAndState(medicareElig, lastName, dob, providerState);
                    }
                    if (!medicareElig.isEmpty())
                    {
                        return medicareElig;
                    }
                }
                else if (recordType.equalsIgnoreCase("MCR") && medicareElig.size() > 0)
                {
                    if (!medicareElig.isEmpty() && (null != lastName || null != dob || null != providerState))
                    {
                        medicareElig = filterEligBasedOnLastNameDOBAndState(medicareElig, lastName, dob, providerState);
                    }
                    if (!medicareElig.isEmpty())
                    {
                        return medicareElig;
                    }
                }
                else if (recordType.equalsIgnoreCase("MCD") && medicaidElig.size() > 0)
                {
                    if (!medicaidElig.isEmpty() && (null != lastName || null != dob || null != providerState))
                    {
                        medicaidElig = filterEligBasedOnLastNameDOBAndState(medicaidElig, lastName, dob, providerState);
                    }
                    if (!medicaidElig.isEmpty())
                    {
                        return medicaidElig;
                    }
                }
            }

            // sbsbId
            eligs = getIFacetsMemberDao().getAllEligibilitiesWithNoEligibilityCheckByAmerigroupID(sbsbId);
            List<FacetsMemberEligibilityDto> resultantElig = new ArrayList<FacetsMemberEligibilityDto>();
            for (FacetsMemberEligibilityDto dto : eligs)
            {
                if (recordType.equalsIgnoreCase("BOTH"))
                {
                    if (dto.sourceSystem.equalsIgnoreCase("MDCD") || dto.sourceSystem.equalsIgnoreCase("MDCR")
                            || dto.sourceSystem.equalsIgnoreCase("MDDD"))
                    {
                        resultantElig.add(dto);
                    }
                }
                else if (recordType.equalsIgnoreCase("MCR"))
                {
                    if (dto.sourceSystem.equalsIgnoreCase("MDCR") || dto.sourceSystem.equalsIgnoreCase("MDDD"))
                    {
                        resultantElig.add(dto);
                    }

                }
                else if (recordType.equalsIgnoreCase("MCD"))
                {
                    if (dto.sourceSystem.equalsIgnoreCase("MDCD") || dto.sourceSystem.equalsIgnoreCase("MDDD"))
                    {
                        resultantElig.add(dto);
                    }
                }
            }

            if (resultantElig.size() > 0)
            {
                if (null != lastName || null != dob || null != providerState)
                {
                    eligs = filterEligBasedOnLastNameDOBAndState(resultantElig, lastName, dob, providerState);
                    return eligs;
                }
            }
            return resultantElig;

        }
        return eligs;
    }

    /**
     *
     * This method fetches all the eligibilities with the condition MEPE_ELIG_IND in the query.
     *
     * @param healthCardId
     * @param sbsbId
     * @param medicaidId
     * @param medicareId
     * @return
     */
    private List<FacetsMemberEligibilityDto> getAllEligibilitiesWithEligibilityCheck(String healthCardId, String sbsbId,
                                                                                     String medicaidId, String medicareId, String providerState, String lastName, String dob, String recordType)
    {
        List<FacetsMemberEligibilityDto> eligs = new ArrayList<FacetsMemberEligibilityDto>();

        //fetch the eligibilities with SBSB_ID only when HCID is given.
        if (!Text.isEffectivelyEmptyOrNull(healthCardId) && Text.isEffectivelyEmptyOrNull(medicaidId)
                && Text.isEffectivelyEmptyOrNull(medicareId))
        {
            eligs = getIFacetsMemberDao().getAllEligibilitiesByAmerigroupID(sbsbId);
            if (eligs == null || eligs.isEmpty() || eligs.size() <= 0)
            {
                eligs = getIFacetsMemberDao().getAllEligibilityByINMedicaidID(sbsbId);
            }
        }
        //fetch the eligibilities with MEDCD_NO only when medicaidId is given.
        else if (Text.isEffectivelyEmptyOrNull(healthCardId) && !Text.isEffectivelyEmptyOrNull(medicaidId)
                && Text.isEffectivelyEmptyOrNull(medicareId))
        {
            eligs = getIFacetsMemberDao().getAllEligibilityByMedicaidID(medicaidId);
            if (eligs == null || eligs.isEmpty() || eligs.size() <= 0)
            {
                eligs = getIFacetsMemberDao().getAllEligibilityByMedicaidIDWithMDCRGrpType(medicaidId);

                if (eligs == null || eligs.isEmpty() || eligs.size() <= 0)
                {
                    eligs = getIFacetsMemberDao().getAllEligibilitiesByAmerigroupID(medicaidId);
                }

            }
        }
        //fetch the eligibilities with HCIN_ID only when medicareId is given.
        else if (Text.isEffectivelyEmptyOrNull(healthCardId) && Text.isEffectivelyEmptyOrNull(medicaidId)
                && !Text.isEffectivelyEmptyOrNull(medicareId))
        {
            eligs = getIFacetsMemberDao().getAllEligibilityByCurrentMedicareID(medicareId);
            if (eligs == null || eligs.isEmpty() || eligs.size() <= 0)
            {
                eligs = getIFacetsMemberDao().getAllEligibilityByOldMedicareID(medicareId);
            }
        }
        //fetch the eligibilities with SBSB_ID first and if there isn't data then fetch with MEDCD_NO when both HCID and meicaidId are given and both are same values.
        else if (!Text.isEffectivelyEmptyOrNull(healthCardId) && !Text.isEffectivelyEmptyOrNull(medicaidId)
                && (healthCardId.equalsIgnoreCase(medicaidId) || sbsbId.equalsIgnoreCase(medicaidId))
                && Text.isEffectivelyEmptyOrNull(medicareId))
        {
            eligs = getIFacetsMemberDao().getAllEligibilitiesByAmerigroupID(sbsbId);
            if (eligs == null || eligs.size() <= 0)
            {
                eligs = getIFacetsMemberDao().getAllEligibilityByMedicaidID(medicaidId);

            }
        }
        //fetch the eligibilities with SBSB_ID when both HCID and meicareId are given.
        else if (!Text.isEffectivelyEmptyOrNull(healthCardId) && Text.isEffectivelyEmptyOrNull(medicaidId)
                && !Text.isEffectivelyEmptyOrNull(medicareId))
        {
            eligs = getIFacetsMemberDao().getAllEligibilitiesByAmerigroupID(sbsbId);
        }

        if (!Text.isEffectivelyEmptyOrNull(healthCardId) && !Text.isEffectivelyEmptyOrNull(medicaidId)
                && !Text.isEffectivelyEmptyOrNull(medicareId)
                && (sbsbId.equalsIgnoreCase(medicaidId) || healthCardId.equalsIgnoreCase(medicaidId))
                && (sbsbId.equalsIgnoreCase(medicareId) || healthCardId.equalsIgnoreCase(medicareId)))
        {

            List<FacetsMemberEligibilityDto> medicaidElig = new ArrayList<FacetsMemberEligibilityDto>();
            List<FacetsMemberEligibilityDto> medicareElig = new ArrayList<FacetsMemberEligibilityDto>();

            // medicare
            if (recordType.equalsIgnoreCase("BOTH") || recordType.equalsIgnoreCase("MCR"))
            {
                medicareElig = getIFacetsMemberDao().getAllEligibilityByCurrentMedicareID(medicareId);
                if (medicareElig == null || medicareElig.isEmpty() || medicareElig.size() <= 0)
                {
                    medicareElig = getIFacetsMemberDao().getAllEligibilityByOldMedicareID(medicareId);
                }
            }

            // mdedicaid
            if (recordType.equalsIgnoreCase("BOTH") || recordType.equalsIgnoreCase("MCD"))
            {
                medicaidElig = getIFacetsMemberDao().getAllEligibilityByMedicaidID(medicaidId);
            }

            if (medicareElig.size() > 0 || medicaidElig.size() > 0)
            {
                if (recordType.equalsIgnoreCase("BOTH"))
                {
                    medicareElig.addAll(medicaidElig);
                    if (!medicareElig.isEmpty() && (null != lastName || null != dob || null != providerState))
                    {
                        medicareElig = filterEligBasedOnLastNameDOBAndState(medicareElig, lastName, dob, providerState);
                    }
                    if (!medicareElig.isEmpty())
                    {
                        return medicareElig;
                    }
                }
                else if (recordType.equalsIgnoreCase("MCR") && medicareElig.size() > 0)
                {
                    if (!medicareElig.isEmpty() && (null != lastName || null != dob || null != providerState))
                    {
                        medicareElig = filterEligBasedOnLastNameDOBAndState(medicareElig, lastName, dob, providerState);
                    }
                    if (!medicareElig.isEmpty())
                    {
                        return medicareElig;
                    }
                }
                else if (recordType.equalsIgnoreCase("MCD") && medicaidElig.size() > 0)
                {
                    if (!medicaidElig.isEmpty() && (null != lastName || null != dob || null != providerState))
                    {
                        medicaidElig = filterEligBasedOnLastNameDOBAndState(medicaidElig, lastName, dob, providerState);
                    }
                    if (!medicaidElig.isEmpty())
                    {
                        return medicaidElig;
                    }
                }
            }

            // sbsbId
            eligs = getIFacetsMemberDao().getAllEligibilitiesByAmerigroupID(sbsbId);
            List<FacetsMemberEligibilityDto> resultantElig = new ArrayList<FacetsMemberEligibilityDto>();
            for (FacetsMemberEligibilityDto dto : eligs)
            {
                if (recordType.equalsIgnoreCase("BOTH"))
                {
                    if (dto.sourceSystem.equalsIgnoreCase("MDCD") || dto.sourceSystem.equalsIgnoreCase("MDCR")
                            || dto.sourceSystem.equalsIgnoreCase("MDDD"))
                    {
                        resultantElig.add(dto);
                    }
                }
                else if (recordType.equalsIgnoreCase("MCR"))
                {
                    if (dto.sourceSystem.equalsIgnoreCase("MDCR") || dto.sourceSystem.equalsIgnoreCase("MDDD"))
                    {
                        resultantElig.add(dto);
                    }

                }
                else if (recordType.equalsIgnoreCase("MCD") || dto.sourceSystem.equalsIgnoreCase("MDDD"))
                {
                    if (dto.sourceSystem.equalsIgnoreCase("MDCD"))
                    {
                        resultantElig.add(dto);
                    }
                }
            }

            if (resultantElig.size() > 0)
            {
                if (null != lastName || null != dob || null != providerState)
                {
                    eligs = filterEligBasedOnLastNameDOBAndState(resultantElig, lastName, dob, providerState);
                    return eligs;
                }
            }
            return resultantElig;

        }

        return eligs;

    }

    private List<FacetsMemberEligibilityDto> filterEligBasedOnLastNameDOBAndState(
            List<FacetsMemberEligibilityDto> eligs, String lastName, String dob, String providerState)
    {
        List<FacetsMemberEligibilityDto> dtoList = new ArrayList<FacetsMemberEligibilityDto>();
        SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd");

        for (FacetsMemberEligibilityDto dto : eligs)
        {// need to check date comaparision
            if (!Text.isEffectivelyEmptyOrNull(lastName) || !Text.isEffectivelyEmptyOrNull(dob)
                    || !Text.isEffectivelyEmptyOrNull(providerState))
            {
                String dt = null;
                if (null != dto.birthDt)
                {
                    dt = sdformat.format(dto.birthDt);
                }
                // lastName , dob
                if (!Text.isEffectivelyEmptyOrNull(lastName) && !Text.isEffectivelyEmptyOrNull(dob)
                        && Text.isEffectivelyEmptyOrNull(providerState))
                {
                    if ((dto.fullLastName.replaceAll(REMOVE_SPACE_SPECIALCHAR, "").toLowerCase().trim()
                            .contains(lastName.replaceAll(REMOVE_SPACE_SPECIALCHAR, "").toLowerCase().trim()))
                            && (dt.compareTo(dob) == 0))
                    {
                        dtoList.add(dto);
                    }
                    // lastName , dob,providerState
                }
                else if (!Text.isEffectivelyEmptyOrNull(lastName) && !Text.isEffectivelyEmptyOrNull(dob)
                        && !Text.isEffectivelyEmptyOrNull(providerState))
                {
                    if ((dto.fullLastName.replaceAll(REMOVE_SPACE_SPECIALCHAR, "").toLowerCase().trim()
                            .contains(lastName.replaceAll(REMOVE_SPACE_SPECIALCHAR, "").toLowerCase().trim()))
                            && (dt.compareTo(dob) == 0) && dto.groupID.startsWith(providerState))
                    {
                        dtoList.add(dto);
                    }
                } // lastName , providerState
                else if (!Text.isEffectivelyEmptyOrNull(lastName) && Text.isEffectivelyEmptyOrNull(dob)
                        && !Text.isEffectivelyEmptyOrNull(providerState))
                {
                    if ((dto.fullLastName.replaceAll(REMOVE_SPACE_SPECIALCHAR, "").toLowerCase().trim()
                            .contains(lastName.replaceAll(REMOVE_SPACE_SPECIALCHAR, "").toLowerCase().trim()))
                            && dto.groupID.startsWith(providerState))
                    {
                        dtoList.add(dto);
                    }
                    //dob,providerState
                }
                else if (Text.isEffectivelyEmptyOrNull(lastName) && !Text.isEffectivelyEmptyOrNull(dob)
                        && !Text.isEffectivelyEmptyOrNull(providerState))
                {
                    if ((dt.compareTo(dob) == 0) && dto.groupID.startsWith(providerState))
                    {
                        dtoList.add(dto);
                    }
                    //providerState
                }
                else if (Text.isEffectivelyEmptyOrNull(lastName) && Text.isEffectivelyEmptyOrNull(dob)
                        && !Text.isEffectivelyEmptyOrNull(providerState))
                {
                    if (dto.groupID.startsWith(providerState))
                    {
                        dtoList.add(dto);
                    }
                } //dob
                else if (Text.isEffectivelyEmptyOrNull(lastName) && Text.isEffectivelyEmptyOrNull(providerState)
                        && !Text.isEffectivelyEmptyOrNull(dob))
                {
                    if (dt.compareTo(dob) == 0)
                    {
                        dtoList.add(dto);
                    }
                } // lastName
                else if (!Text.isEffectivelyEmptyOrNull(lastName) && Text.isEffectivelyEmptyOrNull(providerState)
                        && Text.isEffectivelyEmptyOrNull(dob))
                {

                    if (dto.fullLastName.replaceAll(REMOVE_SPACE_SPECIALCHAR, "").toLowerCase().trim()
                            .contains(lastName.replaceAll(REMOVE_SPACE_SPECIALCHAR, "").toLowerCase().trim()))
                    {
                        dtoList.add(dto);

                    }
                }
            }
			/*else
			{
				dtoList.add(dto);
			}*/
        }

        return dtoList;

    }

    /**
     * This method checks the restrictions for one of the member eligibilities and throws MemberRestrictionException if
     * there are any active restrictions. This method only checks for CROSSOVER, HIPPA and SRI restrictions.
     *
     * @param eligibilities
     */
    private void checkForRestrictions(List<FacetsMemberEligibilityDto> eligibilities)
    {
        FacetsMemberMemberDetailsDto eligibility = getIFacetsMemberDao().getEligibilityBySbrUidAndEligibilityDates(
                eligibilities.get(0).sbsbCK, eligibilities.get(0).dateEffective, eligibilities.get(0).dateTermination);

        MemberEligibilityDetails med = transformEligibilityDetails(eligibility);

        RestrictionType[] restrictionsToEnforce;

        if (eligibility != null && eligibility.groupType != null && eligibility.groupType.equalsIgnoreCase(MARKET_MCD))
        {
            restrictionsToEnforce = new RestrictionType[] { RestrictionType.CROSSOVER, RestrictionType.SRI };
        }
        else
        {
            restrictionsToEnforce = new RestrictionType[] { RestrictionType.CROSSOVER, RestrictionType.HIPAA,
                    RestrictionType.SRI };
        }

        IRestrictionManager restrictionManager = getRestrictionManager();

        List<RestrictionType> activeRestrictions = restrictionManager
                .getRestrictionsByMemberEligibilityDetailsAndRestrictionTypes(med,
                        Arrays.asList(restrictionsToEnforce));

        if (activeRestrictions != null && !activeRestrictions.isEmpty())
        {
            throw new MemberRestrictionException(
                    "Member is being blocked to perform this operation with restrictions: ", activeRestrictions);
        }
    }

    /**
     * This transformation method is for Service Restriction Manager request.
     *
     * @param eligibility
     * @return
     */
    private MemberEligibilityDetails transformEligibilityDetails(FacetsMemberMemberDetailsDto eligibility)
    {
        MemberEligibilityDetails med = new MemberEligibilityDetails();
        if (eligibility != null)
        {
            med.setClassId(Text.isEffectivelyEmptyOrNull(eligibility.classId) ? "" : eligibility.classId);
            med.setDateOfBirth(eligibility.birthDate);
            med.setEligibilityEffectiveDt(eligibility.eligibilityEffDt);
            med.setEligibilityTerminationDt(eligibility.eligibilityTermDt);
            med.setFirstName(Text.isEffectivelyEmptyOrNull(eligibility.firstName) ? "" : eligibility.firstName);
            med.setGrgrCK(Text.isEffectivelyEmptyOrNull(eligibility.groupCk) ? "" : eligibility.groupCk);
            med.setGroupId(Text.isEffectivelyEmptyOrNull(eligibility.groupId) ? "" : eligibility.groupId);
            med.setLastName(Text.isEffectivelyEmptyOrNull(eligibility.lastName) ? "" : eligibility.lastName);
            med.setLineOfBusiness(
                    Text.isEffectivelyEmptyOrNull(eligibility.lineOfBusiness) ? "" : eligibility.lineOfBusiness);
            med.setSubGroupId(Text.isEffectivelyEmptyOrNull(eligibility.subGroup) ? "" : eligibility.subGroup);
            med.setMedicaidID(Text.isEffectivelyEmptyOrNull(eligibility.medicaidId) ? "" : eligibility.medicaidId);
            med.setPlanId(Text.isEffectivelyEmptyOrNull(eligibility.planId) ? "" : eligibility.planId);
            med.setProductId(Text.isEffectivelyEmptyOrNull(eligibility.productId) ? "" : eligibility.productId);
            med.setMedicareID(Text.isEffectivelyEmptyOrNull(eligibility.medicareId) ? "" : eligibility.medicareId);
            med.setMemberCK(Text.isEffectivelyEmptyOrNull(eligibility.memberCk) ? "" : eligibility.memberCk);
            med.setMiddleName(
                    Text.isEffectivelyEmptyOrNull(eligibility.middleInitial) ? "" : eligibility.middleInitial);
            med.setRegion(Text.isEffectivelyEmptyOrNull(eligibility.region) ? "" : eligibility.region);
            med.setSubscriberCK(Text.isEffectivelyEmptyOrNull(eligibility.sbrUid) ? "" : eligibility.sbrUid);
            med.setSubscriberId(
                    Text.isEffectivelyEmptyOrNull(eligibility.subscriberId) ? "" : eligibility.subscriberId);

            if (eligibility.eligibilityEffDt != null && eligibility.eligibilityTermDt != null
                    && DateUtilities.isApproximatelyOnOrAfter(new Date(), eligibility.eligibilityEffDt)
                    && DateUtilities.isApproximatelyOnOrBefore(new Date(), eligibility.eligibilityTermDt))
            {
                med.setCurrentEligibilityDetails(true);
            }
            else if (eligibility.eligibilityEffDt != null
                    && DateUtilities.isApproximatelyOnOrBefore(new Date(), eligibility.eligibilityEffDt))
            {
                med.setFutureEligibilityDetails(true);
            }
            else if (eligibility.eligibilityTermDt != null
                    && DateUtilities.isApproximatelyOnOrAfter(new Date(), eligibility.eligibilityTermDt))
            {
                med.setPastEligibilityDetails(true);
            }

        }
        return med;
    }

    /**
     *
     * This method filters the eligibilities based on the dates. If the startDt and endDt are null then it converts and
     * returns only the current eligibility where current date falls between elig eff date and term date.
     *
     * @param eligibilities
     * @param address
     * @param dualCitizenshipDetails
     * @param startDt
     * @param endDt
     * @return
     */
    private List<MemberEligibilityResponse.MemberEligibility> getFilteredAndTransformedEligList(
            List<FacetsMemberEligibilityDto> eligibilities, FacetsMemberAddressDto address,
            List<FacetsMemberDualCitizenshipDetailsDto> dualCitizenshipDetails, Date startDt, Date endDt,
            boolean isMcidRequired, String stateCd)
    {
        List<MemberEligibilityResponse.MemberEligibility> eligList = new ArrayList<MemberEligibilityResponse.MemberEligibility>();

        String mcID = "";
        if (isMcidRequired)
        {
            mcID = getMcid(eligibilities.get(0).sbsbID);
        }

        for (FacetsMemberEligibilityDto dto : eligibilities)
        {
            String memberState = Text.isEffectivelyEmptyOrNull(dto.groupID) ? null : dto.groupID.substring(0, 2);
            if (startDt == null && endDt == null)
            {
                if ((new Date().getTime() >= dto.dateEffective.getTime()
                        || DateUtilities.sameDay(new Date(), dto.dateEffective))
                        && (new Date().getTime() <= dto.dateTermination.getTime()
                        || DateUtilities.sameDay(new Date(), dto.dateTermination)))
                {
                    List<DualCitizenshipDetails> dualDetailsToAdd = getMatchingDualCitizenshipDetails(dto,
                            dualCitizenshipDetails);

                    if (stateCd == null || (stateCd != null && Text.effectivelySame(stateCd, memberState)))
                    {
                        eligList.add(convertEligibility(dto, address, dualDetailsToAdd, mcID, startDt));
                    }

                    break;
                }
            }
            else if (dto.dateEffective != null && dto.dateTermination != null
                    && dto.dateEffective.getTime() <= endDt.getTime()
                    && dto.dateTermination.getTime() >= startDt.getTime())
            {
                List<DualCitizenshipDetails> dualDetailsToAdd = getMatchingDualCitizenshipDetails(dto,
                        dualCitizenshipDetails);

                if (stateCd == null || (stateCd != null && Text.effectivelySame(stateCd, memberState)))
                {
                    eligList.add(convertEligibility(dto, address, dualDetailsToAdd, mcID, startDt));

                }
            }

        }

        return eligList;
    }

    /**
     * This method matches the right dual citizenship details to the right eligibility when elig eff date, elig term
     * date overlaps with dual spn eff date, dual spn term date.
     *
     * @param dto
     * @param dualCitizenshipDetails
     * @return
     */
    private List<DualCitizenshipDetails> getMatchingDualCitizenshipDetails(FacetsMemberEligibilityDto dto,
                                                                           List<FacetsMemberDualCitizenshipDetailsDto> dualCitizenshipDetails)
    {
        List<DualCitizenshipDetails> dualDetailsToAdd = new ArrayList<DualCitizenshipDetails>();

        for (FacetsMemberDualCitizenshipDetailsDto dualDto : dualCitizenshipDetails)
        {
            if (dualDto.dualSpanStartDt != null && dualDto.dualSpanEndDt != null
                    && dto.dateEffective.getTime() <= dualDto.dualSpanEndDt.getTime()
                    && dto.dateTermination.getTime() >= dualDto.dualSpanStartDt.getTime())
            {
                dualDetailsToAdd.add(convertDualDetails(dualDto));
            }
        }

        return dualDetailsToAdd;
    }

    /**
     * This method converts the dao data to response object data.
     *
     * @param e
     * @param address
     * @param dualDetails
     * @return
     */
    private MemberEligibilityResponse.MemberEligibility convertEligibility(FacetsMemberEligibilityDto e,
                                                                           FacetsMemberAddressDto address, List<DualCitizenshipDetails> dualDetails, String mcId, Date startDt)
    {

        Map<String, String> coverageTypeMap = new HashMap<String, String>();
        coverageTypeMap.put("D", "Dental");
        coverageTypeMap.put("L", "Long Term Disability");
        coverageTypeMap.put("M", "Medical");
        coverageTypeMap.put("S", "Short Term Disability");
        coverageTypeMap.put("W", "Workers Compensation");
        coverageTypeMap.put("P", "Pharmacy");

        MemberEligibilityResponse.MemberEligibility elig = new MemberEligibilityResponse.MemberEligibility();

        elig.setFirstName(Text.nullSafeTrim(e.firstName, ""));
        elig.setLastName(Text.nullSafeTrim(e.lastName, ""));
        if (e.birthDt != null)
            elig.setDateOfBirth(e.birthDt);
        elig.setLobdId(Text.nullSafeTrim(e.lobId, ""));

        if (address != null && address.zip != null)
        {
            elig.setHomeZip(address.zip);
        }

        if (e.groupID != null && e.groupID.contains("WNY"))
        {
            elig.setMarket("WNY");
        }
        else if (e.groupID != null)
        {
            String market = e.groupID.length() > 0 ? e.groupID.substring(0, 2) : "";
            elig.setMarket(market);
        }

        if (!Text.isEffectivelyEmptyOrNull(e.coverageTypeCode))
        {
            elig.setCoverageTypeDescription(Text.nullSafeTrim(coverageTypeMap.get(e.coverageTypeCode), ""));
        }
        else
            elig.setCoverageTypeDescription("");

        elig.setSbrUid(Text.nullSafeTrim(e.sbsbCK, ""));
        elig.setClassId(Text.nullSafeTrim(e.classID, ""));
        if (e.dateEffective != null)
            elig.setDateEffective(e.dateEffective);
        if (e.dateTermination != null)
            elig.setDateTermination(e.dateTermination);
        elig.setGroupId(Text.nullSafeTrim(e.groupID, ""));
        elig.setSubgroupId(Text.nullSafeTrim(e.subgroupType, "")); //elig.subgroupID = e.subgroupType;
        elig.setPlanId(Text.nullSafeTrim(e.planID, ""));
        elig.setPlanDescription(Text.nullSafeTrim(e.planDesc, ""));
        elig.setProductDescription(Text.nullSafeTrim(e.productDescription, ""));
        elig.setProductId(Text.nullSafeTrim(e.productID, ""));
        elig.setProductValueCode(Text.nullSafeTrim(e.productValueCode, ""));
        elig.setProductValueCodeDesc(Text.nullSafeTrim(e.productValueCodeDesc, ""));
        elig.setProductName(Text.nullSafeTrim(e.productName, ""));
        elig.setMedicaidId(Text.nullSafeTrim(e.medicaidID, ""));
        elig.setMedicareId(Text.nullSafeTrim(e.medicareID, ""));
        elig.setCoverageTypeCode(Text.nullSafeTrim(e.coverageTypeCode, ""));
        elig.setEligibilityStatusCode(Text.nullSafeTrim(e.statusCode, ""));
        elig.setGroupName(Text.nullSafeTrim(e.groupName, ""));
        elig.setSubGroupName(Text.nullSafeTrim(e.subGroupName, ""));
        if (e.subGroupEffectiveDate != null)
            elig.setSubGroupEffectiveDate(e.subGroupEffectiveDate);
        if (e.subGroupTerminationDate != null)
            elig.setSubGroupTerminationDate(e.subGroupTerminationDate);
        elig.setSubGroupNbr(Text.nullSafeTrim(e.subGroupId, "")); //elig.subGroupNbr = e.subGroupId;

        if (!Text.isEffectivelyEmptyOrNull(e.sourceSystem)
                && ((e.sourceSystem.equalsIgnoreCase("MDCD")) || (e.sourceSystem.equalsIgnoreCase("MDDD"))))
        {
            elig.setSourceSystem("GBDFACETS");
        }
        else if (!Text.isEffectivelyEmptyOrNull(e.sourceSystem) && (e.sourceSystem.equalsIgnoreCase("MDCR")))
        {
            elig.setSourceSystem("MEDISYS");
        }
        else
        {
            elig.setSourceSystem("OTHER");
        }
        if (e.dateTermination != null && e.dateEffective != null
                && DateUtilities.isApproximatelyOnOrBefore(e.dateEffective, new Date())
                && DateUtilities.isApproximatelyOnOrAfter(e.dateTermination, new Date())
                && Text.effectivelySame(e.statusCode, "Y"))
        {
            elig.setActiveStatus("Active");
        }
        else if (e.dateTermination != null && e.dateEffective != null
                && DateUtilities.isApproximatelyOnOrAfter(e.dateEffective, new Date())
                && DateUtilities.isApproximatelyOnOrAfter(e.dateTermination, new Date()))
        {
            elig.setActiveStatus("Future Active");
        }
        else
        //if (e.dateTermination != null && new Date().after(e.dateTermination))
        {
            elig.setActiveStatus("Inactive");
        }

        if (!Text.isEffectivelyEmptyOrNull(e.sourceSystem))
        {
            if (e.sourceSystem.contains("MDCR") || e.sourceSystem.contains("MDDD"))

            {
                elig.setType("MEDICARE");
            }
            else if (e.sourceSystem.contains("MDCD"))
            {
                elig.setType("MEDICAID");
            }
        }

        elig.setStrategicBusinessTypeCode(getStrategicBusinessTypeCode(e.groupID, e.productValueCode));

        elig.setHealthCardId(new MemberEligibilityResponse.HealthCardId(Text.nullSafeTrim(
                getPrefix(e.dateEffective, e.dateTermination, e.groupCk, e.classID, e.coverageTypeCode, e.planID), ""),
                e.sbsbID));

        List<MemberPortalGroupBrandConfigDto> mappings = Collections.emptyList();

        if (null != e.groupID)
        {
            mappings = ((IMemberPortalDao) DaoImplFactory.getInstance().getDaoImpl(IMemberPortalDao.class))
                    .getBrand(e.groupID);

            for (MemberPortalGroupBrandConfigDto mapping : mappings)
            {
                elig.setBrand(Text.nullSafeTrim(mapping.brand, ""));
            }
        }

        elig.setTobaccoStatus(getMemberTobaccoStatus(e.sbsbCK));

        elig.setMarketingBrand(getMemberMarketBrand(e.groupID, e.classID, e.planID, e.productID));

        elig.setPrintingBrand(getMemberPrintBrand(e.groupID, e.classID, e.planID, e.productID));

        elig.setMarketingBrandDesc(getMarketingBrandDesc(e.groupID, e.classID, e.planID, e.productID));

        elig.setPrintingBrandDesc(getPrintBrandDesc(e.groupID, e.classID, e.planID, e.productID));

        elig.setDualCitizenshipDetails(dualDetails);

        elig.setVendorName(getVendorDelegations(e.groupID, e.classID, e.planID, e.dateEffective, e.dateTermination));
        if (Text.effectivelySame(e.sourceSystem, "MDCD") || Text.effectivelySame(e.sourceSystem, "MDDD"))
        {
            elig.setFundingTypeCd("");
            elig.setPlanBenefitPackageID("");
            elig.setCMSContractCode("");
        }
        else
        {
            elig.setFundingTypeCd(getFundingTypeCode(e.groupID, e.sourceSystem));

            elig.setPlanBenefitPackageID(getPlanBenefitPackageId(e.sbsbCK, e.dateEffective, e.dateTermination));

            elig.setCMSContractCode(getCMSContractCode(e.sbsbCK, e.dateEffective, e.dateTermination));
        }
        elig.setComponentDetails(getComponentDetails(e.productID));

        elig.setPlanEntryDate(e.planEntryDt);
        elig.setMcid(mcId);
        elig.setEligRecordUpdatedDate(e.eligibilityCreateDtm);
        elig.setEligNotifyDate(getClaimHoldDate(e));
        elig.setMemeCk(e.memeCk);
        elig.setGroupPhoneNumber(Text.nullSafeTrim(e.grpPhNo, ""));
        //add warning msgList
        addWarningAlerts(elig, e.groupCk);

        return elig;
    }

    private Date getClaimHoldDate(FacetsMemberEligibilityDto e)
    {
        Date notifyDate = null;
        List<FacetsMemberMemberClaimHoldInfoDto> claimInfodto = getIFacetsMemberDao()
                .getMemberClaimHoldDetailsBySbruid(e.sbsbCK, e.dateEffective, e.dateTermination);

        if (claimInfodto != null && !claimInfodto.isEmpty())
            notifyDate = claimInfodto.get(0).termDate;

        return notifyDate;

    }

    /**
     * Find the member vendor code by group/class/plan/dateEffective details
     *
     * @param groupId
     * @param classId
     * @param planId
     * @param dateEffective
     * @return
     */

    public String getVendorDelegations(String groupId, String classId, String planId, Date startDt, Date endDt)
    {
        Date searchStartDate = (startDt == null) ? new Date() : startDt;
        Date searchEndDate = (startDt == null) ? new Date() : endDt;

        List<PreCertVendorInfoDto> vendorCodes = getPrecertDao().getVendorDetailsBetweenDates(groupId, classId, planId,
                searchStartDate, searchEndDate);

        if (vendorCodes != null && !vendorCodes.isEmpty())
        {

            for (PreCertVendorInfoDto preCertVendorInfoDto : vendorCodes)
            {
                if (preCertVendorInfoDto.vendorCode.equalsIgnoreCase(CARE_MORE))
                {
                    return preCertVendorInfoDto.vendorCode;
                }

            }
        }

        return "";

    }

    private String getPrefix(Date dateEffective, Date dateTermination, String groupCk, String classID,
                             String coverageTypeCode, String planID)
    {
        String prefix = "";

        FacetsMemberClassPlanPrefixDto dto = getIFacetsMemberDao().getPrefixByClassPlan(dateTermination, dateEffective,
                groupCk, classID, coverageTypeCode, planID);

        if (dto != null)
            prefix = Text.nullSafeTrim(dto.prefix, "");

        return prefix;
    }

    /**
     * This method transforms the dual information from dao to response object.
     *
     * @param dualDetails
     * @return
     */
    private DualCitizenshipDetails convertDualDetails(FacetsMemberDualCitizenshipDetailsDto dualDetails)
    {
        DualCitizenshipDetails respDual = new DualCitizenshipDetails();

        respDual.medicaidCostshareCategory = dualDetails.medicaidCostShare;
        respDual.dualLink = dualDetails.dualLink;
        respDual.dualSpanEndDt = dualDetails.dualSpanEndDt;
        respDual.dualSpanStartDt = dualDetails.dualSpanStartDt;
        respDual.dualType = dualDetails.dualType;
        respDual.dualTypeDescription = dualDetails.dualTypeDesc;
        respDual.medicaidAidCategory = dualDetails.medicaidAidCategory;
        respDual.requestedGroupId = dualDetails.requestedGroupId;
        respDual.requestedMemeCk = dualDetails.requestedMemeCk;
        respDual.requestedSubscriberId = dualDetails.requestedSubscriberId;
        respDual.targetGroupId = dualDetails.targetGroupId;
        respDual.targetMemeCk = dualDetails.targetMemeCk;
        respDual.targetSubscriberId = dualDetails.targetSubscriberId;

        return respDual;
    }

    /**
     * This method fetches the tobacco status for the given eligibilities SBSB_CK
     *
     * @param sbsb_ck
     * @return
     */
    public String getMemberTobaccoStatus(String sbsb_ck)
    {
        FacetsMemberTobaccoStatusDto tobaccoStatusDto = new FacetsMemberTobaccoStatusDto();

        String tobaccoStatus = "";
        FacetsMemberDB facetsMemberDB = getFacetsMemberDB();
        if (facetsMemberDB != null)
        {
            tobaccoStatusDto = facetsMemberDB.getMemberTobaccoStatus(sbsb_ck);
        }
        if (tobaccoStatusDto != null)
        {
            if ("Y".equalsIgnoreCase(tobaccoStatusDto.categoryValue))
            {
                tobaccoStatus = "Y";
            }
            else if ("N".equalsIgnoreCase(tobaccoStatusDto.categoryValue)
                    || "R".equalsIgnoreCase(tobaccoStatusDto.categoryValue)
                    || "U".equalsIgnoreCase(tobaccoStatusDto.categoryValue))
            {
                tobaccoStatus = "N";
            }
        }
        return tobaccoStatus;
    }

    /**
     * Find the member marketing brand code from group/class/plan/product details
     *
     * @param groupId
     * @param classId
     * @param planId
     * @param productId
     * @return
     */
    public String getMemberMarketBrand(String groupId, String classId, String planId, String productId)
    {
        String brandCode = "";
        String gcpp = groupId + "/" + classId + "/" + planId + "/" + productId;
        List<FacetsMemberMarketBrandDto> marketBranddto = getIFacetsMemberDao().getMemberMarketBrand(gcpp);
        if (marketBranddto != null && !marketBranddto.isEmpty())
        {
            if (marketBranddto.size() == 1)
            {
                brandCode = marketBranddto.get(0).brandCode;
            }
            else
            {
                FacetsMemberMarketBrandDto closestpatterndto = closestMatch(gcpp, marketBranddto);
                brandCode = closestpatterndto.brandCode;
            }

        }
        return brandCode;
    }

    /**
     * Find the member marketing brand code from group/class/plan/product details
     *
     * @param groupId
     * @param classId
     * @param planId
     * @param productId
     * @return
     */
    public String getPrintBrandDesc(String groupId, String classId, String planId, String productId)
    {
        String brandDesc = "";
        String gcpp = groupId + "/" + classId + "/" + planId + "/" + productId;
        List<FacetsMemberMarketBrandDto> marketBranddto = getIFacetsMemberDao().getMemberPrinttBrand(gcpp);
        if (marketBranddto != null && !marketBranddto.isEmpty())
        {
            if (marketBranddto.size() == 1)
            {
                brandDesc = marketBranddto.get(0).brandDesc;
            }
            else
            {
                FacetsMemberMarketBrandDto closestpatterndto = closestMatch(gcpp, marketBranddto);
                brandDesc = closestpatterndto.brandDesc;
            }

        }
        return brandDesc;
    }

    /**
     * Find the member marketing brand code from group/class/plan/product details
     *
     * @param groupId
     * @param classId
     * @param planId
     * @param productId
     * @return
     */
    public String getMarketingBrandDesc(String groupId, String classId, String planId, String productId)
    {
        String brandDesc = "";
        String gcpp = groupId + "/" + classId + "/" + planId + "/" + productId;
        List<FacetsMemberMarketBrandDto> marketBranddto = getIFacetsMemberDao().getMemberMarketBrand(gcpp);
        if (marketBranddto != null && !marketBranddto.isEmpty())
        {
            if (marketBranddto.size() == 1)
            {
                brandDesc = marketBranddto.get(0).brandDesc;
            }
            else
            {
                FacetsMemberMarketBrandDto closestpatterndto = closestMatch(gcpp, marketBranddto);
                brandDesc = closestpatterndto.brandDesc;
            }

        }
        return brandDesc;
    }

    /**
     * Find the member marketing brand code from group/class/plan/product details
     *
     * @param groupId
     * @param classId
     * @param planId
     * @param productId
     * @return
     */
    public String getMemberPrintBrand(String groupId, String classId, String planId, String productId)
    {
        String brandCode = "";
        String gcpp = groupId + "/" + classId + "/" + planId + "/" + productId;
        List<FacetsMemberMarketBrandDto> printBranddto = getIFacetsMemberDao().getMemberPrinttBrand(gcpp);
        if (printBranddto != null && !printBranddto.isEmpty())
        {
            if (printBranddto.size() == 1)
            {
                brandCode = printBranddto.get(0).brandCode;
            }
            else
            {
                FacetsMemberMarketBrandDto closestpatterndto = closestMatch(gcpp, printBranddto);
                brandCode = closestpatterndto.brandCode;
            }

        }
        return brandCode;
    }

    /**
     * finds the closest match between multiple regex patterns
     *
     * @param gcpp
     * @param facetsMemberMarketBrandDto
     * @return
     */
    public static FacetsMemberMarketBrandDto closestMatch(String gcpp,
                                                          List<FacetsMemberMarketBrandDto> facetsMemberMarketBrandDto)
    {

        FacetsMemberMarketBrandDto closestMatch = null;
        for (int i = 0; i < facetsMemberMarketBrandDto.size(); i++)
        {
            String gcppPattern = facetsMemberMarketBrandDto.get(i).gcppPattern;
            for (int j = facetsMemberMarketBrandDto.size() - 1; j > -1; j--)
            {
                if (i != j)
                {
                    if (Pattern.matches(facetsMemberMarketBrandDto.get(j).gcppPattern.replaceAll("\\\\w", "."),
                            gcppPattern.replaceAll("\\\\w", ".")))
                    {
                        closestMatch = facetsMemberMarketBrandDto.get(i);
                        gcppPattern = facetsMemberMarketBrandDto.get(i).gcppPattern;
                    }
                }

            }
        }
        LOG.info("Closest match :" + closestMatch.gcppPattern);
        return closestMatch;

    }

    /**
     * For use with mocking during unit tests, this will return a new instance of FacetsMemberDB
     *
     * @return new instance of FacetsMemberDB
     */
    protected FacetsMemberDB getFacetsMemberDB()
    {
        return new FacetsMemberDB();
    }

    /**
     * For use with mocking during unit tests, it returns instance of IFacetsmemberDao
     *
     * @return
     */
    protected IFacetsMemberDao getIFacetsMemberDao()
    {
        return (IFacetsMemberDao) DaoImplFactory.getInstance().getDaoImpl(IFacetsMemberDao.class);
    }

    /**
     * method to get Precert DAO instance
     *
     * @return instance of IPreCertDao
     */
    protected IPreCertDao getPrecertDao()
    {
        return (IPreCertDao) DaoImplFactory.getInstance().getDaoImpl(IPreCertDao.class);
    }

    /**
     *
     * @param hcId member's Healthcad Id
     * @return subscriber Id
     */
    private String verifyHCID(String hcId)
    {
        HealthCardID healthCardId = new HealthCardID(Text.nullSafeTrim(hcId));
        return healthCardId.sbsbId;
    }

    /**
     * For mocking during unit testing, this just returns a new HealthCardIDFactory
     *
     * @return new instance of a HealthCardIDFactory
     */
    protected HealthCardIDFactory getHealthCardIDFactory()
    {
        return new HealthCardIDFactory();
    }

    /**
     * This method allows for mocking inside of unit tests
     *
     * @return new instance of APIEligibilityLookup
     */
    protected APIEligibilityLookup getEligibilityLookup()
    {
        return new APIEligibilityLookup();
    }

    /**
     * For use with mocking during unit tests, this returns instance of RestrictionManagerImpl
     *
     * @return
     */
    protected IRestrictionManager getRestrictionManager()
    {
        return new RestrictionManagerImpl();
    }

    /**
     * fetches the PBP id by sbruid and eligibility dates
     *
     * @param sbsbCk
     * @param eligEffDt
     * @param eligTermDt
     * @return
     */
    public String getPlanBenefitPackageId(String sbsbCk, Date eligEffDt, Date eligTermDt)
    {
        FacetsMemberPBPDetailsDto pdbIdDto = getIFacetsMemberDao().getPBPIdBySbrUidAndEligibility(sbsbCk, eligEffDt,
                eligTermDt);
        return (pdbIdDto != null) ? pdbIdDto.pbpId : "";

    }

    /**
     * get the funding type code
     *
     * @param groupID
     * @param groupType
     * @return
     */
    private String getFundingTypeCode(String groupID, String groupType)
    {
        //if the group id is  'INEGR002' then its ASO
        if (!Text.isEffectivelyEmptyOrNull(groupID)
                && (groupID.toUpperCase().equalsIgnoreCase("INEGR002") || groupID.toUpperCase().contains("GRS")))
        {
            return FUNDING_TYPE_CD_ASO;
        }
        else if (Text.effectivelySame(groupType, "MDCR") || Text.effectivelySame(groupType, "MDDD"))
        {
            return FUNDING_TYPE_CD_FI;
        }
        // returning null for all the medicaid markets.S
        return null;
    }

    /**
     *
     * @param productID
     * @return
     */
    private List<ComponentDetails> getComponentDetails(String productID)
    {
        List<FacetsMemberBillingComponentDto> componentDtos = getIFacetsMemberDao().getBillingComponentID(productID);

        List<ComponentDetails> components = new ArrayList<ComponentDetails>();

        if (componentDtos != null && !componentDtos.isEmpty())
        {
            for (FacetsMemberBillingComponentDto component : componentDtos)
            {
                ComponentDetails componentDetail = new ComponentDetails();
                componentDetail.setComponentID(component.billingComponentId);
                componentDetail.setComponentDescription(component.billingComponentDesc);
                components.add(componentDetail);
            }

        }
        return components;
    }

    /**
     * fetch the BGBG id for a member by eligibility dates
     *
     * @param sbsbCK
     * @param eligEffDt
     * @param eligTermDt
     * @return
     */
    private String getCMSContractCode(String sbsbCK, Date eligEffDt, Date eligTermDt)
    {
        FacetsMemberBillingGroupDto cmcContractCdDto = getIFacetsMemberDao()
                .getCMSContractIdBySbrUidAndEligibilityDates(sbsbCK, eligEffDt, eligTermDt);

        return (cmcContractCdDto != null) ? cmcContractCdDto.federalContractId : "";
    }

    /**
     * find the strategic business type by a group id
     *
     * @param groupID
     * @param productValueCd
     * @return
     */
    private String getStrategicBusinessTypeCode(String groupID, String productValueCd)
    {

        String StrategicBusinessTypeCode = null;
        if (!Text.isEffectivelyEmptyOrNull(groupID))
        {
            if (groupID.toUpperCase().contains("SUP"))
            {
                StrategicBusinessTypeCode = "MedSupp";
            }
            else if (groupID.toUpperCase().contains("EGR") || groupID.toUpperCase().contains("GRS"))
            {
                StrategicBusinessTypeCode = "GRS";
            }
            else if (groupID.toUpperCase().contains("MCR"))
            {

                StrategicBusinessTypeCode = MedicareStrategicTypeMap.getInstance().get(productValueCd);

            }
            else if (groupID.toUpperCase().contains("MCD") || groupID.toUpperCase().contains("SETON"))
            {
                StrategicBusinessTypeCode = "MedicaidAGP";
            }
            else if (groupID.contains("MMP"))
            {
                StrategicBusinessTypeCode = "MMP";
            }
            else
            {
                StrategicBusinessTypeCode = "OTHER";
            }
        }
        else
        {
            StrategicBusinessTypeCode = "OTHER";
        }

        return StrategicBusinessTypeCode;
    }

    private void addWarningAlerts(MemberEligibilityResponse.MemberEligibility elig, String groupCK)
    {

        List<FacetsMemberMemberFullAlertTextDto> mbrAlertTextDtoList = getIFacetsMemberDao().getMemberWarningMsg(
                elig.getHealthCardId().getSubscriberId(), elig.getDateEffective(), elig.getDateTermination());

        List<FacetsMemberPlanFullAlertTextDto> mbrPlanAlertTextDtoList = getIFacetsMemberDao().getPlanWarningMsg(
                groupCK, elig.getClassId(), elig.getPlanId(), elig.getProductId(), elig.getDateEffective(),
                elig.getDateTermination());
        List<WarningMessages> wrngMsgList = elig.getWarningMessages();

        WarningMessages msg = null;

        for (FacetsMemberMemberFullAlertTextDto mbrdto : mbrAlertTextDtoList)
        {
            msg = new WarningMessages();
            msg.setMessageType("Member");
            msg.setSeqNo(mbrdto.seqNo);
            msg.setWarningMessage((mbrdto.text1 + " " + mbrdto.text2).trim());
            msg.setStartDate(mbrdto.effDate);
            msg.setEndDate(mbrdto.termDate);
            wrngMsgList.add(msg);
        }

        for (FacetsMemberPlanFullAlertTextDto plandto : mbrPlanAlertTextDtoList)
        {
            msg = new WarningMessages();
            msg.setMessageType("Plan");
            msg.setSeqNo(plandto.seqNo);
            msg.setWarningMessage((plandto.text1 + " " + plandto.text2).trim());
            msg.setStartDate(plandto.effDate);
            msg.setEndDate(plandto.termDate);
            wrngMsgList.add(msg);
        }

        elig.setWarningMessages(wrngMsgList);

    }

    private String getMcid(String subScriberId)
    {

        String mcid = "";
        LOG.info("Before getMcid ::subScriberId::" + subScriberId);
        try
        {
            ESOAApiCallUtil eSOAApiCallUtil = new ESOAApiCallUtil();
            Root prsns = eSOAApiCallUtil.getMCIDResponse(subScriberId);
            for (Person person : prsns.getPersons())
            {
                for (Relationship rlnship : person.getPerson().getRelationships())
                {
                    mcid = rlnship.getRelationship().getId();
                    break;
                }
            }
        }
        catch (Exception ex)
        {
            LOG.error(ex);
        }
        return mcid;
    }

}