package com.anthem.soa.gbd.apimembereligibility.controllers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.beans.BeanUtils;
import com.amerigroup.exception.GeneralErrors;
import com.amerigroup.exception.runtime.ValidationException;
import com.amerigroup.exception.runtime.validation.ArgumentsNotToSpecException;
import com.amerigroup.exception.runtime.validation.MemberNotEligibleException;
import com.amerigroup.exception.runtime.validation.MemberNotFoundException;
import com.amerigroup.utilities.DateUtilities;
import com.amerigroup.utilities.LoggerFactory;
import com.amerigroup.utilities.Text;
import com.anthem.member.restrictions.RestrictionType;
import com.anthem.member.restrictions.exceptions.MemberRestrictionException;
import com.anthem.soa.gbd.api.APIException;
import com.anthem.soa.gbd.api.APIExceptionElement;
import com.anthem.soa.gbd.api.APIExceptionType;
import com.anthem.soa.gbd.apimembereligibility.models.MemberEligibilityResponse;
import com.anthem.soa.gbd.apimembereligibility.servicelogic.MemberEligibilityService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * 
 * @author Sriharsha Tumati
 * 
 * 
 *         <b>GBDSOA API Reference Impl Notes:</b> <br>
 *         This is a representative RESTful Facade method that delivers member eligibility data to Core GBD Member API
 *         clients.
 * 
 *         The CORERest project provides common exception handling methods for REST projects, leveraging Spring's
 *         'ControllerAdvice' model to catch and transform all exceptions to a standardized 'APIException' json format.
 *         This project also handles metrics logging in a standard way.
 * 
 */

@RestController
@RequestMapping("/v1/gbd/members")
@Api(value = "Member API")
public class MemberApiController {
	/**
	 * pattern for alphanumeric and wild card characters only, no special characters
	 */
	private static final String VALID_ALPHA_NUMERIC_REGEX_PATTERN = "^[a-zA-Z0-9]*$";

	/**
	 * Log4j logger
	 */
	private static final Logger LOG = LoggerFactory.getLogger(MemberApiController.class);

	/**
	 * 
	 * This controller method fetches the member eligibilites from facets based on the search criteria provided in the
	 * request. It also checks the restriction for a member.
	 * 
	 * @param hcId Health card Id of a member
	 * @param medicaidId Medicaid ID of a member
	 * @param startDt if passed both startDt and endDt then this operation fetches the eligibilities during that period
	 * @param endDt if passed both startDt and endDt then this operation fetches the eligibilities during that period
	 * @param eligibilityCheck if the value is true then it fetches the eligibilities only when MEPE_ELIG_IND = "Y".
	 *            Default is true.
	 * @param medicareId Medicare ID of a member
	 * @return
	 */
	@RequestMapping(value = "/eligibility", method = RequestMethod.GET)
	@ApiOperation(value = "Get Eligibility", notes = "operation to get member's eligibility", response = MemberEligibilityResponse.class, tags = {
			"Supported", "Retrieval Operations" })
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Fields are with validation errors."),
			@ApiResponse(code = 200, message = " successfully retrieved eligibilities."),
			@ApiResponse(code = 403, message = "Restrictions Apply, Not Eligible."),
			@ApiResponse(code = 404, message = "Not Found."),
			@ApiResponse(code = 500, message = "Internal Server Error.") })
	public ResponseEntity<MemberEligibilityResponse> getEligibilities(
			@RequestParam(value = "healthCardId", required = false) String hcId,
			@RequestParam(value = "medicaidId", required = false) String medicaidId,
			@RequestParam(value = "startDt", required = false) String startDt,
			@RequestParam(value = "endDt", required = false) String endDt,
			@RequestParam(value = "eligibilityCheck", required = false, defaultValue = "true") boolean eligibilityCheck,
			@RequestParam(value = "medicareId", required = false) String medicareId,
			@RequestParam(value = "isMcidRequired", required = false, defaultValue = "false") boolean isMcidRequired,
			@RequestParam(value = "stateCode", required = false) String stateCode,
			@RequestParam(value = "providerState", required = false) String providerState,
			@RequestParam(value = "lastName", required = false) String lastName,
			@RequestParam(value = "dateOfBirth", required = false) String dateOfBirth,
			@RequestParam(value = "recordType", required = false, defaultValue = "BOTH") String recordType,
			@RequestParam(value = "restrictionCheck", required = false, defaultValue = "true") boolean restrictionCheck)
	{
		LOG.info("MemberApiController:: getEligibilities - request: [ healthCardId = " + hcId + ", medicaidId = "
				+ medicaidId + ", medicareId = " + medicareId + " , startDt = " + startDt + ", endDt = " + endDt
				+ ", eligibilityCheck = " + eligibilityCheck + ", isMcidRequired = " + isMcidRequired + ", stateCode = "
				+ stateCode + " ]");
		long startMillis = System.currentTimeMillis();
		
		RequestVals sanitizedSenderAppRequest = new RequestVals();
		RequestVals requestVals = new RequestVals();
		requestVals.setMedicaidId(medicaidId);
		BeanUtils.copyProperties(requestVals,sanitizedSenderAppRequest);

		//Prepare a JSON Response
		MemberEligibilityResponse resp = new MemberEligibilityResponse();
		

		try
		{
			

			validateInputParams(hcId, sanitizedSenderAppRequest.getMedicaidId(), medicareId, startDt, endDt, dateOfBirth);

			List<MemberEligibilityResponse.MemberEligibility> eligibilities = new MemberEligibilityService()
					.findMemberEligibility(hcId, sanitizedSenderAppRequest.getMedicaidId(), getDateFromString(startDt), getDateFromString(endDt),
							eligibilityCheck, medicareId, isMcidRequired, stateCode, providerState, lastName,
							dateOfBirth, recordType, restrictionCheck);

			if (eligibilities != null && !eligibilities.isEmpty())
			{
				resp.setEligibilities(eligibilities);
			}

		}
		catch (MemberNotFoundException mnfe)
		{
			throw new APIException(HttpStatus.NOT_FOUND, mnfe.getErrorCode(), mnfe.getLocalizedMessage(), mnfe);
		}
		catch (MemberNotEligibleException e)
		{
			return new ResponseEntity<MemberEligibilityResponse>(resp, HttpStatus.OK);
		}
		catch (MemberRestrictionException e)
		{
			handleMemberRestrictionException(e);
		}
		catch (ArgumentsNotToSpecException e)
		{
			if (e.getMessage().contains(GeneralErrors.INPUT_PARAMETER_REQUIRED.getCode()))
			{
				throw new APIException(HttpStatus.BAD_REQUEST, GeneralErrors.INPUT_PARAMETER_REQUIRED.getCode(),
						GeneralErrors.INPUT_PARAMETER_REQUIRED.getDescription(), e);
			}
			else if (e.getMessage().contains(GeneralErrors.INPUT_VALUES_MUST_SAME.getCode()))
			{
				throw new APIException(HttpStatus.BAD_REQUEST, GeneralErrors.INPUT_VALUES_MUST_SAME.getCode(),
						GeneralErrors.INPUT_VALUES_MUST_SAME.getDescription(), e);
			}
			else
			{
				throw new APIException(HttpStatus.BAD_REQUEST, e.getErrorCode(), e.getMessage(), e);
			}
		}
		catch (ValidationException e)
		{
			throw new APIException(HttpStatus.BAD_REQUEST, e.getErrorCode(), e.getMessage(), e);
		}
		MemberEligibilityResponse sanitizedResp = new MemberEligibilityResponse();
		BeanUtils.copyProperties(resp,sanitizedResp);
		LOG.info("<getEligibilities : " + (System.currentTimeMillis() - startMillis) + "ms - " + sanitizedResp);

		return new ResponseEntity<MemberEligibilityResponse>(resp, HttpStatus.OK);

	}

	/**
	 * This method check if the member has multiple restrictions when the MemberRestrictionException is caught and all
	 * the restrictions to the response.
	 * 
	 * @param e represent MemberRestrictionException
	 */
	private static void handleMemberRestrictionException(MemberRestrictionException e)
	{
		List<APIExceptionElement> exceptionList = new ArrayList<APIExceptionElement>();
		Iterator<RestrictionType> rIterator = e.getRestrictons().iterator();
		while (rIterator.hasNext())
		{
			RestrictionType r = rIterator.next();
			exceptionList.add(new APIExceptionElement(APIExceptionType.E, r.getRestrictionName(),
					r.getError().getDescription(), r.getError().getCode()));
		}
		throw new APIException(HttpStatus.FORBIDDEN, exceptionList, e);
	}

	/**
	 * 
	 * Based on the requirements, the input parameter are validated here. If any validation failed then it throws
	 * respective exception.
	 * 
	 * @param hcId
	 * @param medicaidId
	 * @param medicareId
	 * @param startDt
	 * @param endDt
	 */
	private void validateInputParams(String hcId, String medicaidId, String medicareId, String startDt, String endDt,
			String dob)
	{
		Date stDt = null;
		Date enDt = null;

		if (startDt != null && endDt == null)
		{
			LOG.info("Missing End Date. ");
			throw new ValidationException("Missing End Date");
		}
		else if (startDt == null && endDt != null)
		{
			LOG.info("Missing Starte Date. ");
			throw new ValidationException("Missing Start Date");
		}
		else if (startDt != null && endDt != null)
		{
			stDt = getDateFromString(startDt);
			enDt = getDateFromString(endDt);

			if (!DateUtilities.isApproximatelyOnOrBefore(stDt, enDt))
			{
				LOG.info("Start date shouldn't be greater than end date.");
				throw new ValidationException("Start date shouldn't be greater than end date.");
			}
		}

		if (!Text.isEffectivelyEmptyOrNull(dob))
		{
			getDateFromString(dob);
		}

		if (Text.isEffectivelyEmptyOrNull(hcId) && Text.isEffectivelyEmptyOrNull(medicaidId)
				&& Text.isEffectivelyEmptyOrNull(medicareId))
		{
			LOG.info("input parameters must be required. ");
			throw new ArgumentsNotToSpecException(GeneralErrors.INPUT_PARAMETER_REQUIRED.getCode());
		}

		// If two different values are passed in for HCID & Medicaid Id input params, STOP HERE.
		//		if (!Text.isEffectivelyEmptyOrNull(hcId) && !Text.isEffectivelyEmptyOrNull(medicaidId)
		//				&& (!hcId.equalsIgnoreCase(medicaidId)))
		//		{
		//			LOG.error("input values must be the same. ");
		//			throw new ArgumentsNotToSpecException(GeneralErrors.INPUT_VALUES_MUST_SAME.getCode());
		//		}
		// If Medicare Id input params, STOP HERE.
		if (!Text.isEffectivelyEmptyOrNull(medicareId))
		{
			if (!medicareId.matches(VALID_ALPHA_NUMERIC_REGEX_PATTERN))
			{
				LOG.info("medicare Id must be alpha numeric with no special characters and no blank space ");
				throw new ArgumentsNotToSpecException(GeneralErrors.ARGUMENTS_NOT_TO_SPEC.getCode());
			}
		}

	}

	/**
	 * 
	 * This method is used to convert the string formatted date("yyyy-MM-dd") to Java Util Date. This method hasn't
	 * moved to corefoundation as the format might change from service to service and may be conflicted with other
	 * formats like date having time.
	 * 
	 * @param date
	 * @return Date
	 */
	private Date getDateFromString(String date)
	{
		Date dt = null;

		if (date != null)
		{
			try
			{
				if (!date.matches("\\d{4}-\\d{2}-\\d{2}"))
				{
					throw new ArgumentsNotToSpecException(
							"The date is not in expected format. Please give the date in yyyy-mm-dd format. dd ranges from 01 to 31 and MM ranges from 01 to 12");
				}
				SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
				dateFormatter.setLenient(false);
				dt = dateFormatter.parse(date.trim());
			}
			catch (ParseException e)
			{
				throw new ArgumentsNotToSpecException(
						"The date is not in expected format. Please give the date in yyyy-mm-dd format. dd ranges from 01 to 31 and MM ranges from 01 to 12");
			}
		}

		return dt;
	}

	public class RequestVals
	{
		public String medicaidId;

		public String getMedicaidId()
		{
			return medicaidId;
		}

		public void setMedicaidId(String medicaidId)
		{
			this.medicaidId = medicaidId;
		}
	}
}
