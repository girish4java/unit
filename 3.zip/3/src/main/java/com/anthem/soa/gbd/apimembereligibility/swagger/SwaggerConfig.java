/*
 * package com.elevancehealth.dckr.microsvc.aksgbdsoamembereligibility.swagger;
 * 
 * import java.util.ArrayList; import java.util.List;
 * 
 * import org.springframework.context.annotation.Bean; import
 * org.springframework.context.annotation.Configuration; import
 * org.springframework.web.servlet.config.annotation.EnableWebMvc; import
 * org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
 * import
 * org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
 * 
 * import springfox.documentation.builders.ApiInfoBuilder; import
 * springfox.documentation.builders.ParameterBuilder; import
 * springfox.documentation.builders.PathSelectors; import
 * springfox.documentation.builders.RequestHandlerSelectors; import
 * springfox.documentation.schema.ModelRef; import
 * springfox.documentation.service.ApiInfo; import
 * springfox.documentation.service.Contact; import
 * springfox.documentation.service.Parameter; import
 * springfox.documentation.spi.DocumentationType; import
 * springfox.documentation.spring.web.plugins.ApiSelectorBuilder; import
 * springfox.documentation.spring.web.plugins.Docket; import
 * springfox.documentation.swagger.web.UiConfiguration; import
 * springfox.documentation.swagger2.annotations.EnableSwagger2;
 * 
 * @Configuration
 * 
 * @EnableSwagger2
 * 
 * @EnableWebMvc public class SwaggerConfig extends WebMvcConfigurerAdapter {
 * 
 * @Bean public Docket api() { Docket docket =
 * 
 * // new Docket(DocumentationType.SWAGGER_2); new
 * Docket(DocumentationType.SWAGGER_2).host("virtual.api.anthem.com").
 * pathMapping("/v1/gbd/members") .useDefaultResponseMessages(false);
 * 
 * ApiSelectorBuilder apiSelectorBuilder = docket.select();
 * 
 * //apiSelectorBuilder.apis(RequestHandlerSelectors.any()); // to restrict to
 * specific package apiSelectorBuilder
 * .apis(RequestHandlerSelectors.basePackage(
 * "com.anthem.soa.gbd.apimembereligibility.controllers"));
 * 
 * apiSelectorBuilder.paths(PathSelectors.any()); // PathSelectors provides
 * additional filtering with predicates which scan the request paths of your
 * application //apiSelectorBuilder.paths(PathSelectors.ant("/summary/*")) ;
 * 
 * //Adding Header ParameterBuilder aParameterBuilder1 = new ParameterBuilder();
 * aParameterBuilder1.name("meta-senderapp").
 * description("Name of Sender Application") .modelRef(new
 * ModelRef("string")).parameterType("header").required(true); ParameterBuilder
 * aParameterBuilder2 = new ParameterBuilder();
 * aParameterBuilder2.name("apiKey").description("API Key").modelRef(new
 * ModelRef("string")) .parameterType("header").required(true); ParameterBuilder
 * aParameterBuilder3 = new ParameterBuilder();
 * aParameterBuilder3.name("meta-transid").description("Transaction ID").
 * modelRef(new ModelRef("string")) .parameterType("header").required(false);
 * ParameterBuilder aParameterBuilder4 = new ParameterBuilder();
 * aParameterBuilder4.name("UserName").description("User Name").modelRef(new
 * ModelRef("string")) .parameterType("header").required(false);
 * ParameterBuilder aParameterBuilder5 = new ParameterBuilder();
 * aParameterBuilder5.name("meta-src-envrmt").
 * description("Name of Source Environment") .modelRef(new
 * ModelRef("string")).parameterType("header").required(false); // pagination
 * 
 * List<Parameter> aParameters = new ArrayList<Parameter>();
 * aParameters.add(aParameterBuilder1.build());
 * aParameters.add(aParameterBuilder2.build());
 * aParameters.add(aParameterBuilder3.build());
 * aParameters.add(aParameterBuilder4.build());
 * aParameters.add(aParameterBuilder5.build());
 * 
 * return apiSelectorBuilder.build().apiInfo(apiInfo()).pathMapping("/").
 * globalOperationParameters(aParameters);
 * 
 * //return new
 * Docket(DocumentationType.SWAGGER_2).select().apis(RequestHandlerSelectors.any
 * ()) //
 * .paths(PathSelectors.any()).build().apiInfo(apiInfo()).pathMapping("/"); }
 * 
 * @Bean public UiConfiguration uiConfig() { // public static final String[]
 * DEFAULT_SUBMIT_METHODS = new String[] { "get", "post", "put", "delete",
 * "patch" };
 * 
 * UiConfiguration uiConfiguration = new UiConfiguration("", "none", "alpha",
 * "schema", UiConfiguration.Constants.DEFAULT_SUBMIT_METHODS, true, true);
 * return uiConfiguration;
 * 
 * //new UiConfiguration("", "none", "alpha", "schema",
 * UiConfiguration.Constants.DEFAULT_SUBMIT_METHODS, // true, true, 60000L); }
 * 
 * private ApiInfo apiInfo() {
 * 
 * ApiInfoBuilder apiInfoBuilder = new ApiInfoBuilder();
 * apiInfoBuilder.title("API Member Eligibility"); apiInfoBuilder.description(
 * "The API Member Eligibility is used to retrieve the eligibilties for a member based on serach criteria. "
 * +
 * "Please see the <a href='https://confluence.anthem.com/display/GBDSOA/Member+API'>confluence documentation</a> "
 * +
 * "for more detailed information about how elligibility and restriction checks are implemented along with further details "
 * + "about the individual operations." + "" + "" +
 * "<br><br><b>NOTE:</b> This API is primarily intended to support self service actions. "
 * +
 * "Call Center consumers will find that some operations are restricted according to user self-service restrictions."
 * ); apiInfoBuilder.termsOfServiceUrl(
 * "https://confluence.anthem.com/display/GBDSOA/Member+API");
 * apiInfoBuilder.version("1.7.6"); apiInfoBuilder.license("License of API");
 * 
 * Contact contact = new Contact("Sriharsha Tumati", "", "");
 * apiInfoBuilder.contact(contact);
 * 
 * return apiInfoBuilder.build(); }
 * 
 * @Override public void addResourceHandlers(final ResourceHandlerRegistry
 * registry) {
 * registry.addResourceHandler("swagger-ui.html").addResourceLocations(
 * "classpath:/META-INF/resources/");
 * registry.addResourceHandler("/webjars/**").addResourceLocations(
 * "classpath:/META-INF/resources/webjars/"); }
 * 
 * }
 
package com;*/




