package com.anthem.soa.gbd.apimembereligibility.util;

import java.util.HashMap;

public class MedicareStrategicTypeMap extends HashMap<String, String>
{

	/**
	 * generated UID
	 */
	private static final long serialVersionUID = -3405572178636109270L;

	/**
	 * The single instance of this class
	 */
	private static final MedicareStrategicTypeMap INSTANCE = new MedicareStrategicTypeMap();

	/**
	 * Get the single instance of this class
	 * 
	 * @return the single instance of this class
	 */
	public static MedicareStrategicTypeMap getInstance()
	{
		return INSTANCE;
	}

	/**
	 * Private constructor. Prevents external instantiation and subclassing.
	 */
	private MedicareStrategicTypeMap()
	{
		put("HMO", "MAPD");
		put("HMOS", "Duals");
		put("HMOI", "Duals");
		put("HMOC", "Duals");
		put("HMOD", "Duals");
		put("HMOP", "MAPD");
		put("HMCS", "Duals");
		put("LPPO", "MAPD");
		put("PPOC", "Duals");
		put("PPOD", "Duals");
		put("RPPO", "MAPD");

	}

}
