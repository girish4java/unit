package com.anthem.soa.gbd.apimembereligibility.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * POJO for returning member eligibility information
 * 
 * @author Daniel Spangler
 */
public class MemberEligibilityResponse implements Serializable
{

	/**
	 * because we must
	 */
	private static final long serialVersionUID = 1L;

	private List<MemberEligibility> eligibilities = new ArrayList<MemberEligibility>();

	/**
	 * @return the eligibilities
	 */
	public List<MemberEligibility> getEligibilities()
	{
		return eligibilities;
	}

	/**
	 * @param eligibilities the eligibilities to set
	 */
	public void setEligibilities(List<MemberEligibility> eligibilities)
	{
		this.eligibilities = eligibilities;
	}

	/**
	 * @author AE00065
	 * 
	 */
	public static class MemberEligibility
	{

		/**
		 * This is the API defined subscriber uid that is expected on subsequent calls to the API.
		 */
		private String sbrUid;

		/** This is the class or planClass */
		private String classId;

		/** This is the plan. */
		private String planId;

		/** This is description for the plan of benefits. */
		private String planDescription;

		private String groupId;

		private String subgroupId;

		/** Either MEDICAID or MEDICARE */
		private String type;

		/** ID on Health Card */
		private HealthCardId healthCardId;

		private String mcid;

		/** The product id */
		private String productId;

		/** The name of the product */
		private String productName;

		/** The product description */
		private String productDescription;

		/** The date that the eligibility begins */
		private Date dateEffective;

		/** The date that the eligibility terminates */
		private Date dateTermination;
		/**
		 * The name of the brand
		 */
		private String brand;

		/**
		 * The name of the medicaidId
		 */
		private String medicaidId;

		private String medicareId;

		/**
		 * The name of the coverageTypeCode
		 */
		private String coverageTypeCode;

		/**
		 * The name of the coverageTypeDescription
		 */
		private String coverageTypeDescription;

		/**
		 * The name of the tobacco status
		 */
		private String tobaccoStatus;

		/** Member's First Name */
		private String firstName;

		/** Member's Last name */
		private String lastName;

		/** Member's Date of Birth */
		private Date dateOfBirth;

		/** Member's Line of Business Id */
		private String lobdId;

		/** Member's home address Zip */
		private String homeZip;

		/** Member's Eligibility Status Code */
		private String eligibilityStatusCode;

		/** Member's Active Status */
		private String activeStatus;

		/** Member's Group Name */
		private String groupName;

		/** Member's Sub Group Name */
		private String subGroupName;

		/** Member's Sub Group EffectiveDate */
		private Date subGroupEffectiveDate;

		/** Member's Sub Group TerminationDate */
		private Date subGroupTerminationDate;

		/** Member's Strategic Business Type Code */
		private String strategicBusinessTypeCode;

		/** Member's Sub Group Number */
		private String subGroupNbr;

		/** Member's market */
		private String market;

		/** Source System */
		private String sourceSystem;
		/** Marketing Brand code **/
		private String marketingBrand;

		private String marketingBrandDesc;

		private String printingBrand;

		private String printingBrandDesc;

		private List<DualCitizenshipDetails> dualCitizenshipDetails;

		private String vendorName;

		private String fundingTypeCd;

		private String planBenefitPackageID;

		private String productValueCode;

		private String productValueCodeDesc;

		private String CMSContractCode;

		private List<ComponentDetails> componentDetails = new ArrayList<ComponentDetails>();

		private List<WarningMessages> warningMessages = new ArrayList<WarningMessages>();

		private Date planEntryDate;

		private Date eligRecordUpdatedDate;

		private Date eligNotifyDate;

		private String memeCk;

		private String groupPhoneNumber;

		public String getGroupPhoneNumber()
		{
			return groupPhoneNumber;
		}

		public void setGroupPhoneNumber(String grpPhNo)
		{
			this.groupPhoneNumber = grpPhNo;
		}

		public String getMemeCk()
		{
			return memeCk;
		}

		public void setMemeCk(String memeCk)
		{
			this.memeCk = memeCk;
		}

		public Date getEligRecordUpdatedDate()
		{
			return eligRecordUpdatedDate;
		}

		public void setEligRecordUpdatedDate(Date eligRecordUpdatedDate)
		{
			this.eligRecordUpdatedDate = eligRecordUpdatedDate;
		}

		/**
		 * @return the eligNotifyDate
		 */
		public Date getEligNotifyDate()
		{
			return eligNotifyDate;
		}

		/**
		 * @param eligNotifyDate the eligNotifyDate to set
		 */
		public void setEligNotifyDate(Date eligNotifyDate)
		{
			this.eligNotifyDate = eligNotifyDate;
		}

		public String getMcid()
		{
			return mcid;
		}

		public void setMcid(String mcid)
		{
			this.mcid = mcid;
		}

		public Date getPlanEntryDate()
		{
			return planEntryDate;
		}

		public void setPlanEntryDate(Date planEntryDate)
		{
			this.planEntryDate = planEntryDate;
		}

		public List<WarningMessages> getWarningMessages()
		{
			return warningMessages;
		}

		public void setWarningMessages(List<WarningMessages> warningMessages)
		{
			this.warningMessages = warningMessages;
		}

		/**
		 * @return the groupId
		 */
		public String getGroupId()
		{
			return groupId;
		}

		/**
		 * @param groupId the groupId to set
		 */
		public void setGroupId(String groupId)
		{
			this.groupId = groupId;
		}

		/**
		 * @return the subgroupId
		 */
		public String getSubgroupId()
		{
			return subgroupId;
		}

		/**
		 * @param subgroupId the subgroupId to set
		 */
		public void setSubgroupId(String subgroupId)
		{
			this.subgroupId = subgroupId;
		}

		/**
		 * @return the productId
		 */
		public String getProductId()
		{
			return productId;
		}

		/**
		 * @param productId the productId to set
		 */
		public void setProductId(String productId)
		{
			this.productId = productId;
		}

		/**
		 * @return the productName
		 */
		public String getProductName()
		{
			return productName;
		}

		/**
		 * @param productName the productName to set
		 */
		public void setProductName(String productName)
		{
			this.productName = productName;
		}

		/**
		 * @return the productDescription
		 */
		public String getProductDescription()
		{
			return productDescription;
		}

		/**
		 * @param productDescription the productDescription to set
		 */
		public void setProductDescription(String productDescription)
		{
			this.productDescription = productDescription;
		}

		/**
		 * @return the dateEffective
		 */
		public Date getDateEffective()
		{
			return dateEffective;
		}

		/**
		 * @param dateEffective the dateEffective to set
		 */
		public void setDateEffective(Date dateEffective)
		{
			this.dateEffective = dateEffective;
		}

		/**
		 * @return the dateTermination
		 */
		public Date getDateTermination()
		{
			return dateTermination;
		}

		/**
		 * @param dateTermination the dateTermination to set
		 */
		public void setDateTermination(Date dateTermination)
		{
			this.dateTermination = dateTermination;
		}

		/**
		 * @return returns the sbruid
		 */
		public String getSbrUid()
		{
			return sbrUid;
		}

		/**
		 * Sets the sbruid
		 * 
		 * @param sbrUid the new sbruid
		 */
		public void setSbrUid(String sbrUid)
		{
			this.sbrUid = sbrUid;
		}

		/**
		 * @return the classId
		 */
		public String getClassId()
		{
			return classId;
		}

		/**
		 * @return the planId
		 */
		public String getPlanId()
		{
			return planId;
		}

		/**
		 * @return the planDesc
		 */
		public String getPlanDescription()
		{
			return planDescription;
		}

		/**
		 * @param planDesc the planDesc to set
		 */
		public void setPlanDescription(String planDesc)
		{
			this.planDescription = planDesc;
		}

		/**
		 * @return the type
		 */
		public String getType()
		{
			return type;
		}

		/**
		 * @return the healthCardId
		 */
		public HealthCardId getHealthCardId()
		{
			return healthCardId;
		}

		/**
		 * @param classId the classId to set
		 */
		public void setClassId(String classId)
		{
			this.classId = classId;
		}

		/**
		 * @param planId the planId to set
		 */
		public void setPlanId(String planId)
		{
			this.planId = planId;
		}

		/**
		 * @param type the type to set
		 */
		public void setType(String type)
		{
			this.type = type;
		}

		/**
		 * @param healthCardId the healthCardId to set
		 */
		public void setHealthCardId(HealthCardId healthCardId)
		{
			this.healthCardId = healthCardId;
		}

		/**
		 * @return the medicaidId
		 */
		public String getMedicaidId()
		{
			return medicaidId;
		}

		/**
		 * @param medicaidId the medicaidId to set
		 */
		public void setMedicaidId(String medicaidId)
		{
			this.medicaidId = medicaidId;
		}

		/**
		 * @return the medicareId
		 */
		public String getMedicareId()
		{
			return medicareId;
		}

		/**
		 * @param medicareId the medicareId to set
		 */
		public void setMedicareId(String medicareId)
		{
			this.medicareId = medicareId;
		}

		/**
		 * @return the coverageTypeCode
		 */
		public String getCoverageTypeCode()
		{
			return coverageTypeCode;
		}

		/**
		 * @param coverageTypeCode the coverageTypeCode to set
		 */
		public void setCoverageTypeCode(String coverageTypeCode)
		{
			this.coverageTypeCode = coverageTypeCode;
		}

		/**
		 * @return the coverageTypeDescription
		 */
		public String getCoverageTypeDescription()
		{
			return coverageTypeDescription;
		}

		/**
		 * @param coverageTypeDescription the coverageTypeDescription to set
		 */
		public void setCoverageTypeDescription(String coverageTypeDescription)
		{
			this.coverageTypeDescription = coverageTypeDescription;
		}

		/**
		 * @return the tobaccoStatus
		 */
		public String getTobaccoStatus()
		{
			return tobaccoStatus;
		}

		/**
		 * @param tobaccoStatus the tobaccoStatus to set
		 */
		public void setTobaccoStatus(String tobaccoStatus)
		{
			this.tobaccoStatus = tobaccoStatus;
		}

		/**
		 * @return the market
		 */
		public String getMarket()
		{
			return market;
		}

		/**
		 * @param market the market to set
		 */
		public void setMarket(String market)
		{
			this.market = market;
		}

		/**
		 * @return the sourceSystem
		 */
		public String getSourceSystem()
		{
			return sourceSystem;
		}

		/**
		 * @param sourceSystem the sourceSystem to set
		 */
		public void setSourceSystem(String sourceSystem)
		{
			this.sourceSystem = sourceSystem;
		}

		/*
		 * (non-Javadoc)
		 *
		 * @see java.lang.Object#hashCode()
		 */
		@Override
		public int hashCode()
		{
			final int prime = 31;
			int result = 1;
			result = prime * result + ((healthCardId == null) ? 0 : healthCardId.hashCode());
			result = prime * result + ((sbrUid == null) ? 0 : sbrUid.hashCode());
			return result;
		}

		/*
		 * (non-Javadoc)
		 *
		 * @see java.lang.Object#equals(java.lang.Object)
		 */
		@Override
		public boolean equals(Object obj)
		{
			if (this == obj)
			{
				return true;
			}
			if (obj == null)
			{
				return false;
			}
			if (getClass() != obj.getClass())
			{
				return false;
			}
			MemberEligibility other = (MemberEligibility) obj;
			if (healthCardId == null)
			{
				if (other.healthCardId != null)
				{
					return false;
				}
			}
			else if (!healthCardId.equals(other.healthCardId))
			{
				return false;
			}
			if (sbrUid == null)
			{
				if (other.sbrUid != null)
				{
					return false;
				}
			}
			else if (!sbrUid.equals(other.sbrUid))
			{
				return false;
			}
			return true;
		}

		/**
		 * @return Brand
		 */
		public String getBrand()
		{
			return brand;
		}

		/**
		 * @param brand value to store as brand
		 */
		public void setBrand(String brand)
		{
			this.brand = brand;
		}

		public String getMarketingBrand()
		{
			return marketingBrand;
		}

		public void setMarketingBrand(String marketingBrand)
		{
			this.marketingBrand = marketingBrand;
		}

		public String getFirstName()
		{
			return firstName;
		}

		public void setFirstName(String firstName)
		{
			this.firstName = firstName;
		}

		public String getLastName()
		{
			return lastName;
		}

		public void setLastName(String lastName)
		{
			this.lastName = lastName;
		}

		/**
		 * @return the dateOfBirth
		 */
		public Date getDateOfBirth()
		{
			return dateOfBirth;
		}

		/**
		 * @param dateOfBirth the dateOfBirth to set
		 */
		public void setDateOfBirth(Date dateOfBirth)
		{
			this.dateOfBirth = dateOfBirth;
		}

		public String getLobdId()
		{
			return lobdId;
		}

		public void setLobdId(String lobdId)
		{
			this.lobdId = lobdId;
		}

		public String getHomeZip()
		{
			return homeZip;
		}

		public void setHomeZip(String homeZip)
		{
			this.homeZip = homeZip;
		}

		/**
		 * @return the eligibilityStatusCode
		 */
		public String getEligibilityStatusCode()
		{
			return eligibilityStatusCode;
		}

		/**
		 * @param eligibilityStatusCode the eligibilityStatusCode to set
		 */
		public void setEligibilityStatusCode(String eligibilityStatusCode)
		{
			this.eligibilityStatusCode = eligibilityStatusCode;
		}

		/**
		 * @return the activeStatus
		 */
		public String getActiveStatus()
		{
			return activeStatus;
		}

		/**
		 * @param activeStatus the activeStatus to set
		 */
		public void setActiveStatus(String activeStatus)
		{
			this.activeStatus = activeStatus;
		}

		/**
		 * @return the groupName
		 */
		public String getGroupName()
		{
			return groupName;
		}

		/**
		 * @param groupName the groupName to set
		 */
		public void setGroupName(String groupName)
		{
			this.groupName = groupName;
		}

		/**
		 * @return the subGroupName
		 */
		public String getSubGroupName()
		{
			return subGroupName;
		}

		/**
		 * @param subGroupName the subGroupName to set
		 */
		public void setSubGroupName(String subGroupName)
		{
			this.subGroupName = subGroupName;
		}

		/**
		 * @return the subGroupEffectiveDate
		 */
		public Date getSubGroupEffectiveDate()
		{
			return subGroupEffectiveDate;
		}

		/**
		 * @param subGroupEffectiveDate the subGroupEffectiveDate to set
		 */
		public void setSubGroupEffectiveDate(Date subGroupEffectiveDate)
		{
			this.subGroupEffectiveDate = subGroupEffectiveDate;
		}

		/**
		 * @return the subGroupTerminationDate
		 */
		public Date getSubGroupTerminationDate()
		{
			return subGroupTerminationDate;
		}

		/**
		 * @param subGroupTerminationDate the subGroupTerminationDate to set
		 */
		public void setSubGroupTerminationDate(Date subGroupTerminationDate)
		{
			this.subGroupTerminationDate = subGroupTerminationDate;
		}

		/**
		 * @return the strategicBusinessTypeCode
		 */
		public String getStrategicBusinessTypeCode()
		{
			return strategicBusinessTypeCode;
		}

		/**
		 * @param strategicBusinessTypeCode the strategicBusinessTypeCode to set
		 */
		public void setStrategicBusinessTypeCode(String strategicBusinessTypeCode)
		{
			this.strategicBusinessTypeCode = strategicBusinessTypeCode;
		}

		/**
		 * @return the subGroupNbr
		 */
		public String getSubGroupNbr()
		{
			return subGroupNbr;
		}

		/**
		 * @param subGroupNbr the subGroupNbr to set
		 */
		public void setSubGroupNbr(String subGroupNbr)
		{
			this.subGroupNbr = subGroupNbr;
		}

		public List<DualCitizenshipDetails> getDualCitizenshipDetails()
		{
			return dualCitizenshipDetails;
		}

		public void setDualCitizenshipDetails(List<DualCitizenshipDetails> dualCitizenshipDetails)
		{
			this.dualCitizenshipDetails = dualCitizenshipDetails;
		}

		/**
		 * @return the vendorName
		 */
		public String getVendorName()
		{
			return vendorName;
		}

		/**
		 * @param vendorName the vendorName to set
		 */
		public void setVendorName(String vendorName)
		{
			this.vendorName = vendorName;
		}

		public String getFundingTypeCd()
		{
			return fundingTypeCd;
		}

		public void setFundingTypeCd(String fundingTypeCd)
		{
			this.fundingTypeCd = fundingTypeCd;
		}

		public String getPlanBenefitPackageID()
		{
			return planBenefitPackageID;
		}

		public void setPlanBenefitPackageID(String planBenefitPackageID)
		{
			this.planBenefitPackageID = planBenefitPackageID;
		}

		public String getProductValueCode()
		{
			return productValueCode;
		}

		public void setProductValueCode(String productValueCode)
		{
			this.productValueCode = productValueCode;
		}

		public String getProductValueCodeDesc()
		{
			return productValueCodeDesc;
		}

		public void setProductValueCodeDesc(String productValueCodeDesc)
		{
			this.productValueCodeDesc = productValueCodeDesc;
		}

		public String getCMSContractCode()
		{
			return CMSContractCode;
		}

		public void setCMSContractCode(String cMSContractCode)
		{
			CMSContractCode = cMSContractCode;
		}

		public List<ComponentDetails> getComponentDetails()
		{
			return componentDetails;
		}

		public void setComponentDetails(List<ComponentDetails> componentDetails)
		{
			this.componentDetails = componentDetails;
		}

		public String getMarketingBrandDesc()
		{
			return marketingBrandDesc;
		}

		public void setMarketingBrandDesc(String marketingBrandDesc)
		{
			this.marketingBrandDesc = marketingBrandDesc;
		}

		public String getPrintingBrand()
		{
			return printingBrand;
		}

		public void setPrintingBrand(String printingBrand)
		{
			this.printingBrand = printingBrand;
		}

		public String getPrintingBrandDesc()
		{
			return printingBrandDesc;
		}

		public void setPrintingBrandDesc(String printingBrandDesc)
		{
			this.printingBrandDesc = printingBrandDesc;
		}

		@Override
		public String toString()
		{
			return "MemberEligibility [sbrUid=" + sbrUid + ", classId=" + classId + ", planId=" + planId
					+ ", planDescription=" + planDescription + ", groupId=" + groupId + ", subgroupId=" + subgroupId
					+ ", type=" + type + ", healthCardId=" + healthCardId + ", mcid=" + mcid + ", productId="
					+ productId + ", productName=" + productName + ", productDescription=" + productDescription
					+ ", dateEffective=" + dateEffective + ", dateTermination=" + dateTermination + ", brand=" + brand
					+ ", medicaidId=" + medicaidId + ", medicareId=" + medicareId + ", coverageTypeCode="
					+ coverageTypeCode + ", coverageTypeDescription=" + coverageTypeDescription + ", tobaccoStatus="
					+ tobaccoStatus + ", firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth="
					+ dateOfBirth + ", lobdId=" + lobdId + ", homeZip=" + homeZip + ", eligibilityStatusCode="
					+ eligibilityStatusCode + ", activeStatus=" + activeStatus + ", groupName=" + groupName
					+ ", subGroupName=" + subGroupName + ", subGroupEffectiveDate=" + subGroupEffectiveDate
					+ ", subGroupTerminationDate=" + subGroupTerminationDate + ", strategicBusinessTypeCode="
					+ strategicBusinessTypeCode + ", subGroupNbr=" + subGroupNbr + ", market=" + market
					+ ", sourceSystem=" + sourceSystem + ", marketingBrand=" + marketingBrand + ", marketingBrandDesc="
					+ marketingBrandDesc + ", printingBrand=" + printingBrand + ", printingBrandDesc="
					+ printingBrandDesc + ", dualCitizenshipDetails=" + dualCitizenshipDetails + ", vendorName="
					+ vendorName + ", fundingTypeCd=" + fundingTypeCd + ", planBenefitPackageID=" + planBenefitPackageID
					+ ", productValueCode=" + productValueCode + ", productValueCodeDesc=" + productValueCodeDesc
					+ ", CMSContractCode=" + CMSContractCode + ", componentDetails=" + componentDetails
					+ ", warningMessages=" + warningMessages + ", planEntryDate=" + planEntryDate
					+ ", eligRecordUpdatedDate=" + eligRecordUpdatedDate + ", eligNotifyDate=" + eligNotifyDate
					+ ", memeCk=" + memeCk + ", groupPhoneNumber=" + groupPhoneNumber + ", getGroupPhoneNumber()="
					+ getGroupPhoneNumber() + ", getMemeCk()=" + getMemeCk() + ", getEligRecordUpdatedDate()="
					+ getEligRecordUpdatedDate() + ", getEligNotifyDate()=" + getEligNotifyDate() + ", getMcid()="
					+ getMcid() + ", getPlanEntryDate()=" + getPlanEntryDate() + ", getWarningMessages()="
					+ getWarningMessages() + ", getGroupId()=" + getGroupId() + ", getSubgroupId()=" + getSubgroupId()
					+ ", getProductId()=" + getProductId() + ", getProductName()=" + getProductName()
					+ ", getProductDescription()=" + getProductDescription() + ", getDateEffective()="
					+ getDateEffective() + ", getDateTermination()=" + getDateTermination() + ", getSbrUid()="
					+ getSbrUid() + ", getClassId()=" + getClassId() + ", getPlanId()=" + getPlanId()
					+ ", getPlanDescription()=" + getPlanDescription() + ", getType()=" + getType()
					+ ", getHealthCardId()=" + getHealthCardId() + ", getMedicaidId()=" + getMedicaidId()
					+ ", getMedicareId()=" + getMedicareId() + ", getCoverageTypeCode()=" + getCoverageTypeCode()
					+ ", getCoverageTypeDescription()=" + getCoverageTypeDescription() + ", getTobaccoStatus()="
					+ getTobaccoStatus() + ", getMarket()=" + getMarket() + ", getSourceSystem()=" + getSourceSystem()
					+ ", hashCode()=" + hashCode() + ", getBrand()=" + getBrand() + ", getMarketingBrand()="
					+ getMarketingBrand() + ", getFirstName()=" + getFirstName() + ", getLastName()=" + getLastName()
					+ ", getDateOfBirth()=" + getDateOfBirth() + ", getLobdId()=" + getLobdId() + ", getHomeZip()="
					+ getHomeZip() + ", getEligibilityStatusCode()=" + getEligibilityStatusCode()
					+ ", getActiveStatus()=" + getActiveStatus() + ", getGroupName()=" + getGroupName()
					+ ", getSubGroupName()=" + getSubGroupName() + ", getSubGroupEffectiveDate()="
					+ getSubGroupEffectiveDate() + ", getSubGroupTerminationDate()=" + getSubGroupTerminationDate()
					+ ", getStrategicBusinessTypeCode()=" + getStrategicBusinessTypeCode() + ", getSubGroupNbr()="
					+ getSubGroupNbr() + ", getDualCitizenshipDetails()=" + getDualCitizenshipDetails()
					+ ", getVendorName()=" + getVendorName() + ", getFundingTypeCd()=" + getFundingTypeCd()
					+ ", getPlanBenefitPackageID()=" + getPlanBenefitPackageID() + ", getProductValueCode()="
					+ getProductValueCode() + ", getProductValueCodeDesc()=" + getProductValueCodeDesc()
					+ ", getCMSContractCode()=" + getCMSContractCode() + ", getComponentDetails()="
					+ getComponentDetails() + ", getMarketingBrandDesc()=" + getMarketingBrandDesc()
					+ ", getPrintingBrand()=" + getPrintingBrand() + ", getPrintingBrandDesc()="
					+ getPrintingBrandDesc() + ", getClass()=" + getClass() + ", toString()=" + super.toString() + "]";
		}

	}

	/**
	 * @author AE00065
	 * 
	 */
	public static class HealthCardId
	{
		private String prefix;
		private String subscriberId;

		/**
		 * @param subscriberIdWithPrefix type String
		 */
		public HealthCardId(String subscriberIdWithPrefix)
		{
			if (subscriberIdWithPrefix == null)
			{
				throw new IllegalArgumentException("SubscriberId can not be null");
			}
			if (subscriberIdWithPrefix.length() > 9)
			{
				this.prefix = subscriberIdWithPrefix.substring(0, 3);
				this.subscriberId = subscriberIdWithPrefix.substring(3, subscriberIdWithPrefix.length());
			}
			else
			{
				this.prefix = "";
				this.subscriberId = subscriberIdWithPrefix;
			}

		}

		/**
		 * @param prefix represents prefix
		 * @param subscriberId represents subscriberId
		 */
		public HealthCardId(String prefix, String subscriberId)
		{
			this.prefix = prefix;
			this.subscriberId = subscriberId;
		}

		/**
		 * @return the prefix
		 */
		public String getPrefix()
		{
			return prefix;
		}

		/**
		 * @return the subscriberId
		 */
		public String getSubscriberId()
		{
			return subscriberId;
		}

		/*
		 * (non-Javadoc)
		 *
		 * @see java.lang.Object#hashCode()
		 */
		@Override
		public int hashCode()
		{
			final int prime = 31;
			int result = 1;
			result = prime * result + ((prefix == null) ? 0 : prefix.hashCode());
			result = prime * result + ((subscriberId == null) ? 0 : subscriberId.hashCode());
			return result;
		}

		/*
		 * (non-Javadoc)
		 *
		 * @see java.lang.Object#equals(java.lang.Object)
		 */
		@Override
		public boolean equals(Object obj)
		{
			if (this == obj)
			{
				return true;
			}
			if (obj == null)
			{
				return false;
			}
			if (getClass() != obj.getClass())
			{
				return false;
			}
			HealthCardId other = (HealthCardId) obj;
			if (prefix == null)
			{
				if (other.prefix != null)
				{
					return false;
				}
			}
			else if (!prefix.equals(other.prefix))
			{
				return false;
			}
			if (subscriberId == null)
			{
				if (other.subscriberId != null)
				{
					return false;
				}
			}
			else if (!subscriberId.equals(other.subscriberId))
			{
				return false;
			}
			return true;
		}

		/*
		 * (non-Javadoc)
		 *
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString()
		{
			return "HealthCardId [prefix=" + prefix + ", subscriberId=" + subscriberId + "]";
		}

	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString()
	{
		return "MemberEligibilityResponse [eligibilities=" + eligibilities + "]";
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((eligibilities == null) ? 0 : eligibilities.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj)
	{
		if (this == obj)
		{
			return true;
		}
		if (obj == null)
		{
			return false;
		}
		if (getClass() != obj.getClass())
		{
			return false;
		}
		MemberEligibilityResponse other = (MemberEligibilityResponse) obj;
		if (eligibilities == null)
		{
			if (other.eligibilities != null)
			{
				return false;
			}
		}
		else if (!eligibilities.equals(other.eligibilities))
		{
			return false;
		}
		return true;
	}

}
