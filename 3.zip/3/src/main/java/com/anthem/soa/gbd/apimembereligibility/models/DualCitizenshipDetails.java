package com.anthem.soa.gbd.apimembereligibility.models;
import java.util.Date;

/**
 * 
 * @author AF14154
 * 
 *         POJO to store Member Dual citizenship data.
 */
public class DualCitizenshipDetails
{

	/** dual_link */
	public String dualLink;

	/** dual_type */
	public String dualType;

	/** Dual Type Description */
	public String dualTypeDescription;

	/** requested SBSB_ID for dual citizenship details */
	public String requestedSubscriberId;

	/** requested GRGR_ID for dual citizenship details */
	public String requestedGroupId;

	/** requested MEME_CK for dual citizenship details */
	public String requestedMemeCk;

	/** Other SBSB_ID for requested Member */
	public String targetSubscriberId;

	/** Other GRGR_ID for requested Member */
	public String targetGroupId;

	/** Other MEME_CK for requested Member */
	public String targetMemeCk;

	/** Dual Span Start Dt DUAL_SPN_START_DT */
	public Date dualSpanStartDt;

	/** Dual Span End Dt DUAL_SPN_END_DT */
	public Date dualSpanEndDt;

	/** COST_SHARE_CAT */
	public String medicaidCostshareCategory;

	/** MEDICAID_LEVEL */
	public String medicaidAidCategory;

	@Override
	public String toString()
	{
		return "DualCitizenshipDetails [dualLink=" + dualLink + ", dualType=" + dualType + ", dualTypeDescription="
				+ dualTypeDescription + ", requestedSubscriberId=" + requestedSubscriberId + ", requestedGroupId="
				+ requestedGroupId + ", requestedMemeCk=" + requestedMemeCk + ", targetSubscriberId="
				+ targetSubscriberId + ", targetGroupId=" + targetGroupId + ", targetMemeCk=" + targetMemeCk
				+ ", dualSpanStartDt=" + dualSpanStartDt + ", dualSpanEndDt=" + dualSpanEndDt + ", costshareCategory="
				+ medicaidCostshareCategory + ", medicaidAidCategory=" + medicaidAidCategory + "]";
	}

}
