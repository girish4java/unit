package com.anthem.soa.gbd.apimembereligibility.models;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Person2
{

	@JsonProperty("personid")
	private String personid;

	@JsonProperty("createdtimestamp")
	private Date createdtimestamp;

	@JsonProperty("lastupdatedtimestamp")
	private Date lastupdatedtimestamp;

	@JsonProperty("relationships")
	private List<Relationship> relationships;

	public String getPersonid()
	{
		return personid;
	}

	public void setPersonid(String personid)
	{
		this.personid = personid;
	}

	public Date getCreatedtimestamp()
	{
		return createdtimestamp;
	}

	public void setCreatedtimestamp(Date createdtimestamp)
	{
		this.createdtimestamp = createdtimestamp;
	}

	public Date getLastupdatedtimestamp()
	{
		return lastupdatedtimestamp;
	}

	public void setLastupdatedtimestamp(Date lastupdatedtimestamp)
	{
		this.lastupdatedtimestamp = lastupdatedtimestamp;
	}

	public List<Relationship> getRelationships()
	{
		return relationships;
	}

	public void setRelationships(List<Relationship> relationships)
	{
		this.relationships = relationships;
	}

	@Override
	public String toString()
	{
		return "Person2 [personid=" + personid + ", createdtimestamp=" + createdtimestamp + ", lastupdatedtimestamp="
				+ lastupdatedtimestamp + ", relationships=" + relationships + "]";
	}

}
