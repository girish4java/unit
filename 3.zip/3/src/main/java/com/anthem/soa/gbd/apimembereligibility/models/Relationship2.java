package com.anthem.soa.gbd.apimembereligibility.models;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Relationship2
{

	@JsonProperty("type")
	private String type;

	@JsonProperty("id")
	private String id;

	@JsonProperty("source")
	private String source;

	@JsonProperty("createdtimestamp")
	private Date createdtimestamp;

	@JsonProperty("lastupdatedtimestamp")
	private Date lastupdatedtimestamp;

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}

	public String getSource()
	{
		return source;
	}

	public void setSource(String source)
	{
		this.source = source;
	}

	public Date getCreatedtimestamp()
	{
		return createdtimestamp;
	}

	public void setCreatedtimestamp(Date createdtimestamp)
	{
		this.createdtimestamp = createdtimestamp;
	}

	public Date getLastupdatedtimestamp()
	{
		return lastupdatedtimestamp;
	}

	public void setLastupdatedtimestamp(Date lastupdatedtimestamp)
	{
		this.lastupdatedtimestamp = lastupdatedtimestamp;
	}

	@Override
	public String toString()
	{
		return "Relationship2 [type=" + type + ", id=" + id + ", source=" + source + ", createdtimestamp="
				+ createdtimestamp + ", lastupdatedtimestamp=" + lastupdatedtimestamp + "]";
	}

}
