package com.anthem.soa.gbd.apimembereligibility.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;
import java.util.*;

import org.apache.hc.client5.http.classic.HttpClient;
/*import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;*/
//import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
//import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
//import org.apache.hc.client5.http.impl.classic.HttpClients;
//import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactory;
//import org.apache.hc.core5.ssl.SSLContextBuilder;
import org.apache.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.amerigroup.config.ConfigServiceFactory;
import com.amerigroup.config.IConfigService;
import com.amerigroup.exception.runtime.execution.InternalErrorException;
import com.amerigroup.exception.runtime.execution.SettingNotFoundException;
import com.amerigroup.utilities.LoggerFactory;
import com.anthem.soa.gbd.api.APIException;
import com.anthem.soa.gbd.api.APIExceptionElement;
import com.anthem.soa.gbd.apimembereligibility.models.Person;
import com.anthem.soa.gbd.apimembereligibility.models.Relationship;
import com.anthem.soa.gbd.apimembereligibility.models.Root;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

/**
 * Utility class to call internal ESOA API to get messages , mainly focused on DTO from database side to
 * service DTO
 *
 * @author Azeem
 *
 */
public final class ESOAApiCallUtil
{

	private static final Logger LOG = LoggerFactory.getLogger(ESOAApiCallUtil.class);

	/**
	 * Application Name
	 */
	private String applicationName = "MemberDomain";

	/**
	 * Component Name
	 */
	private String componentName = "MemebrRelationshipService";

	/**
	 * List Name
	 */
	private String listName = "getMemebrRelationshipId";


	/**
	 * Configuration Service
	 */
	private IConfigService configService;

	/**
	 * ESOA API END POINT
	 */
	private static final String API_MANAGER_ESOA_API_SERVICE_ENDPOINT = "MemebrRelationshipAPIServiceEndpoint";



	/**
	 * ESOA API CONNECTION TIMEOUT
	 */
	public static final String API_CONNECTION_TIMEOUT = "connectionTimeout";

	/**
	 * ESOA API READ TIMEOUT
	 */
	public static final String API_READ_TIMEOUT = "readTimeout";

	/**
	 * ESOA API META-SRC-ENVRMT
	 */
	public static final String API_META_SRC_ENVRMT = "metaSrcEnvrmt";

	/**
	 * APIKEY
	 */
	public static final String APIKEY = "apikey";

	/**
	 * SEPARATOR
	 */
//	private static final String SEPARATOR = "/";
	private static final String SEPARATOR = ".";

	private static String relationshipAPIServiceEndpoint;

	private String connectionTimeout;
	private String readTimeout;
	private  String metaSrcEnvrmt;
	private  String apikey;

	// class wide instance, only initialized once at startup time
	private static Map<String, String> membereligibilitymap;

	public static Map<String, String> getMembereligibilitymap() {
		return membereligibilitymap;
	}

	public static void setMembereligibilitymap(Map<String, String> membereligibilitymap) {
		ESOAApiCallUtil.membereligibilitymap = membereligibilitymap;
	}

	/**
	 * Get the ESOA Internal API service end point, read timeout and connection timeout values from Imperio
	 */
	private void getConfigInfoFromImperio()
	{
		LOG.info("Inside getConfigInfoFromImperio()");
//		configService = new ConfigServiceFactory().getInstanceFor(applicationName);
		try
		{
			/*// get end point for Id card
			relationshipAPIServiceEndpoint = configService.getSetting(componentName + SEPARATOR + listName + SEPARATOR
					+ API_MANAGER_ESOA_API_SERVICE_ENDPOINT);
			LOG.info("ESOAAPIServiceEndpoint>>> " + relationshipAPIServiceEndpoint);


			// get connection timeout
			connectionTimeout = configService.getSetting(componentName + SEPARATOR + listName + SEPARATOR
					+ API_CONNECTION_TIMEOUT);
			LOG.info("connectionTimeout>>> " + connectionTimeout);

			// get read timeout
			readTimeout = configService.getSetting(componentName + SEPARATOR + listName + SEPARATOR + API_READ_TIMEOUT);
			LOG.info("readTimeout>>> " + readTimeout);

			// get met-src-envrmt
			metaSrcEnvrmt = configService.getSetting(componentName + SEPARATOR + listName + SEPARATOR
					+ API_META_SRC_ENVRMT);
			LOG.info("metaSrcEnvrmt>>> " + metaSrcEnvrmt);

			// get apikey
			apikey = configService.getSetting(componentName + SEPARATOR + listName + SEPARATOR + APIKEY);
*/

			relationshipAPIServiceEndpoint = membereligibilitymap.get(
					componentName + SEPARATOR + listName + SEPARATOR + API_MANAGER_ESOA_API_SERVICE_ENDPOINT);
			LOG.info("ESOAAPIServiceEndpoint>>> " + relationshipAPIServiceEndpoint);

			// get connection timeout
			connectionTimeout = membereligibilitymap.get(componentName + SEPARATOR + listName + SEPARATOR + API_CONNECTION_TIMEOUT);
			LOG.info("connectionTimeout>>> " + connectionTimeout);

			// get read timeout
			readTimeout = membereligibilitymap.get(componentName + SEPARATOR + listName + SEPARATOR + API_READ_TIMEOUT);
			LOG.info("readTimeout>>> " + readTimeout);

			// get met-src-envrmt
			metaSrcEnvrmt = membereligibilitymap.get(componentName + SEPARATOR + listName + SEPARATOR + API_META_SRC_ENVRMT);
			LOG.info("metaSrcEnvrmt>>> " + metaSrcEnvrmt);

			// get apikey
			apikey = membereligibilitymap.get(componentName + SEPARATOR + listName + SEPARATOR + APIKEY);

		}
		catch (SettingNotFoundException settingsException)
		{
			LOG.error(settingsException.getMessage());
			throw new SettingNotFoundException(settingsException.getMessage());
		}
	}

	public Root getMCIDResponse(String subscriberId)
	{

		getConfigInfoFromImperio();

//		RestTemplate restTemplate = createSslRestTemplate();

		RestTemplate restTemplate1 = new RestTemplate();

		HttpEntity<String> entity = new HttpEntity<>(createRequestHeaders());

		ResponseEntity<Root> responseEntity = null;
		Root response = new Root();
		try
		{
			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(relationshipAPIServiceEndpoint)
					.queryParam("relationshipidtype", "HCID")
					.queryParam("relationshipidvalue", subscriberId)
					.queryParam("returnrelationshipidtype", "MCID");
			String uri = builder.build().toUri().toString();
			LOG.info("uri>>>> " + uri);

			//4. Make the POST request by setting the required parameters
			responseEntity = restTemplate1.exchange(uri, HttpMethod.GET, entity,
					Root.class);

			LOG.info("Response Body>>> " + responseEntity.getBody().toString().trim());
			LOG.info("Response Headers>>> " + responseEntity.getHeaders().toString());
			LOG.info("Response StatusCode>> " + responseEntity.getStatusCode().toString());
			response = responseEntity.getBody();

		}
		catch (HttpStatusCodeException httpStatusCodeException)
		{
			LOG.info("STATUS CODE::::::: " + httpStatusCodeException.getStatusCode().value());
			LOG.info("Exception Message::::: " + httpStatusCodeException.getMessage().trim());
			LOG.info("Exception ResponseBody::::: " + httpStatusCodeException.getResponseBodyAsString().trim());
			httpStatusCodeException.printStackTrace();
			if (httpStatusCodeException.getStatusCode().value() != 404)
			{
				throwBadRequestError(httpStatusCodeException.getResponseBodyAsString().trim());
			}
		}
		catch (Throwable ex)
		{
			//ex.printStackTrace();
			LOG.info(ex.getStackTrace().toString());
			throw new APIException(HttpStatus.INTERNAL_SERVER_ERROR, "INTR", ex.getMessage().trim(), ex
					.getMessage().trim());
		}


		return response;
	}




	/**
	 * Throw APIException by getting the message in response body
	 *
	 * @param httpStatusCodeException
	 */
	private void throwBadRequestError(String responseBodyAsString)
	{
		LOG.info("responseBodyAsString >>>>>>> " + responseBodyAsString);

		APIExceptionElement element = new Gson().fromJson(responseBodyAsString, APIExceptionElement.class);

		if (null != element && null != element.getMessage() )
		{
			throw new APIException(HttpStatus.BAD_REQUEST, element.getCode().trim(), element.getMessage()
					.trim());
		}
	}

	/**
	 * Create SSL Rest Template that support 2 Way SSL
	 *
	 * @return
	 */
	/*private RestTemplate createSslRestTemplate()
	{
//		String storePath = System.getProperty("anthem.net.ssl.keyStore");
//		String storePassword = System.getProperty("anthem.net.ssl.keyStorePassword");
//		String storeType = System.getProperty("anthem.net.ssl.keyStoreType");
//		String storeAlias = System.getProperty("anthem.net.ssl.keyStoreAlias");

		RestTemplate restTemplate = null;

//		if (storePath != null && !storePath.isEmpty() && storePath.length() > 0)
//		{
//
//			try (FileInputStream file = new FileInputStream(storePath);)
//			{
//				KeyStore keyStore = KeyStore.getInstance(storeType);
//				LOG.info("After getting ssl keystore anthem.net.ssl.keyStore");
//				LOG.info("storePath=" + storePath);
//				LOG.info("storeType=" + storeType);
//				LOG.info("keyStoreAlias=" + storeAlias);
//
//				/*
//				 * Setting up the keystore
//				 */
//				keyStore.load(file, storePassword.toCharArray());

    /*    SSLConnectionSocketFactory socketFactory = null;try
	{
		socketFactory = new SSLConnectionSocketFactory(new SSLContextBuilder().build());
	}catch(NoSuchAlgorithmException|
	KeyManagementException e)
	{
		throw new RuntimeException(e);
	}

	HttpClientBuilder builder = HttpClients.custom();

	builder.setSSLSocketFactory(socketFactory);builder.useSystemProperties();

	LOG.info("Create HttpClient along with SSL Socket Factory");
	CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(socketFactory).build();

	LOG.info("Create ClientHttpRequestFactory");
	HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(
			(HttpClient) httpClient);requestFactory.setConnectTimeout(Integer.parseInt(connectionTimeout));*/
//				requestFactory.setReadTimeout(Integer.parseInt(readTimeout));

	//LOG.info("Create Rest template object with HttpComponentsClientHttpRequestFactory has SSL setup");restTemplate=new RestTemplate(requestFactory);

//			}
//			catch (Exception e1)
//			{
//				e1.printStackTrace();
//			}
//		}
//		else
//		{
//			LOG.error("Problem found with one or more SSL configuration: "
//					+ String.format("StorePath=%s, StoreType=%s, StoreAlias=%s", storePath, storeType, storeAlias));
//
//			throw new InternalErrorException("No or invalid Java SSL properties found");
//		}

	//return restTemplate;
	//}*/

	/**
	 * Create request headers for the API call
	 *
	 * @return
	 */
	private HttpHeaders createRequestHeaders()
	{
		LOG.info("Inside getRequestHeaders()");
		HttpHeaders headers = new HttpHeaders();
		headers.add("apikey", apikey);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add("meta-transid", UUID.randomUUID().toString());
		//headers.add("meta-senderapp", metaSenderApp);
		headers.add("meta-src-envrmt", metaSrcEnvrmt);
		return headers;
	}

	/**
	 * Private constructor to avoid initialization
	 * @throws IOException
	 * @throws JsonMappingException
	 * @throws JsonParseException
	 */
	public ESOAApiCallUtil()
	{


	}


}