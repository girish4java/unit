package com.anthem.soa.gbd.apimembereligibility.models;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;

public class Person
{
	@JsonProperty("person")
	private Person2 person;

	public Person2 getPerson()
	{
		return person;
	}

	public void setPerson(Person2 person)
	{
		this.person = person;
	}

	@Override
	public String toString()
	{
		return "Person [person=" + person + "]";
	}

}
