package com.elevancehealth.dckr.microsvc.aksgbdsoamembereligibility;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.client5.http.ssl.NoopHostnameVerifier;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactoryBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;

/**
 * Docker MS Prototype!
 *
 */

@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan(value = { "com.elevancehealth","com.amerigroup.facets.dao","com.amerigroup.facets.dao.dto","com.anthem" })
//@EnableAspectJAutoProxy(proxyTargetClass = false)
@EnableConfigurationProperties
@RefreshScope
public class Application { 
	
	@Value("${defaultReadTimeout}")
    private int readTimeout; 
	
	@Value("${defaultConnectionTimeout}")
    private int connectionTimeout;
	
    public static final Logger logger = LoggerFactory.getLogger(Application.class);

	
    public static void main(String[] args) {
    	SpringApplication.run(Application.class, args);
    	logger.info("Info  message");
        logger.error("This is error message");
        logger.debug("This is debug message");
    }
    
    @GetMapping("/welcome")
    public String helloWorld() {
        return "Hello World";
	}
    
    @GetMapping(value = "/releasetag", produces = "application/json")    
	public ResponseEntity<String> releasetag() {    	
    	String responseStr = "{\"releaseTag\": \"" + System.getenv("release_tag_name") + "\"}";
    	return new ResponseEntity<>(responseStr, HttpStatus.OK);
	}

    @Bean(name = "restTemplate")
	public RestTemplate restTemplate(RestTemplateBuilder builder)throws NoSuchAlgorithmException, KeyManagementException {

		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return new X509Certificate[0];
			}

			public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
			}

			public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
			}
		} };
		SSLContext sslContext = SSLContext.getInstance("SSL");
		sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
		
		/*
		 * CloseableHttpClient httpClient =
		 * HttpClients.custom().setSSLContext(sslContext)
		 * .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE).build();
		 */
		CloseableHttpClient httpclient = HttpClients.custom()
		        .setConnectionManager(PoolingHttpClientConnectionManagerBuilder.create()
		                .setSSLSocketFactory(SSLConnectionSocketFactoryBuilder.create()
		                        .setSslContext(sslContext)
		                        .setHostnameVerifier(NoopHostnameVerifier.INSTANCE)
		                        .build())
		                .build())
		        .build();
		
		HttpComponentsClientHttpRequestFactory customRequestFactory = new HttpComponentsClientHttpRequestFactory(httpclient);

		customRequestFactory.setConnectTimeout(10000);
		//customRequestFactory.setReadTimeout(10000);

		//customRequestFactory.setHttpClient(httpClient);
		return builder.requestFactory(() -> customRequestFactory).build();
	}
}