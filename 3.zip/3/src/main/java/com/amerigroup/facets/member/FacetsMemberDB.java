package com.amerigroup.facets.member;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.amerigroup.daobase.DaoImplFactory;
import com.amerigroup.exception.runtime.validation.MemberNotFoundException;
import com.amerigroup.facets.dao.IFacetsMemberDao;
import com.amerigroup.facets.dao.dto.FacetsMemberAmerigroupIDDto;
import com.amerigroup.facets.dao.dto.FacetsMemberEligibilityDto;
import com.amerigroup.facets.dao.dto.FacetsMemberHippaDto;
import com.amerigroup.facets.dao.dto.FacetsMemberTobaccoStatusDto;
import com.amerigroup.utilities.Text;

/**
 * Utility class for access member info in Facets
 * 
 * @author jzou001, Azeem
 * 
 */
public class FacetsMemberDB {

	private static final String VALID_DIGIT_REGEX_PATTERN = "^\\d+$";

	private static final Logger LOG = Logger.getLogger(FacetsMemberDB.class);

	IFacetsMemberDao facetsMemberDao = (IFacetsMemberDao) DaoImplFactory.getInstance().getDaoImpl(
			IFacetsMemberDao.class);

	/**
	 * identifies whether a subscriber has a HIPPA restriction in effect on their accounts
	 *
	 * @param amerigroupId
	 * @return
	 */
	private boolean subscriberHasHippaRestrictions(String amerigroupId) {
		FacetsMemberHippaDto hippaRestrictionDto = facetsMemberDao.getHipaa(amerigroupId);
		if (hippaRestrictionDto == null) {
			return false;
		} else {
			return ("Y").equals(hippaRestrictionDto.hipaa) ? true : false;
		}
	}

	/**
	 * <p>
	 * Find amerigroupID using the amerigroup id
	 * </p>
	 * <p>
	 * <b>Not transaction-aware.</b>
	 * </p>
	 * <p>
	 * Executes the following SQL:<br/>
	 * <blockquote>
	 *
	 * <pre>
	 * select sbsb_id, grgr_ck from cmc_sbsb_subsc where sbsb_id=?
	 * </pre>
	 *
	 * </blockquote>
	 * </p>
	 *
	 * @param memberAgpId Amerigroup ID of the member
	 * @return A <tt>List</tt> of <tt>FacetsMemberAmerigroupIDDto</tt> objects that match the selection criteria. The
	 * <tt>List</tt> may be empty but will never return null.
	 */
	public List<FacetsMemberAmerigroupIDDto> findByAgp(String memberAgpId) {

		List<FacetsMemberAmerigroupIDDto> members = new ArrayList<FacetsMemberAmerigroupIDDto>();
		members = facetsMemberDao.findByAgp(memberAgpId);

		if (members != null && !members.isEmpty()) {
			LOG.info("Member found for valid Amerigroup ID (" + Text.nullSafeTrim(memberAgpId) + ")");

		} else {
			LOG.info("Member not found for valid Amerigroup ID (" + Text.nullSafeTrim(memberAgpId) + ")");
			throw new MemberNotFoundException("Amerigroup ID '" + memberAgpId + "' could not be found.");
		}

		return members;
	}

	/**
	 * subscriberId must be a digit
	 *
	 * @param subscriberId the subscriber ID to be checked
	 * @return a boolean value indicating if the given string is the correct format
	 */
	private boolean isValid(String subscriberId) {
		//
		return (subscriberId != null) && subscriberId.matches(VALID_DIGIT_REGEX_PATTERN);
	}

	/**
	 * Searches for members by medicaid ID searchScope. If search is empty
	 *
	 * @param medicaidId Required parameter for searching
	 * @return list of member DTOs matching the input parameters
	 */
	public FacetsMemberEligibilityDto getEligibilitySearchByMedicaidId(String medicaidId) {
		// We will just do some basic validation here for required parameters
		if (Text.isEffectivelyEmptyOrNull(medicaidId)) {
			throw new InvalidParameterException("MedicaidId number required");
		}

		FacetsMemberEligibilityDto dto;

		dto = facetsMemberDao.getCurrentEligibilityByMedicaidID(medicaidId);

		return dto;
	}

	/**
	 * @param sbsb_ck member sbsb_ck
	 * @return
	 * @return member tobacco status
	 */
	public FacetsMemberTobaccoStatusDto getMemberTobaccoStatus(String sbsb_ck) {
		IFacetsMemberDao facetsMemberDao = (IFacetsMemberDao) DaoImplFactory.getInstance().getDaoImpl(
				IFacetsMemberDao.class);

		FacetsMemberTobaccoStatusDto dto = facetsMemberDao.getMemberTobaccoStatus(sbsb_ck);
		if (dto == null) {
			return null;
		}

		return dto;
	}
}
