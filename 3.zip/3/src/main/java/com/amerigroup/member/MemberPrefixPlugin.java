package com.amerigroup.member;

import java.util.ArrayList;
import java.util.List;

import com.amerigroup.daobase.DaoImplFactory;
import com.amerigroup.facets.dao.IFacetsMemberDao;
import com.amerigroup.facets.dao.dto.FacetsMemberBluesPrefixDto;

/**
 * This class is used to caching all the valid member prefix with length 3 stored in the database table -
 * CMC_CSPI_CS_PLAN. It contains a list to contain all these prefixes. The list will be refreshed every 10 minutes.
 * 
 */
public class MemberPrefixPlugin
{
	/**
	 * The time that list will remain in the cache before they expire - 10 minutes
	 */
	private static final long CACHED_LIST_TIME_TO_LIVE = 10 * 60 * 1000;

	/**
	 * A list used to cache the valid member prefixes
	 */
	private List<String> cachedPrefixes;

	/**
	 * When System.currentTimeMillis exceeds this value, we should refresh our cache and this value will be updated to
	 * System.currentTimeMillis + CACHED_LIST_TIME_TO_LIVE
	 */
	private Long expires;

	/**
	 * Create Single instance for this plugin
	 */
	private static final MemberPrefixPlugin INSTANCE = new MemberPrefixPlugin();

	/**
	 * Factory method to get this plugin
	 * 
	 * @return instance of MemberPrefixPlugin
	 */
	public static MemberPrefixPlugin getInstance()
	{
		return INSTANCE;
	}

	/**
	 * Package-private constructor. Prevents instantiation and subclassing outside the package.
	 */
	MemberPrefixPlugin()
	{
		; // Nothing to do
	}

	/**
	 * Method to force refreshing the prefix cache list, this is used for testing purpose only
	 */
	synchronized void forceRefreash()
	{
		/*
		 * Make the expires time smaller than current system time.
		 */
		expires = System.currentTimeMillis() - 1;
	}

	/**
	 * This method will be called by other classes to get the cached prefixes.
	 * 
	 * @return a list of String
	 */
	public synchronized List<String> getCachedPrefixes()
	{
		if (cachedPrefixes == null || System.currentTimeMillis() > expires)
		{
			expires = loadMemberPrefixes();
		}
		return cachedPrefixes;
	}

	/**
	 * This method will:
	 * 
	 * 1. Refresh the member prefixes cache.
	 * 
	 * 2. Increase the number of refreshedTimes which used to memorized how many times we refreshed prefix list from the
	 * database.
	 * 
	 * 3. Reset the expired time of the prefix list
	 * 
	 * @return Updated expired time stamp, should be Sytem.currentTimeMillis()+CACHED_LIST_TIME_TO_LIVE
	 */
	private synchronized Long loadMemberPrefixes()
	{
		List<FacetsMemberBluesPrefixDto> prefixDtos = ((IFacetsMemberDao) DaoImplFactory.getInstance().getDaoImpl(
				IFacetsMemberDao.class)).getBluesPrefixes();

		cachedPrefixes = new ArrayList<String>();

		for (int i = 0; i < prefixDtos.size(); i++)
		{
			cachedPrefixes.add(prefixDtos.get(i).prefix);
		}

		/*
		 * Reset the expired time
		 */
		Long newExpires = System.currentTimeMillis() + CACHED_LIST_TIME_TO_LIVE;

		return newExpires;
	}
}
