package com.amerigroup.member.portal;

import java.util.ArrayList;
import java.util.List;

import com.amerigroup.daobase.DaoImplFactory;
import com.amerigroup.facets.dao.IFacetsMemberDao;
import com.amerigroup.facets.dao.dto.FacetsMemberEligibilityDto;
import com.amerigroup.member.portal.dao.IMemberPortalDao;
import com.amerigroup.member.portal.dao.dto.MemberPortalGroupBrandConfigDto;

public class APIEligibilityLookup
{

	DaoImplFactory factory = DaoImplFactory.getInstance();

	/**
	 * Returns current eligibilities for the given subscriber
	 * 
	 * @param sbsbId
	 * @return all active eligibilities
	 */
	public List<FacetsMemberEligibilityDto> getEligibilities(String sbsbId)
	{
		List<FacetsMemberEligibilityDto> result = new ArrayList<FacetsMemberEligibilityDto>();
		FacetsMemberEligibilityDto singleEligibilities = getSingleEligibilities(sbsbId);
		if (singleEligibilities != null)
		{
			result.add(singleEligibilities);
		}

		return result;
	}

	/**
	 * Returns current eligibilities for the given subscriber
	 * 
	 * @param sbsbId
	 * @return all active eligibilities
	 */
	public List<FacetsMemberEligibilityDto> getEligibilitiesWithNoEligibilityCheck(String sbsbId)
	{
		List<FacetsMemberEligibilityDto> result = new ArrayList<FacetsMemberEligibilityDto>();
		FacetsMemberEligibilityDto singleEligibilities = getSingleEligibilitiesWithNoEligibilityCheck(sbsbId);
		if (singleEligibilities != null)
		{
			result.add(singleEligibilities);
		}

		return result;
	}

	/**
	 * Returns current eligibilities for the given medicaid Id
	 * 
	 * @param sbsbId
	 * @return all active eligibilities
	 */
	public List<FacetsMemberEligibilityDto> getEligibilitiesByMedicaidId(String medicaidId)
	{
		List<FacetsMemberEligibilityDto> result = new ArrayList<FacetsMemberEligibilityDto>();
		FacetsMemberEligibilityDto singleEligibilities = getSingleEligibilitiesByMedicaidId(medicaidId);
		if (singleEligibilities != null)
		{
			result.add(singleEligibilities);
		}

		return result;
	}

	/**
	 * Returns current eligibilities for the given medicaid Id
	 * 
	 * @param sbsbId
	 * @return all active eligibilities
	 */
	public List<FacetsMemberEligibilityDto> getEligibilitiesByMedicareId(String medicareId)
	{
		List<FacetsMemberEligibilityDto> result = new ArrayList<FacetsMemberEligibilityDto>();
		FacetsMemberEligibilityDto singleEligibilities = getSingleEligibilitiesByMedicareId(medicareId);
		if (singleEligibilities != null)
		{
			result.add(singleEligibilities);
		}

		return result;
	}

	/**
	 * Returns current eligibilities for the given medicaid Id
	 * 
	 * @param sbsbId
	 * @return all active eligibilities
	 */
	public List<FacetsMemberEligibilityDto> getEligibilitiesWithNoEligibilityCheckByMedicaidId(String medicaidId)
	{
		List<FacetsMemberEligibilityDto> result = new ArrayList<FacetsMemberEligibilityDto>();
		FacetsMemberEligibilityDto singleEligibilities = getSingleEligibilitiesWithNoEligibilityCheckByMedicaidId(medicaidId);
		if (singleEligibilities != null)
		{
			result.add(singleEligibilities);
		}

		return result;
	}

	/**
	 * Returns current eligibilities for the given medicare Id
	 * 
	 * @param sbsbId
	 * @return all active eligibilities
	 */
	public List<FacetsMemberEligibilityDto> getEligibilitiesWithNoEligibilityCheckByMedicareId(String medicareId)
	{
		List<FacetsMemberEligibilityDto> result = new ArrayList<FacetsMemberEligibilityDto>();
		FacetsMemberEligibilityDto singleEligibilities = getSingleEligibilitiesWithNoEligibilityCheckByMedicareId(medicareId);
		if (singleEligibilities != null)
		{
			result.add(singleEligibilities);
		}

		return result;
	}

	/**
	 * Returns all the eligibilities for the given medicaid Id
	 * 
	 * @param medicaidId
	 * @return all active eligibilities
	 */
	public List<FacetsMemberEligibilityDto> getAllEligibilitiesByMedicaidId(String medicaidId)
	{
		List<FacetsMemberEligibilityDto> result = new ArrayList<FacetsMemberEligibilityDto>();
		result = getDao().getAllEligibilityByMedicaidID(medicaidId);

		return result;
	}

	/**
	 * Returns all the eligibilities for the given medicare Id
	 * 
	 * @param medicareId
	 * @return all active eligibilities
	 */
	public List<FacetsMemberEligibilityDto> getAllEligibilitiesByMedicareId(String medicareId)
	{
		List<FacetsMemberEligibilityDto> result = new ArrayList<FacetsMemberEligibilityDto>();
		result = getDao().getAllEligibilityByCurrentMedicareID(medicareId);
		if (result == null || result.isEmpty() || result.size() <= 0)
		{
			result = getDao().getAllEligibilityByOldMedicareID(medicareId);
		}
		return result;
	}

	/**
	 * Returns all the eligibilities for the given medicaid Id
	 * 
	 * @param medicaidId
	 * @return all active eligibilities
	 */
	public List<FacetsMemberEligibilityDto> getAllEligibilitiesWithNoEligibilityCheckByMedicaidId(String medicaidId)
	{
		List<FacetsMemberEligibilityDto> result = new ArrayList<FacetsMemberEligibilityDto>();
		result = getDao().getAllEligibilityWithNoEligibilityCheckByMedicaidID(medicaidId);

		return result;
	}

	/**
	 * Returns all the eligibilities for the given medicare Id
	 * 
	 * @param medicareId
	 * @return all active eligibilities
	 */
	public List<FacetsMemberEligibilityDto> getAllEligibilitiesWithNoEligibilityCheckByMedicareId(String medicareId)
	{
		List<FacetsMemberEligibilityDto> result = new ArrayList<FacetsMemberEligibilityDto>();
		result = getDao().getAllEligibilityWithNoEligibilityCheckByCurrentMedicareID(medicareId);
		if (result == null || result.isEmpty() || result.size() <= 0)
		{
			result = getDao().getAllEligibilityWithNoEligibilityCheckByOldMedicareID(medicareId);
		}
		return result;
	}

	/**
	 * Returns all eligibilities, past, present and future for the given subscriber
	 * 
	 * @param sbsbId subscriber Id
	 * @return all eligibilities, past, present, and future, for the given subscriber Id
	 */
	public List<FacetsMemberEligibilityDto> getAllEligibilitiesBySbsbId(String sbsbId)
	{
		return getDao().getAllEligibilitiesByAmerigroupID(sbsbId);
	}

	/**
	 * Returns all eligibilities, past, present and future for the given subscriber
	 * 
	 * @param sbsbId subscriber Id
	 * @return all eligibilities, past, present, and future, for the given subscriber Id
	 */
	public List<FacetsMemberEligibilityDto> getAllEligibilitiesWithNoEligibilityCheckBySbsbId(String sbsbId)
	{
		return getDao().getAllEligibilitiesWithNoEligibilityCheckByAmerigroupID(sbsbId);
	}

	/**
	 * 
	 * @param medicaidId
	 * @return a single "current" / active eligibility for the provided member id
	 */
	private FacetsMemberEligibilityDto getSingleEligibilitiesByMedicaidId(String mediciadId)
	{
		return getDao().getCurrentEligibilityByMedicaidID(mediciadId);
	}

	/**
	 * 
	 * @param medicareId
	 * @return a single "current" / active eligibility for the provided member id
	 */
	private FacetsMemberEligibilityDto getSingleEligibilitiesByMedicareId(String medicareId)
	{
		FacetsMemberEligibilityDto result = new FacetsMemberEligibilityDto();
		result = getDao().getCurrentEligibilityByCurrentMedicareID(medicareId);
		if (result == null)
		{
			result = getDao().getCurrentEligibilityByOldMedicareID(medicareId);
		}
		return result;
	}

	/**
	 * 
	 * @param medicaidId
	 * @return a single "current" / active eligibility for the provided member id
	 */
	private FacetsMemberEligibilityDto getSingleEligibilitiesWithNoEligibilityCheckByMedicaidId(String mediciadId)
	{
		return getDao().getCurrentEligibilityWithNoEligibilityCheckByMedicaidID(mediciadId);
	}

	/**
	 * 
	 * @param medicareId
	 * @return a single "current" / active eligibility for the provided member id
	 */
	private FacetsMemberEligibilityDto getSingleEligibilitiesWithNoEligibilityCheckByMedicareId(String medicareId)
	{
		FacetsMemberEligibilityDto result = new FacetsMemberEligibilityDto();
		result = getDao().getCurrentEligibilityWithNoEligibilityCheckByCurrentMedicareID(medicareId);
		if (result == null)
		{
			result = getDao().getCurrentEligibilityWithNoEligibilityCheckByOldMedicareID(medicareId);
		}
		return result;
	}

	/**
	 * 
	 * @param medicaidId
	 * @return a single "current" / active eligibility for the provided member id
	 */
	private FacetsMemberEligibilityDto getSingleEligibilities(String sbsbId)
	{
		return getDao().getCurrentEligibilityByAmerigroupID(sbsbId);
	}

	/**
	 * 
	 * @param medicaidId
	 * @return a single "current" / active eligibility for the provided member id
	 */
	private FacetsMemberEligibilityDto getSingleEligibilitiesWithNoEligibilityCheck(String sbsbId)
	{
		return getDao().getCurrentEligibilityWithNoEligibilityCheckByAmerigroupID(sbsbId);
	}

	/**
	 * This is to help with mocking during unit testing
	 * 
	 * @return new instantiation of the IFacetsMemberDao object
	 */
	protected IFacetsMemberDao getDao()
	{
		return ((IFacetsMemberDao) factory.getDaoImpl(IFacetsMemberDao.class));
	}

	/**
	 * @param groupId
	 * @return
	 */
	public List<MemberPortalGroupBrandConfigDto> getBrand(String groupId)
	{
		return ((IMemberPortalDao) factory.getDaoImpl(IMemberPortalDao.class)).getBrand(groupId);
	}
}
