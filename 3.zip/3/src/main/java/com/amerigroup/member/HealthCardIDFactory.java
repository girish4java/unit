package com.amerigroup.member;

import java.util.Date;

/**
 * Helper utility for creating instances of a HealthCardID. This is useful for testing purposes because the existing
 * HealthCardID implementation is a hybrid object that looks like a pojo, but internally will access the database to
 * populate prefix values. Using the factory will allow for easier testing and pave the way for deprecating the current
 * behavior.
 * 
 * @author Daniel Spangler
 * 
 */
public class HealthCardIDFactory
{

	/**
	 * Creates an instance of a HealthCardID using the provided subscriberId. The prefix will be looked up from the
	 * database.
	 * 
	 * @param subscriberId the raw subscriberId to use
	 * @return the healthcard id instance
	 */
	public HealthCardID createHealthCardID(String subscriberId)
	{
		return new HealthCardID(subscriberId);
	}

	/**
	 * Creates an instance of a HealthCardID using the provided subscriberId. The prefix will be looked up from the
	 * database.
	 * 
	 * @param subscriberId the raw subscriberId to use
	 * @return the healthcard id instance
	 */
	public HealthCardID createHealthCardID(String subscriberId, Date startDt)
	{
		return new HealthCardID(subscriberId, startDt);
	}

	/**
	 * Creates an instance of a HealthCardID using the provided subscriberId and prefix.
	 * 
	 * @param prefix the prefix id
	 * @param subscriberId the raw subscriberId to use
	 * @return the healthcard id instance
	 */
	public HealthCardID createHealthCardID(String prefix, String subscriberId)
	{
		return new HealthCardID(prefix, subscriberId);
	}

}
