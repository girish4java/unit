package com.amerigroup.member;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlType;

import com.amerigroup.daobase.DaoImplFactory;
import com.amerigroup.exception.runtime.validation.ArgumentsNotToSpecException;
import com.amerigroup.exception.runtime.validation.PrefixIdMismatchException;
import com.amerigroup.exception.runtime.validation.PrefixInvalidException;
import com.amerigroup.facets.dao.IFacetsMemberDao;
import com.amerigroup.facets.dao.dto.FacetsMemberIdAndBluesPrefixDto;
import com.amerigroup.utilities.Text;

/**
 * ID shown on Health Insurance ID Card
 */

@XmlType(name = "HealthCardID")
public class HealthCardID
{
	/**
	 * For Blues members, their ID will have prefix such as YTD. Possible prefixes will be stored in cspi_its_prefix
	 * column of Facets.cmc_cspi_cs_plan table
	 */
	@XmlElement(required = true, nillable = false)
	public String prefix;

	/**
	 * SubscriberId is stored in Facets table CMC_SBSB_SUBSC.SBSB_ID
	 */
	@XmlElement(required = true, nillable = false)
	public String sbsbId;

	/**
	 * Default public constructor
	 */
	public HealthCardID()
	{
		prefix = "";
		sbsbId = "";
	}

	/**
	 * Public constructor. If the value provided to the constructor has a prefix, that that value will be parsed and
	 * assigned as the prefix. No db lookup wil be attempted.
	 * 
	 * Validation rules:
	 * <ul>
	 * <li>hcid can be 8,9, or 12 characters
	 * <li>hcid must not contain empty spaces
	 * </ul>
	 * 
	 * @param rawSbsbId Subscriber ID
	 */
	public HealthCardID(String rawSbsbId)
	{
		rawSbsbId = Text.nullSafeTrim(rawSbsbId);
		if (!Text.isEffectivelyEmptyOrNull(rawSbsbId) && rawSbsbId.length() > 9)
		{
			this.prefix = rawSbsbId.substring(0, 3);
			this.sbsbId = rawSbsbId.substring(3, rawSbsbId.length());
		}
		else
		{
			valueOf(rawSbsbId, new Date());
		}
	}

	/**
	 * Public constructor. If the value provided to the constructor has a prefix, that that value will be parsed and
	 * assigned as the prefix. No db lookup wil be attempted.
	 * 
	 * @param rawSbsbId SBSB ID
	 * @param searchDate Search date since prefix might be date sensitive
	 */
	public HealthCardID(String rawSbsbId, Date searchDate)
	{
		rawSbsbId = Text.nullSafeTrim(rawSbsbId);
		if (!Text.isEffectivelyEmptyOrNull(rawSbsbId) && rawSbsbId.length() > 9)
		{
			this.prefix = rawSbsbId.substring(0, 3);
			this.sbsbId = rawSbsbId.substring(3, rawSbsbId.length());
		}
		else
		{
			valueOf(rawSbsbId, searchDate);
		}
	}

	/**
	 * Public constructor
	 * 
	 * @param rawPrefix ID prefix
	 * @param rawSbsbId ID
	 */
	public HealthCardID(String rawPrefix, String rawSbsbId)
	{
		rawSbsbId = Text.nullSafeTrim(rawSbsbId);
		rawPrefix = Text.nullSafeTrim(rawPrefix);

		this.prefix = rawPrefix;
		this.sbsbId = rawSbsbId;
	}

	/**
	 * Check the prefix caching and see if the input prefix is among the list
	 * 
	 * @param pfx the id prefix
	 * 
	 * @return whether this is a valid prefix
	 */
	private boolean isValidPrefix(String pfx)
	{
		/*
		 * Get the cached prefixes
		 */
		MemberPrefixPlugin mpp = MemberPrefixPlugin.getInstance();

		List<String> prefixList = mpp.getCachedPrefixes();

		for (String str : prefixList)
		{
			if (pfx.equalsIgnoreCase(str))
			{
				return true;
			}
		}
		return false;
	}

	@Override
	public String toString()
	{
		return "HealthCardID [prefix=" + prefix + ", sbsbId=" + sbsbId + "]";
	}

	/**
	 * Verify that: 1) sbsbID cannot be null or empty; 2) prefix is valid and agree with sbsbID
	 */
	public void validate()
	{
		if (Text.isEffectivelyEmptyOrNull(sbsbId))
		{
			throw new ArgumentsNotToSpecException("Subscriber ID cannot be null or empty");
		}

		if (!(sbsbId.length() == 8 || sbsbId.length() == 9))
		{
			throw new ArgumentsNotToSpecException("Subscriber ID must be 8 or 9 characters");
		}

		if (!Text.isEffectivelyEmptyOrNull(prefix))
		{
			// Prefix must be in the prefix cache
			if (!isValidPrefix(prefix))
			{
				throw new PrefixInvalidException(prefix + " prefix is invalid");
			}

			// Prefix must agree with sbsbID
			HealthCardID tempId = new HealthCardID(sbsbId);
			if (!prefix.equalsIgnoreCase(tempId.prefix))
			{
				throw new PrefixIdMismatchException(prefix + " does not agree with sbsbId " + sbsbId);
			}
		}
	}

	/**
	 * Verify that: 1) sbsbID cannot be null or empty; 2) prefix is valid and agree with sbsbID
	 */
	public void validate(Date searchDate)
	{
		if (Text.isEffectivelyEmptyOrNull(sbsbId))
		{
			throw new ArgumentsNotToSpecException("Subscriber ID cannot be null or empty");
		}

		if (!(sbsbId.length() == 8 || sbsbId.length() == 9))
		{
			throw new ArgumentsNotToSpecException("Subscriber ID must be 8 or 9 characters");
		}

		if (!Text.isEffectivelyEmptyOrNull(prefix))
		{
			// Prefix must be in the prefix cache
			if (!isValidPrefix(prefix))
			{
				throw new PrefixInvalidException(prefix + " prefix is invalid");
			}

			if (searchDate == null)
			{
				searchDate = new Date();
			}
			// Prefix must agree with sbsbID
			HealthCardID tempId = new HealthCardID(sbsbId, searchDate);
			if (!prefix.equalsIgnoreCase(tempId.prefix))
			{
				throw new PrefixIdMismatchException(prefix + " does not agree with sbsbId " + sbsbId + " as of "
						+ searchDate);
			}
		}
	}

	/**
	 * Convert SBSB ID to HealthCard ID for a given date
	 * 
	 * @param rawSbsbId SBSB ID
	 * @param searchDate Search date since prefix might be date sensitive
	 */
	private final void valueOf(String rawSbsbId, Date searchDate)
	{
		sbsbId = rawSbsbId;
		if (rawSbsbId != null)
		{
			sbsbId = rawSbsbId.trim();
		}
		if (searchDate == null)
		{
			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.MILLISECOND, 0);
			cal.set(Calendar.SECOND, 0);
			searchDate = cal.getTime();
		}

		/*
		 * We do not have length restriction of this sbsbId
		 */
		if (!Text.isEffectivelyEmptyOrNull(sbsbId) && searchDate != null)
		{
			/*
			 * Get the prefix info from Facets table by subscriberId and search
			 * date.
			 */
			FacetsMemberIdAndBluesPrefixDto dto = ((IFacetsMemberDao) DaoImplFactory.getInstance().getDaoImpl(
					IFacetsMemberDao.class)).getIdAndBluesPrefixBySbsbIdAndDate(sbsbId, searchDate);

			if (dto != null)
			{
				prefix = dto.prefix;
			}
		}
	}
}
